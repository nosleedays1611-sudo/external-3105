PATCH SLOTS — APPLY/RESTORE ORIGINAL

1. Coloque o .3105 nesta pasta.
2. Em ContentView.swift > PatchSlots, troque SOMENTE o nome entre aspas.

ON:
- abre e decodifica o .3105
- chama DevicePatchService.apply(project:)
- PatchTransaction cria backup/journal original
- aplica o patch

OFF:
- encontra o último PatchTransactionReceipt desse projeto
- chama DevicePatchService.restore(receipt:)
- valida e restaura o backup original

Pacotes protegidos por senha não podem ser ligados automaticamente pelo switch.
