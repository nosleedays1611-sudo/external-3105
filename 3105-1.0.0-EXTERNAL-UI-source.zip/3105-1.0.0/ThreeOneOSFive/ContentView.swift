import SwiftUI

struct ContentView: View {
    @State private var tab = 0
    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.ignoresSafeArea()
            Group {
                if tab == 0 { ExternalFunctionsView() }
                else if tab == 1 { PlaceholderView(title: "Texturas") }
                else { PlaceholderView(title: "Config") }
            }.padding(.bottom, 86)
            HStack {
                BottomItem(icon: "house.fill", title: "Function", selected: tab == 0) { tab = 0 }
                BottomItem(icon: "figure.stand", title: "Texturas", selected: tab == 1) { tab = 1 }
                BottomItem(icon: "cube.fill", title: "Config", selected: tab == 2) { tab = 2 }
            }.padding(.horizontal, 28).padding(.bottom, 12)
        }.preferredColorScheme(.dark)
    }
}

private struct ExternalFunctionsView: View {
    @State private var game = 0
    @State private var enabled: Set<String> = []
    private let headshots = [
        ("aim", "AIM ASSIT", "Mira no Pescoco + Esp Box"),
        ("alto-neck", "HS ALTO + NECK", "HS Acima da Cabeça e no Pescoço."),
        ("neck", "HS NECK", "HS Apenas no Pescoço do Inimigo."),
        ("peito", "HS PEITO", "HS no Peito do Inimigo."),
        ("magic", "MAGIC", "Bala Magica"),
        ("fps", "120/144 FPS", "Para Celulares Que Suportam 120/144 FPS")
    ]
    private let holograms = [
        ("guns", "HOLOGRAMA GUNS", "Holograma nas Armas"),
        ("characters", "HOLOGRAMA CHARACTERS", "Holograma nos Personagens")
    ]
    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Spacer().frame(height: 245)
                HStack(spacing: 16) {
                    GameButton("Free Fire Normal", selected: game == 0) { game = 0 }
                    GameButton("Free Fire Max", selected: game == 1) { game = 1 }
                }
                SectionBlock(title: "HEADSHOTS", rows: headshots, enabled: $enabled).padding(.top, 30)
                SectionBlock(title: "HOLOGRAMAS", rows: holograms, enabled: $enabled).padding(.top, 28)
                Spacer().frame(height: 80)
            }.padding(.horizontal, 30)
        }
    }
}

private struct GameButton: View {
    let title: String; let selected: Bool; let action: () -> Void
    init(_ title: String, selected: Bool, action: @escaping () -> Void) { self.title=title; self.selected=selected; self.action=action }
    var body: some View { Button(action: action) { Text(title).font(.system(size: 18, weight: .semibold)).foregroundStyle(.white).frame(maxWidth: .infinity).frame(height: 72).overlay(RoundedRectangle(cornerRadius: 18).stroke(selected ? Color(red:0.58,green:0.78,blue:0.98) : Color.white.opacity(0.28), lineWidth: 2)) }.buttonStyle(.plain) }
}

private struct SectionBlock: View {
    let title: String; let rows: [(String,String,String)]; @Binding var enabled: Set<String>
    var body: some View { VStack(alignment: .leading, spacing: 24) { Text(title).font(.system(size: 17, weight: .bold)).foregroundStyle(Color(red:0.60,green:0.77,blue:0.94)); ForEach(rows, id: \.0) { row in HStack { VStack(alignment:.leading, spacing:6) { Text(row.1).font(.system(size:20, weight:.medium)).foregroundStyle(.white); Text(row.2).font(.system(size:14)).foregroundStyle(Color.white.opacity(0.48)) }; Spacer(); Toggle("", isOn: Binding(get:{enabled.contains(row.0)}, set:{on in if on {enabled.insert(row.0)} else {enabled.remove(row.0)} })).labelsHidden().scaleEffect(1.12) } } } }
}

private struct BottomItem: View {
    let icon:String; let title:String; let selected:Bool; let action:()->Void
    var body: some View { Button(action:action) { VStack(spacing:4) { Image(systemName:icon).font(.system(size:23)); Text(title).font(.system(size:13)) }.foregroundStyle(selected ? Color(red:0.58,green:0.77,blue:0.94) : Color.white.opacity(0.52)).frame(maxWidth:.infinity).frame(height:70).background(selected ? Color.white.opacity(0.10) : .clear, in: RoundedRectangle(cornerRadius:30)) }.buttonStyle(.plain) }
}
private struct PlaceholderView: View { let title:String; var body: some View { ZStack { Color.black.ignoresSafeArea(); Text(title).font(.title.bold()).foregroundStyle(.white) } } }
