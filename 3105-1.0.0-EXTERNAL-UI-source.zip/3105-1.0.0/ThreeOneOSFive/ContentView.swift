import SwiftUI

struct ContentView: View {
    @State private var tab = 0
    @AppStorage("external.darkMode") private var darkMode = true

    var body: some View {
        ZStack(alignment: .bottom) {
            Color.black.ignoresSafeArea()

            Group {
                if tab == 0 {
                    ExternalFunctionsView()
                } else if tab == 1 {
                    TexturasView()
                } else {
                    ConfigDashboardView(darkMode: $darkMode)
                }
            }
            .padding(.bottom, 88)

            HStack {
                BottomItem(icon: "house.fill", title: "Function", selected: tab == 0) { tab = 0 }
                BottomItem(icon: "figure.stand", title: "Texturas", selected: tab == 1) { tab = 1 }
                BottomItem(icon: "cube.fill", title: "Config", selected: tab == 2) { tab = 2 }
            }
            .padding(.horizontal, 28)
            .padding(.bottom, 12)
        }
        .preferredColorScheme(darkMode ? .dark : .light)
    }
}

private struct ExternalFunctionsView: View {
    @State private var game = 0
    @State private var enabled: Set<String> = []

    private let aimEsp = [
        ("aim-assist", "AIM ASSIST", ""),
        ("aimbot-esp", "AIM BOT + ESP 3 DEDOS", "")
    ]

    private let headshots = [
        ("alto-pescoco", "HS ALTO + PESCOÇO", ""),
        ("pescoco", "HS PESCOÇO", ""),
        ("peito", "HS PEITO", ""),
        ("magic-bullet", "MAGIC BULLET", "")
    ]

    private let holograms = [
        ("holograma-preto", "HOLOGRAMA PRETO", "")
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Spacer().frame(height: 245)

                HStack(spacing: 18) {
                    GameButton("Free Fire Normal", selected: game == 0) { game = 0 }
                    GameButton("Free Fire Max", selected: game == 1) { game = 1 }
                }

                SectionBlock(title: "AIM / ESP", rows: aimEsp, enabled: $enabled)
                    .padding(.top, 34)

                SectionBlock(title: "HEADSHOTS", rows: headshots, enabled: $enabled)
                    .padding(.top, 34)

                SectionBlock(title: "HOLOGRAMAS", rows: holograms, enabled: $enabled)
                    .padding(.top, 34)

                Spacer().frame(height: 100)
            }
            .padding(.horizontal, 28)
        }
    }
}

private struct GameButton: View {
    let title: String
    let selected: Bool
    let action: () -> Void

    init(_ title: String, selected: Bool, action: @escaping () -> Void) {
        self.title = title
        self.selected = selected
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 72)
                .overlay(
                    RoundedRectangle(cornerRadius: 18)
                        .stroke(
                            selected
                                ? Color(red: 0.58, green: 0.78, blue: 0.98)
                                : Color.white.opacity(0.28),
                            lineWidth: 2
                        )
                )
        }
        .buttonStyle(.plain)
    }
}

private struct SectionBlock: View {
    let title: String
    let rows: [(String, String, String)]
    @Binding var enabled: Set<String>

    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            Text(title)
                .font(.system(size: 17, weight: .bold))
                .foregroundStyle(Color(red: 0.60, green: 0.77, blue: 0.94))

            ForEach(rows, id: \.0) { row in
                HStack(spacing: 18) {
                    VStack(alignment: .leading, spacing: 7) {
                        Text(row.1)
                            .font(.system(size: 20, weight: .medium))
                            .foregroundStyle(.white)

                        if !row.2.isEmpty {
                            Text(row.2)
                                .font(.system(size: 15))
                                .foregroundStyle(Color.white.opacity(0.48))
                        }
                    }

                    Spacer(minLength: 12)

                    Toggle(
                        "",
                        isOn: Binding(
                            get: { enabled.contains(row.0) },
                            set: { on in
                                if on { enabled.insert(row.0) }
                                else { enabled.remove(row.0) }
                            }
                        )
                    )
                    .labelsHidden()
                    .scaleEffect(1.12)
                }
                .frame(minHeight: 44)
            }
        }
    }
}

private struct TexturasView: View {
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            Text("Em desenvolvimento pra nova atualização")
                .font(.system(size: 20, weight: .medium))
                .foregroundStyle(Color.white.opacity(0.65))
                .multilineTextAlignment(.center)
                .padding(.horizontal, 38)
        }
    }
}

private struct ConfigDashboardView: View {
    @EnvironmentObject private var appState: AppState
    @Binding var darkMode: Bool
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            List {
                Section("CONTA") {
                    LabeledContent("Key", value: "–")
                    LabeledContent("Expira em", value: "–")
                    LabeledContent("Build", value: "10")
                    LabeledContent("Versão", value: "1.10")
                }

                Section {
                    LabeledContent("Phone", value: DeviceInfo.machine)
                    LabeledContent("Modelo de hardware", value: DeviceInfo.machine)
                    LabeledContent("Versão do iOS", value: UIDevice.current.systemVersion)
                    HStack {
                        Text("Compatibilidade")
                        Spacer()
                        Label(
                            appState.isSupported ? "Suportado" : "Não suportado",
                            systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill"
                        )
                        .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                } header: {
                    Text("DISPOSITIVO")
                } footer: {
                    Text("Verificado: iOS 26.0–26.6.1 e builds listados do iOS 27.")
                }

                Section("INSTALAÇÃO") {
                    Label {
                        Text("Funciona apenas assinado com certificado enterprise. SideStore, AltStore, 3uTools e LiveContainer não são suportados.")
                            .foregroundStyle(.secondary)
                    } icon: {
                        Image(systemName: "checkmark.seal")
                            .foregroundStyle(Color(red:0.58,green:0.77,blue:0.94))
                    }
                }
            }
            .scrollContentBackground(.hidden)
            .background(Color(uiColor: .systemBackground))
            .toolbar {
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button {
                        showSettings = true
                    } label: {
                        Image(systemName: "gearshape")
                    }

                    Button {
                        darkMode.toggle()
                    } label: {
                        Image(systemName: darkMode ? "moon.fill" : "sun.max.fill")
                    }
                }
            }
            .tint(Color(red:0.58,green:0.77,blue:0.94))
            .sheet(isPresented: $showSettings) {
                SettingsView()
            }
        }
    }
}

private struct LanguageCell: View {
    let title: String
    var selected: Bool = false

    init(_ title: String, selected: Bool = false) {
        self.title = title
        self.selected = selected
    }

    var body: some View {
        Text(title)
            .font(.system(size: 14, weight: .medium))
            .frame(maxWidth: .infinity)
            .frame(height: 44)
            .background(selected ? Color.white.opacity(0.12) : Color.clear,
                        in: RoundedRectangle(cornerRadius: 9))
    }
}

private struct ConfigValueRow: View {
    let title: String
    let value: String

    init(_ title: String, value: String) {
        self.title = title
        self.value = value
    }

    var body: some View {
        HStack {
            Text(title).font(.system(size: 18))
            Spacer()
            Text(value)
                .font(.system(size: 16, design: .monospaced))
                .foregroundStyle(.secondary)
        }
    }
}

private extension Text {
    func configHeader() -> some View {
        self.font(.system(size: 18, weight: .semibold))
            .foregroundStyle(.secondary)
    }
}

private enum DeviceInfo {
    static var machine: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }
}

private struct BottomItem: View {
    let icon: String
    let title: String
    let selected: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                Image(systemName: icon).font(.system(size: 23))
                Text(title).font(.system(size: 13))
            }
            .foregroundStyle(
                selected
                    ? Color(red: 0.58, green: 0.77, blue: 0.94)
                    : Color.white.opacity(0.52)
            )
            .frame(maxWidth: .infinity)
            .frame(height: 70)
            .background(
                selected ? Color.white.opacity(0.10) : .clear,
                in: RoundedRectangle(cornerRadius: 30)
            )
        }
        .buttonStyle(.plain)
    }
}
