PATCH SLOTS

1. Coloque seus arquivos .3105 nesta pasta.
2. Abra ContentView.swift.
3. No bloco PatchSlots, troque somente o nome entre aspas.
Exemplo:
static let hsNeck = "meu_patch.3105"

Os switches já chamam PatchSlotRunner automaticamente.
