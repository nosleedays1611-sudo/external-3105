PATCH SLOTS — APPLY/RESTORE + SENHA

Em ContentView.swift > PatchSlots:
- nome do arquivo: "arquivo.3105"
- password = "0" para arquivo SEM senha
- se tiver senha, coloque a senha entre aspas.

Exemplo:
static let aimBotEsp = "aim-bot-esp.3105"
static let aimBotEspPassword = "MinhaSenha123"

ON usa o mesmo PatchPackageCodec.decode e DevicePatchService.apply.
OFF usa o receipt/backup e DevicePatchService.restore.
