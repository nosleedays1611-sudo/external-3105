import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage("external.darkMode") private var darkMode = true

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 27) {
                    HStack(spacing: 14) {
                        AppLogo(size: 48)
                        VStack(alignment:.leading, spacing:4) {
                            Text("3105").font(.system(size:19,weight:.semibold))
                            Text(language.text("common.version", appVersion))
                                .font(.system(size:15)).foregroundStyle(.secondary)
                        }
                    }

                    settingHeader("Language")
                    Picker("Language", selection:$languageCode) {
                        ForEach(AppLanguage.allCases) { option in Text(option.displayName).tag(option.rawValue) }
                    }.pickerStyle(.segmented).labelsHidden()

                    settingHeader("Device")
                    compactRow("Hardware model", AppInfo.displayMachineName)
                    compactRow("iOS Version", AppInfo.osVersion)

                    settingHeader("Verified versions")
                    HStack {
                        Text("Current version"); Spacer()
                        Image(systemName: appState.isSupported ? "checkmark.circle.fill":"xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? .green:.red)
                        Text(appState.isSupported ? "Supported":"Unsupported")
                            .foregroundStyle(appState.isSupported ? .green:.red)
                    }
                    compactRow("iOS 26", ExploitSupportPolicy.verifiedIOS26Range)
                    VStack(alignment:.leading,spacing:10) {
                        Text("iOS 27.0")
                        ForEach(ExploitSupportPolicy.verifiedIOS27Builds,id:\.build) { v in
                            Text("Beta \(v.beta)  ·  \(v.build)")
                                .font(.system(size:13,design:.monospaced)).foregroundStyle(.secondary)
                        }
                    }
                    Text("Only the builds listed above are enabled. Newer builds may be marked unsupported.")
                        .font(.system(size:13)).foregroundStyle(.secondary)

                    settingHeader("Appearance")
                    Toggle(isOn:$darkMode) {
                        Label(darkMode ? "Dark mode":"Light mode",
                              systemImage:darkMode ? "moon.fill":"sun.max.fill")
                    }

                    settingHeader("Credits")
                    Link(destination:URL(string:"https://discord.gg/realmproxys")!) {
                        HStack {
                            VStack(alignment:.leading,spacing:3) {
                                Text("Realm").font(.headline)
                                Text("Discord").font(.caption)
                            }
                            Spacer(); Image(systemName:"arrow.up.right")
                        }.foregroundStyle(AppTheme.accent)
                    }
                }
                .padding(.horizontal, 34).padding(.top, 36).padding(.bottom, 44)
            }
            .navigationTitle("Settings").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement:.topBarTrailing) {
                    Button("Done") { dismiss() }.fontWeight(.semibold)
                }
            }
            .tint(AppTheme.accent)
        }
        .preferredColorScheme(darkMode ? .dark:.light)
    }

    private func settingHeader(_ s:String)->some View {
        Text(s).font(.system(size:16,weight:.semibold)).foregroundStyle(.secondary)
    }
    private func compactRow(_ a:String,_ b:String)->some View {
        HStack { Text(a); Spacer(); Text(b).font(.system(size:15,design:.monospaced)).foregroundStyle(.secondary) }
            .font(.system(size:16)).frame(minHeight:36)
    }
    private var appVersion:String {
        Bundle.main.object(forInfoDictionaryKey:"AppReleaseDisplayVersion") as? String
        ?? Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String ?? "1.0"
    }
}
