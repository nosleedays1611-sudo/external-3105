PATCH SLOTS
Edite ContentView.swift > PatchSlots.
password = "0" significa sem senha.
Se houver senha, coloque a senha entre aspas.
Os arquivos .3105 precisam estar disponíveis no bundle do app para os switches localizá-los.
