import SwiftUI
import UIKit
import ImageIO

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage("external.darkMode") private var darkMode = true

    private var isPT: Bool { languageCode == AppLanguage.portugueseBrazil.rawValue }

    var body: some View {
        NavigationStack {
            ZStack {
                Color.black.ignoresSafeArea()
                ScrollView {
                VStack(alignment: .leading, spacing: 27) {
                    RealmGIFBanner()
                        .frame(maxWidth: .infinity)
                        .frame(height: 104)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(AppTheme.accent.opacity(0.55), lineWidth: 1)
                        )

                    settingHeader(isPT ? "Idioma" : "Language")
                    Picker(isPT ? "Idioma" : "Language", selection:$languageCode) {
                        ForEach(AppLanguage.allCases) { option in
                            Text(option.displayName).tag(option.rawValue)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()

                    settingHeader(isPT ? "Dispositivo" : "Device")
                    compactRow(isPT ? "Modelo de hardware" : "Hardware model", AppInfo.displayMachineName)
                    compactRow(isPT ? "Versão do iOS" : "iOS Version", AppInfo.osVersion)

                    settingHeader(isPT ? "Versões verificadas" : "Verified versions")
                    HStack {
                        Text(isPT ? "Versão atual" : "Current version")
                        Spacer()
                        Image(systemName: appState.isSupported ? "checkmark.circle.fill":"xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? .green:.red)
                        Text(appState.isSupported
                             ? (isPT ? "Suportado":"Supported")
                             : (isPT ? "Não suportado":"Unsupported"))
                            .foregroundStyle(appState.isSupported ? .green:.red)
                    }
                    compactRow("iOS 26", ExploitSupportPolicy.verifiedIOS26Range)
                    VStack(alignment:.leading,spacing:10) {
                        Text("iOS 27.0")
                        ForEach(ExploitSupportPolicy.verifiedIOS27Builds,id:\.build) { v in
                            Text("\(isPT ? "Beta" : "Beta") \(v.beta)  ·  \(v.build)")
                                .font(.system(size:13,design:.monospaced)).foregroundStyle(.secondary)
                        }
                    }
                    Text(isPT
                         ? "Somente as builds listadas acima estão habilitadas. Builds mais novas podem aparecer como não suportadas."
                         : "Only the builds listed above are enabled. Newer builds may be marked unsupported.")
                        .font(.system(size:13)).foregroundStyle(.secondary)

                    // Appearance was intentionally removed here:
                    // the single global theme switch lives on the Config screen.

                    settingHeader(isPT ? "Créditos" : "Credits")
                    Link(destination:URL(string:"https://discord.gg/realmproxys")!) {
                        HStack {
                            Text("Realm").font(.headline)
                            Spacer()
                            Image(systemName:"arrow.up.right")
                        }
                        .foregroundStyle(AppTheme.accent)
                        .frame(minHeight: 44)
                    }
                }
                .padding(.horizontal,34)
                .padding(.top,36)
                .padding(.bottom,44)
            }
                }
            .navigationTitle(isPT ? "Ajustes" : "Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement:.topBarTrailing) {
                    Button(isPT ? "Concluído" : "Done") { dismiss() }
                        .fontWeight(.semibold)
                }
            }
            .tint(AppTheme.accent)
        }
        // Same global theme used by Function/Texturas/Config.
        .environment(\.colorScheme, .dark)
        .preferredColorScheme(.dark)
    }

    private func settingHeader(_ s:String)->some View {
        Text(s).font(.system(size:16,weight:.semibold)).foregroundStyle(.secondary)
    }

    private func compactRow(_ a:String,_ b:String)->some View {
        HStack {
            Text(a)
            Spacer()
            Text(b).font(.system(size:15,design:.monospaced)).foregroundStyle(.secondary)
        }
        .font(.system(size:16))
        .frame(minHeight:36)
    }

    private var appVersion:String {
        Bundle.main.object(forInfoDictionaryKey:"AppReleaseDisplayVersion") as? String
        ?? Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String
        ?? "1.0"
    }
}


private struct RealmGIFBanner: UIViewRepresentable {
    func makeUIView(context: Context) -> UIImageView {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        load(into: view)
        return view
    }

    func updateUIView(_ uiView: UIImageView, context: Context) {
        if uiView.animationImages == nil { load(into: uiView) }
    }

    private func load(into imageView: UIImageView) {
        guard let url = Bundle.main.url(forResource: "realm-banner", withExtension: "gif"),
              let data = try? Data(contentsOf: url),
              let source = CGImageSourceCreateWithData(data as CFData, nil) else { return }

        var frames: [UIImage] = []
        var duration: Double = 0
        let count = CGImageSourceGetCount(source)
        for index in 0..<count {
            guard let cg = CGImageSourceCreateImageAtIndex(source, index, nil) else { continue }
            frames.append(UIImage(cgImage: cg))
            duration += 0.08
        }
        imageView.animationImages = frames
        imageView.animationDuration = max(duration, 0.08 * Double(frames.count))
        imageView.startAnimating()
    }
}
