PATCH VAULT INPUT — v26

Esta pasta serve apenas como entrada para patches novos.
Ela nao e copiada para a IPA.

O workflow usa tools/build_patch_vault.py em modo incremental:
- preserva os patches que ja estao no patchvault.bin;
- adiciona/substitui somente os .3105 colocados nesta pasta;
- gera uma nova chave/vault;
- apaga os .3105 crus da copia usada no build.

AIM / ESP
- AIM BOT + ESP 4 DEDOS: aim-bot-esp.3105
- AIM SILENT + 4 DEDOS: aim-silent-4-dedos.3105
  -> este e o novo slot preparado; coloque o arquivo manualmente aqui.

ANTENA / HS
HS ALTO + PESCOCO
- sem: hs-alto-neck-sem-antena.3105
- com: hs-alto-neck-com-antena.3105

HS ALTO
- sem: hs-alto-sem-antena.3105
- com: hs-alto.3105

HS PESCOCO
- sem: hs-neck-sem-antena.3105
- com: hs-neck-com-antena.3105

HS PEITO
- sem: hs-peito-sem-antena.3105
- com: hs-peito.3105

Todos os botoes "sem" dos popups ficam habilitados na interface.
O arquivo correspondente precisa ter sido integrado ao vault para a opcao aplicar.

NO RELOG / HEADSHOTS CACHE
A aba No Relog usa apenas o switch (sem cards INJETAR 40%/LOBBY) e possui
slots de HEADSHOT separados. Coloque manualmente estes arquivos nesta pasta:

HS ALTO + PESCOCO
- sem: hs-alto-neck-sem-antena-cache.3105
- com: hs-alto-neck-com-antena-cache.3105

HS ALTO
- sem: hs-alto-sem-antena-cache.3105
- com: hs-alto-cache.3105

HS PESCOCO
- sem: hs-neck-sem-antena-cache.3105
- com: hs-neck-com-antena-cache.3105

HS PEITO
- sem: hs-peito-sem-antena-cache.3105
- com: hs-peito-cache.3105

Os popups "sem/com" continuam iguais aos da aba Function.
Ao ligar o switch do No Relog, a variante escolhida e aplicada diretamente;
ao existem os cards manuais nessa aba.

As senhas ficam no enum PatchSlots em ThreeOneOSFive/ContentView.swift.
"0" = patch sem senha.

REGRAS PRINCIPAIS
- Apenas um HS pode ficar selecionado por vez.
- Um AIM pode ser usado junto de um unico HS.
- HOLOGRAMA GUNS pode ser usado junto de um unico HS.
- Dois AIMs nao ficam ativos juntos.
- AIM e HOLOGRAMA nao ficam ativos juntos.
- MAGIC BULLET permanece habilitado na interface.
- 120/144 FPS permanece habilitado.

TEXTURAS v30 — arquivos preparados para upload manual:
- textura-1.3105  -> Textura 1 / personagem: santino
- textura-2.3105  -> Textura 2 / personagem: santino
- textura-3.3105  -> Textura 3 / personagem: santino

Coloque os arquivos em ThreeOneOSFive/Patches/ antes do build.
