PATCH VAULT INPUT

Esta pasta nao e copiada para a IPA.
O build protegido usa ThreeOneOSFive/Generated/patchvault.bin, embutido diretamente no executavel 3105.

Para trocar os patches localmente:
1. Coloque temporariamente os .3105 nesta pasta.
2. Rode:
   python3 -m pip install cryptography
   python3 tools/build_patch_vault.py \
     --input ThreeOneOSFive/Patches \
     --vault ThreeOneOSFive/Generated/patchvault.bin \
     --bridge ThreeOneOSFive/helpers/PatchVaultBridge.generated.c
3. Remova novamente os .3105 crus antes de publicar a source.
4. Commit somente patchvault.bin e PatchVaultBridge.generated.c.

O workflow nunca copia esta pasta para Payload/3105.app.
