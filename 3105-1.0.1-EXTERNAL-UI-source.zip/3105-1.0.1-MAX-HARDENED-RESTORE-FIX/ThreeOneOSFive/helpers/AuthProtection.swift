import Foundation
import SwiftUI
import Security
import CryptoKit
import Darwin

enum ProtectedAction: String {
    case tabNavigation = "tab-navigation"
    case gameSelection = "game-selection"
    case patchToggle = "patch-toggle"
    case patchApply = "patch-apply"
    case patchRestore = "patch-restore"
}

struct ActionPermit {
    let action: String
    let issuedAt: TimeInterval
    let nonce: String
    let signature: String
}

enum AuthGateError: LocalizedError {
    case blocked

    var errorDescription: String? {
        "Autenticação obrigatória. Ação bloqueada."
    }
}

private final class AuthRuntimeGate {
    static let shared = AuthRuntimeGate()

    private let lock = NSLock()
    private var sessionSecret: String?
    private var serverExpiry: Date?

    private init() {}

    func open(key: String, deviceToken: String, expiresAt: Date?) {
        let processNonce = UUID().uuidString + UUID().uuidString
        let material = [
            key,
            deviceToken,
            processNonce,
            AuthDylibLoader.expectedIntegritySHA256
        ].joined(separator: "|")

        lock.lock()
        sessionSecret = Self.sha256(material)
        serverExpiry = expiresAt
        lock.unlock()
    }

    func close() {
        lock.lock()
        sessionSecret = nil
        serverExpiry = nil
        lock.unlock()
    }

    func makePermit(for action: ProtectedAction) -> ActionPermit? {
        lock.lock()
        defer { lock.unlock() }

        guard let secret = sessionSecret else { return nil }
        if let serverExpiry, serverExpiry <= Date() { return nil }

        let issuedAt = Date().timeIntervalSince1970
        let nonce = UUID().uuidString
        let signature = Self.sha256("\(secret)|\(action.rawValue)|\(issuedAt)|\(nonce)")
        return ActionPermit(action: action.rawValue, issuedAt: issuedAt, nonce: nonce, signature: signature)
    }

    func validate(_ permit: ActionPermit, for action: ProtectedAction) -> Bool {
        lock.lock()
        defer { lock.unlock() }

        guard let secret = sessionSecret,
              permit.action == action.rawValue else { return false }

        if let serverExpiry, serverExpiry <= Date() { return false }

        let age = Date().timeIntervalSince1970 - permit.issuedAt
        guard age >= -2, age <= 15 else { return false }

        let expected = Self.sha256("\(secret)|\(action.rawValue)|\(permit.issuedAt)|\(permit.nonce)")
        return Self.constantTimeEqual(expected, permit.signature)
    }

    func isOpen() -> Bool {
        lock.lock()
        defer { lock.unlock() }
        guard sessionSecret != nil else { return false }
        if let serverExpiry, serverExpiry <= Date() { return false }
        return true
    }

    private static func sha256(_ text: String) -> String {
        let digest = SHA256.hash(data: Data(text.utf8))
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    private static func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8)
        let b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in a.indices { diff |= a[i] ^ b[i] }
        return diff == 0
    }
}

final class AuthDylibLoader {
    static let shared = AuthDylibLoader()
    // Stable integrity fingerprint of the dylib executable code + auth strings.
    // It intentionally excludes the code-signature blob, because iOS signing changes that blob.
    static let expectedIntegritySHA256 = "1a077a9bd9d9fbe7e318af925bc4e5971a6955469c83e3ace7e3de7d493b3c0b"
    private static let textRange = 0x50e4..<(0x50e4 + 0x98bc)
    private static let cstringRange = 0x10f3b..<(0x10f3b + 0x27d)

    private let lock = NSLock()
    private var handle: UnsafeMutableRawPointer?
    private var lastIntegrityCheck: Date?
    private var lastIntegrityResult = false
    private(set) var lastError: String?

    private init() {}

    @discardableResult
    func loadAndVerify() -> Bool {
        lock.lock()
        defer { lock.unlock() }

        if hasSuspiciousLoaderEnvironment() {
            lastError = "Ambiente de carregamento alterado."
            return false
        }

        guard let url = dylibURL() else {
            lastError = "CanvaCore.dylib não encontrada."
            return false
        }

        guard verifyHash(url: url) else {
            lastIntegrityCheck = Date()
            lastIntegrityResult = false
            lastError = "Integridade da CanvaCore.dylib inválida."
            return false
        }
        lastIntegrityCheck = Date()
        lastIntegrityResult = true

        if handle != nil {
            lastError = nil
            return true
        }

        handle = dlopen(url.path, RTLD_NOW | RTLD_LOCAL)
        guard handle != nil else {
            if let cError = dlerror() {
                lastError = String(cString: cError)
            } else {
                lastError = "Falha ao carregar CanvaCore.dylib."
            }
            return false
        }

        lastError = nil
        return true
    }

    func verifyIntegrity() -> Bool {
        lock.lock()
        defer { lock.unlock() }

        guard handle != nil,
              !hasSuspiciousLoaderEnvironment(),
              let url = dylibURL() else { return false }

        // Hashing the dylib from disk on every tap made navigation unnecessarily heavy.
        // Keep a very short cache: protection is still re-checked continuously, but
        // repeated gates during normal UI interaction are effectively instant.
        if let lastIntegrityCheck,
           Date().timeIntervalSince(lastIntegrityCheck) < 5 {
            return lastIntegrityResult
        }

        let result = verifyHash(url: url)
        lastIntegrityCheck = Date()
        lastIntegrityResult = result
        return result
    }

    private func dylibURL() -> URL? {
        let standard = Bundle.main.bundleURL
            .appendingPathComponent("Frameworks", isDirectory: true)
            .appendingPathComponent("CanvaCore.dylib", isDirectory: false)

        if FileManager.default.fileExists(atPath: standard.path) {
            return standard
        }

        let fallback = Bundle.main.bundleURL.appendingPathComponent("CanvaCore.dylib")
        if FileManager.default.fileExists(atPath: fallback.path) {
            return fallback
        }
        return nil
    }

    private func verifyHash(url: URL) -> Bool {
        guard let data = try? Data(contentsOf: url, options: [.mappedIfSafe]),
              data.count >= Self.textRange.upperBound,
              data.count >= Self.cstringRange.upperBound else { return false }

        var protectedBytes = Data()
        protectedBytes.append(data.subdata(in: Self.textRange))
        protectedBytes.append(data.subdata(in: Self.cstringRange))

        let digest = SHA256.hash(data: protectedBytes).map { String(format: "%02x", $0) }.joined()
        return constantTimeEqual(digest, Self.expectedIntegritySHA256)
    }

    private func hasSuspiciousLoaderEnvironment() -> Bool {
        let environment = ProcessInfo.processInfo.environment
        let blocked = [
            "DYLD_INSERT_LIBRARIES",
            "DYLD_LIBRARY_PATH",
            "DYLD_FRAMEWORK_PATH",
            "DYLD_FALLBACK_LIBRARY_PATH"
        ]
        return blocked.contains { key in
            guard let value = environment[key] else { return false }
            return !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        }
    }

    private func constantTimeEqual(_ lhs: String, _ rhs: String) -> Bool {
        let a = Array(lhs.utf8)
        let b = Array(rhs.utf8)
        guard a.count == b.count else { return false }
        var diff: UInt8 = 0
        for i in a.indices { diff |= a[i] ^ b[i] }
        return diff == 0
    }
}

final class AuthProtection: ObservableObject {
    static let shared = AuthProtection()

    enum State: Equatable {
        case checking
        case waitingForAuth
        case authorized
        case denied(String)
    }

    @Published private(set) var state: State = .checking
    @Published private(set) var licenseKey: String?
    @Published private(set) var expiresAt: Date?
    @Published private(set) var lastValidation: Date?

    private var pollTimer: Timer?
    private var refreshInProgress = false

    private init() {}

    var isAuthorized: Bool {
        if case .authorized = state { return true }
        return false
    }

    var displayedKey: String {
        licenseKey ?? "–"
    }

    var expirationDisplay: String {
        guard let expiresAt else {
            return isAuthorized ? "Sem expiração" : "–"
        }

        let seconds = Int(expiresAt.timeIntervalSinceNow)
        guard seconds > 0 else { return "Expirada" }

        let days = seconds / 86_400
        let hours = (seconds % 86_400) / 3_600
        let minutes = (seconds % 3_600) / 60

        if days > 0 { return "\(days)d \(hours)h \(minutes)min" }
        if hours > 0 { return "\(hours)h \(minutes)min" }
        return "\(max(minutes, 1))min"
    }

    var lockMessage: String {
        switch state {
        case .checking:
            return "Verificando autenticação…"
        case .waitingForAuth:
            return "Faça a autenticação pela External Auth para liberar o aplicativo."
        case .authorized:
            return ""
        case .denied(let reason):
            return reason
        }
    }

    @MainActor
    func bootstrap() async {
        guard AuthDylibLoader.shared.loadAndVerify() else {
            deny(AuthDylibLoader.shared.lastError ?? "External Auth obrigatória não carregou.")
            startPolling()
            return
        }

        startPolling()
        _ = await refresh(forceRemote: true)
    }

    @MainActor
    func appBecameActive() async {
        guard AuthDylibLoader.shared.loadAndVerify() else {
            deny(AuthDylibLoader.shared.lastError ?? "External Auth indisponível.")
            return
        }
        _ = await refresh(forceRemote: true)
    }

    @MainActor
    func permit(for action: ProtectedAction) async -> ActionPermit? {
        // IMPORTANT: protected UI actions must never wait for the network.
        // Remote validation already runs at bootstrap, when the app becomes active
        // and from the polling loop. Here we only use the already-open runtime gate,
        // so tabs/switches respond immediately while still failing closed.
        guard AuthDylibLoader.shared.verifyIntegrity() else {
            deny("Proteção da External Auth inválida.")
            return nil
        }

        guard isAuthorized,
              let permit = AuthRuntimeGate.shared.makePermit(for: action),
              AuthRuntimeGate.shared.validate(permit, for: action) else {
            return nil
        }

        // Keep the server state fresh without putting latency on the user's tap.
        if lastValidation == nil || Date().timeIntervalSince(lastValidation!) >= 20 {
            Task { @MainActor [weak self] in
                guard let self else { return }
                _ = await self.refresh(forceRemote: true)
            }
        }

        return permit
    }

    @MainActor
    @discardableResult
    func refresh(forceRemote: Bool) async -> Bool {
        if !forceRemote,
           isAuthorized,
           let lastValidation,
           Date().timeIntervalSince(lastValidation) < 25 {
            return true
        }

        if refreshInProgress { return false }
        refreshInProgress = true
        defer { refreshInProgress = false }

        guard AuthDylibLoader.shared.verifyIntegrity() || AuthDylibLoader.shared.loadAndVerify() else {
            deny(AuthDylibLoader.shared.lastError ?? "External Auth obrigatória não encontrada.")
            return false
        }

        guard let key = KeychainReader.read(service: KeychainReader.service, account: KeychainReader.keyAccount),
              !key.isEmpty,
              let deviceToken = KeychainReader.read(service: KeychainReader.service, account: KeychainReader.deviceTokenAccount),
              !deviceToken.isEmpty else {
            AuthRuntimeGate.shared.close()
            licenseKey = nil
            expiresAt = nil
            state = .waitingForAuth
            return false
        }

        do {
            let response = try await AuthAPI.check(key: key, deviceToken: deviceToken)
            guard response.status.lowercased() == "active" else {
                deny("Key sem status ativo.")
                return false
            }
            guard response.key == key else {
                deny("Key retornada pela API não corresponde à autenticação local.")
                return false
            }

            let expiration = response.expiresAt.flatMap(AuthAPI.parseDate)
            if let expiration, expiration <= Date() {
                deny("A key expirou.")
                return false
            }

            if response.pausedAt != nil {
                deny("A key está pausada.")
                return false
            }

            licenseKey = key
            expiresAt = expiration
            lastValidation = Date()
            AuthRuntimeGate.shared.open(key: key, deviceToken: deviceToken, expiresAt: expiration)
            state = .authorized
            return true
        } catch {
            deny("Falha ao validar a key na API. Conexão online obrigatória.")
            return false
        }
    }

    @MainActor
    private func deny(_ reason: String) {
        AuthRuntimeGate.shared.close()
        licenseKey = nil
        expiresAt = nil
        state = .denied(reason)
    }

    @MainActor
    private func startPolling() {
        guard pollTimer == nil else { return }
        pollTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            guard let self else { return }
            Task { @MainActor in
                _ = await self.refresh(forceRemote: false)
            }
        }
    }

    static func validatePermit(_ permit: ActionPermit, for action: ProtectedAction) -> Bool {
        guard AuthDylibLoader.shared.verifyIntegrity() else { return false }
        return AuthRuntimeGate.shared.validate(permit, for: action)
    }

    static func runtimeAccessAllowed() -> Bool {
        guard AuthDylibLoader.shared.verifyIntegrity() else { return false }
        return AuthRuntimeGate.shared.isOpen()
    }
}

private enum KeychainReader {
    static let service = "app.external.auth"
    static let keyAccount = "license-key"
    static let deviceTokenAccount = "device-token-v3"

    static func read(service: String, account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]

        var result: CFTypeRef?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        guard status == errSecSuccess,
              let data = result as? Data,
              let value = String(data: data, encoding: .utf8) else { return nil }
        return value
    }
}

private enum AuthAPI {
    struct CheckResponse: Decodable {
        let key: String
        let status: String
        let activatedAt: String?
        let expiresAt: String?
        let pausedAt: String?
        let remainingMS: Double?

        enum CodingKeys: String, CodingKey {
            case key
            case status
            case activatedAt = "activated_at"
            case expiresAt = "expires_at"
            case pausedAt = "paused_at"
            case remainingMS = "remaining_ms"
        }
    }

    static func check(key: String, deviceToken: String) async throws -> CheckResponse {
        let scheme = "https"
        let host = ["externalconfig", "shardweb", "app"].joined(separator: ".")
        guard let url = URL(string: "\(scheme)://\(host)/api/keys/check"),
              url.host == host,
              url.scheme == scheme else {
            throw URLError(.badURL)
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.timeoutInterval = 12
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try JSONSerialization.data(withJSONObject: [
            "key": key,
            "device_token": deviceToken
        ])

        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 12
        configuration.timeoutIntervalForResource = 15
        let session = URLSession(configuration: configuration)

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse,
              (200...299).contains(http.statusCode) else {
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode(CheckResponse.self, from: data)
    }

    static func parseDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }

        let standard = ISO8601DateFormatter()
        standard.formatOptions = [.withInternetDateTime]
        return standard.date(from: value)
    }
}
