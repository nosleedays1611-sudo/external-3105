import SwiftUI
import UIKit
import ImageIO

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.appLanguage) private var language
    @EnvironmentObject private var appState: AppState
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @AppStorage("external.darkMode") private var darkMode = true

    private var isPT: Bool { languageCode == AppLanguage.portugueseBrazil.rawValue }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 27) {
                    RealmGIFBanner()
                        .frame(maxWidth: .infinity)
                        .frame(height: 118)
                        .background(Color.black)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .overlay(
                            RoundedRectangle(cornerRadius: 18)
                                .stroke(Color(red: 0.58, green: 0.78, blue: 0.98).opacity(0.75), lineWidth: 1.2)
                        )

                    settingHeader(isPT ? "Idioma" : "Language")
                    Picker(isPT ? "Idioma" : "Language", selection: $languageCode) {
                        ForEach(AppLanguage.allCases) { option in
                            Text(option.displayName).tag(option.rawValue)
                        }
                    }
                    .pickerStyle(.segmented)
                    .labelsHidden()

                    settingHeader(isPT ? "Dispositivo" : "Device")
                    compactRow(isPT ? "Modelo de hardware" : "Hardware model", AppInfo.displayMachineName)
                    compactRow(isPT ? "Versão do iOS" : "iOS Version", AppInfo.osVersion)

                    settingHeader(isPT ? "Versões verificadas" : "Verified versions")
                    HStack {
                        Text(isPT ? "Versão atual" : "Current version")
                        Spacer()
                        Image(systemName: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? .green : .red)
                        Text(appState.isSupported
                             ? (isPT ? "Suportado" : "Supported")
                             : (isPT ? "Não suportado" : "Unsupported"))
                            .foregroundStyle(appState.isSupported ? .green : .red)
                    }

                    compactRow("iOS 26", ExploitSupportPolicy.verifiedIOS26Range)

                    VStack(alignment: .leading, spacing: 10) {
                        Text("iOS 27.0")
                        ForEach(ExploitSupportPolicy.verifiedIOS27Builds, id: \.build) { v in
                            Text("\(isPT ? "Beta" : "Beta") \(v.beta)  ·  \(v.build)")
                                .font(.system(size: 13, design: .monospaced))
                                .foregroundStyle(.secondary)
                        }
                    }

                    Text(isPT
                         ? "Somente as builds listadas acima estão habilitadas. Builds mais novas podem aparecer como não suportadas."
                         : "Only the builds listed above are enabled. Newer builds may be marked unsupported.")
                        .font(.system(size: 13))
                        .foregroundStyle(.secondary)

                    settingHeader(isPT ? "Créditos" : "Credits")
                    Link(destination: URL(string: "https://discord.gg/realmproxys")!) {
                        HStack {
                            Text("Realm").font(.headline)
                            Spacer()
                            Image(systemName: "arrow.up.right")
                        }
                        .foregroundStyle(Color(red: 0.58, green: 0.78, blue: 0.98))
                        .frame(minHeight: 44)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(.horizontal, 34)
                .padding(.top, 36)
                .padding(.bottom, 44)
            }
            .background(Color.black.ignoresSafeArea())
            .navigationTitle(isPT ? "Ajustes" : "Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(isPT ? "Concluído" : "Done") { dismiss() }
                        .fontWeight(.semibold)
                        .foregroundStyle(Color(red: 0.58, green: 0.78, blue: 0.98))
                }
            }
            .tint(Color(red: 0.58, green: 0.78, blue: 0.98))
        }
        .environment(\.colorScheme, .dark)
        .preferredColorScheme(.dark)
    }

    private func settingHeader(_ s:String)->some View {
        Text(s).font(.system(size:16,weight:.semibold)).foregroundStyle(.secondary)
    }

    private func compactRow(_ a:String,_ b:String)->some View {
        HStack {
            Text(a)
            Spacer()
            Text(b).font(.system(size:15,design:.monospaced)).foregroundStyle(.secondary)
        }
        .font(.system(size:16))
        .frame(minHeight:36)
    }

    private var appVersion:String {
        Bundle.main.object(forInfoDictionaryKey:"AppReleaseDisplayVersion") as? String
        ?? Bundle.main.object(forInfoDictionaryKey:"CFBundleShortVersionString") as? String
        ?? "1.0"
    }
}

private struct RealmGIFBanner: UIViewRepresentable {
    func makeUIView(context: Context) -> UIView {
        let container = UIView()
        container.backgroundColor = .black
        container.clipsToBounds = true

        let imageView = UIImageView()
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.tag = 3105

        container.addSubview(imageView)
        NSLayoutConstraint.activate([
            imageView.leadingAnchor.constraint(equalTo: container.leadingAnchor),
            imageView.trailingAnchor.constraint(equalTo: container.trailingAnchor),
            imageView.topAnchor.constraint(equalTo: container.topAnchor),
            imageView.bottomAnchor.constraint(equalTo: container.bottomAnchor)
        ])

        load(into: imageView)
        return container
    }

    func updateUIView(_ uiView: UIView, context: Context) {
        guard let imageView = uiView.viewWithTag(3105) as? UIImageView else { return }
        if imageView.animationImages == nil || imageView.animationImages?.isEmpty == true {
            load(into: imageView)
        }
    }

    private func load(into imageView: UIImageView) {
        guard let data = EmbeddedResourceVault.data(named: "ui.realm.banner"),
              let source = CGImageSourceCreateWithData(data as CFData, nil) else {
            return
        }

        var frames: [UIImage] = []
        var totalDuration: Double = 0

        for index in 0..<CGImageSourceGetCount(source) {
            guard let cgImage = CGImageSourceCreateImageAtIndex(source, index, nil) else { continue }

            var frameDuration = 0.08
            if let properties = CGImageSourceCopyPropertiesAtIndex(source, index, nil) as? [CFString: Any],
               let gifProperties = properties[kCGImagePropertyGIFDictionary] as? [CFString: Any] {
                if let unclamped = gifProperties[kCGImagePropertyGIFUnclampedDelayTime] as? Double,
                   unclamped > 0 {
                    frameDuration = unclamped
                } else if let delay = gifProperties[kCGImagePropertyGIFDelayTime] as? Double,
                          delay > 0 {
                    frameDuration = delay
                }
            }

            frames.append(UIImage(cgImage: cgImage))
            totalDuration += frameDuration
        }

        guard !frames.isEmpty else { return }

        imageView.image = frames.first
        imageView.animationImages = frames
        imageView.animationDuration = max(totalDuration, 0.08 * Double(frames.count))
        imageView.animationRepeatCount = 0
        imageView.startAnimating()
    }
}
