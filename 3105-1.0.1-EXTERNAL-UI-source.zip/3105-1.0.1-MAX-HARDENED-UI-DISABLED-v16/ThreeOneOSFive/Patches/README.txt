PATCH VAULT INPUT

Esta pasta nao e copiada para a IPA.
O workflow gera ThreeOneOSFive/Generated/patchvault.bin e remove os .3105 crus da copia temporaria antes do build.

ARQUIVOS DAS OPCOES COM / SEM ANTENA

HS ALTO + PESCOCO
- SEM antena: hs-alto-neck-sem-antena.3105
- COM antena: hs-alto-neck-com-antena.3105

HS PESCOCO
- SEM antena: hs-neck-sem-antena.3105
- COM antena: hs-neck-com-antena.3105

As quatro senhas ficam no enum PatchSlots em ThreeOneOSFive/ContentView.swift.
"0" = patch sem senha.

FLUXO NA INTERFACE
1. Ligue o switch de HS ALTO + PESCOCO ou HS PESCOCO.
2. O app pergunta "Ativar antena?".
3. COM seleciona o arquivo *-com-antena.3105.
4. SEM seleciona o arquivo *-sem-antena.3105.
5. INJETAR usa somente a variante escolhida.
6. LOBBY restaura automaticamente o backup da variante que foi aplicada.
7. Enquanto existir um backup aplicado, o app impede trocar COM/SEM antes do LOBBY para evitar restaurar o arquivo errado.

Os demais patches continuam com o mesmo fluxo anterior.

REGRAS DE SELECAO V12
- Apenas um HS pode ficar selecionado por vez: HS ALTO + PESCOCO, HS PESCOCO ou HS PEITO.
- Ao escolher outro HS, o anterior e desligado. Se ele ja estiver injetado, o app restaura o backup antes de trocar.
- AIM BOT + ESP 4 DEDOS pode ser usado junto de um unico HS.
- HOLOGRAMA GUNS pode ser usado junto de um unico HS.
- AIM BOT + ESP 4 DEDOS e HOLOGRAMA GUNS nao podem ficar ligados juntos.
- MAGIC BULLET e 120/144 FPS ficam isolados: nao podem ser combinados com outro switch.
- Depois de LOBBY/restaurar com sucesso aparece: "Desinjetado com sucesso!".
