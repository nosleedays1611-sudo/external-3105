import SwiftUI

struct ContentView: View {
    @State private var tab = 0
    @AppStorage("external.darkMode") private var darkMode = true

    private var scheme: ColorScheme { darkMode ? .dark : .light }
    private var bg: Color { darkMode ? .black : Color(uiColor: .systemGroupedBackground) }
    private var primary: Color { darkMode ? .white : .black }
    private var secondary: Color { darkMode ? Color.white.opacity(0.50) : Color.black.opacity(0.50) }

    var body: some View {
        ZStack(alignment: .bottom) {
            bg.ignoresSafeArea()

            Group {
                if tab == 0 {
                    ExternalFunctionsView(darkMode: darkMode)
                } else if tab == 1 {
                    TexturasView(darkMode: darkMode)
                } else {
                    ConfigDashboardView(darkMode: $darkMode)
                }
            }
            .padding(.bottom, 72)

            HStack(spacing: 8) {
                BottomItem(icon: "house.fill", title: "Function", selected: tab == 0, darkMode: darkMode) { tab = 0 }
                BottomItem(icon: "figure.stand", title: "Texturas", selected: tab == 1, darkMode: darkMode) { tab = 1 }
                BottomItem(icon: "cube.fill", title: "Config", selected: tab == 2, darkMode: darkMode) { tab = 2 }
            }
            .padding(.horizontal, 22)
            .padding(.bottom, 8)
        }
        .environment(\.colorScheme, scheme)
        .preferredColorScheme(scheme)
    }
}

private struct PatchOption: Identifiable {
    let id: String
    let title: String
    let patchFile: String
    let patchPassword: String
}

private enum PatchSlots {
    // EDITE SOMENTE os nomes e senhas abaixo.
    // password = "0" significa SEM SENHA.
    static let aimAssist = "aim-assist.3105"
    static let aimAssistPassword = "0"

    static let aimBotEsp = "aim-bot-esp.3105"
    static let aimBotEspPassword = "0"

    static let hsAltoNeck = "hs-alto-neck.3105"
    static let hsAltoNeckPassword = "0"

    static let hsNeck = "hs-neck.3105"
    static let hsNeckPassword = "0"

    static let hsPeito = "hs-peito.3105"
    static let hsPeitoPassword = "0"

    static let magicBullet = "magic-bullet.3105"
    static let magicBulletPassword = "0"

    static let hologramaPreto = "holograma-preto.3105"
    static let hologramaPretoPassword = "0"
}

private struct ExternalFunctionsView: View {
    let darkMode: Bool
    @State private var game = 0
    @State private var enabled: Set<String> = []

    private let aimEsp = [
        PatchOption(id: "aim-assist", title: "AIM ASSIST", patchFile: PatchSlots.aimAssist, patchPassword: PatchSlots.aimAssistPassword),
        PatchOption(id: "aimbot-esp", title: "AIM BOT + ESP 3 DEDOS", patchFile: PatchSlots.aimBotEsp, patchPassword: PatchSlots.aimBotEspPassword)
    ]
    private let headshots = [
        PatchOption(id: "alto-pescoco", title: "HS ALTO + PESCOÇO", patchFile: PatchSlots.hsAltoNeck, patchPassword: PatchSlots.hsAltoNeckPassword),
        PatchOption(id: "pescoco", title: "HS PESCOÇO", patchFile: PatchSlots.hsNeck, patchPassword: PatchSlots.hsNeckPassword),
        PatchOption(id: "peito", title: "HS PEITO", patchFile: PatchSlots.hsPeito, patchPassword: PatchSlots.hsPeitoPassword),
        PatchOption(id: "magic-bullet", title: "MAGIC BULLET", patchFile: PatchSlots.magicBullet, patchPassword: PatchSlots.magicBulletPassword)
    ]
    private let holograms = [
        PatchOption(id: "holograma-preto", title: "HOLOGRAMA PRETO", patchFile: PatchSlots.hologramaPreto, patchPassword: PatchSlots.hologramaPretoPassword)
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Spacer().frame(height: 155)

                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { game = 0 }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { game = 1 }
                }

                SectionBlock(title: "AIM / ESP", rows: aimEsp, enabled: $enabled, darkMode: darkMode).padding(.top, 24)
                SectionBlock(title: "HEADSHOTS", rows: headshots, enabled: $enabled, darkMode: darkMode).padding(.top, 24)
                SectionBlock(title: "HOLOGRAMAS", rows: holograms, enabled: $enabled, darkMode: darkMode).padding(.top, 24)
                Spacer().frame(height: 75)
            }
            .padding(.horizontal, 22)
        }
    }
}

private struct GameButton: View {
    let title: String; let selected: Bool; let darkMode: Bool; let action: () -> Void
    init(_ title: String, selected: Bool, darkMode: Bool, action: @escaping () -> Void) {
        self.title=title; self.selected=selected; self.darkMode=darkMode; self.action=action
    }
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(darkMode ? .white : .black)
                .frame(maxWidth: .infinity).frame(height: 54)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(
                    selected ? Color(red:0.58,green:0.78,blue:0.98) :
                        (darkMode ? Color.white.opacity(0.25) : Color.black.opacity(0.20)), lineWidth: 1.5))
        }.buttonStyle(.plain)
    }
}

private struct SectionBlock: View {
    let title: String
    let rows: [PatchOption]
    @Binding var enabled: Set<String>
    let darkMode: Bool
    @State private var busy: Set<String> = []
    @State private var message: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 17) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(Color(red:0.60,green:0.77,blue:0.94))

            ForEach(rows) { row in
                HStack(spacing: 12) {
                    Text(row.title)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(darkMode ? .white : .black)

                    Spacer(minLength: 8)

                    if busy.contains(row.id) {
                        ProgressView().scaleEffect(0.85)
                    }

                    Toggle("", isOn: Binding(
                        get: { enabled.contains(row.id) },
                        set: { on in
                            guard !busy.contains(row.id) else { return }
                            busy.insert(row.id)

                            // Keep the visible switch in its previous state until
                            // the original 3105 Apply/Restore operation succeeds.
                            DispatchQueue.global(qos: .userInitiated).async {
                                let result = PatchSlotRunner.setEnabled(on, fileName: row.patchFile, configuredPassword: row.patchPassword)

                                DispatchQueue.main.async {
                                    busy.remove(row.id)
                                    switch result {
                                    case .success(let text):
                                        if on { enabled.insert(row.id) }
                                        else { enabled.remove(row.id) }
                                        message = text
                                    case .failure(let error):
                                        message = PatchSlotRunner.message(for: error)
                                    }
                                }
                            }
                        }
                    ))
                    .labelsHidden()
                    .scaleEffect(0.88)
                    .disabled(busy.contains(row.id))
                }
                .frame(minHeight: 36)
            }
        }
        .alert("3105", isPresented: Binding(
            get: { message != nil },
            set: { if !$0 { message = nil } }
        )) {
            Button("OK") { message = nil }
        } message: {
            Text(message ?? "")
        }
    }
}

private enum PatchSlotRunner {
    // Uses the SAME package decoder + DevicePatchService used by the original
    // project's Apply/Restore buttons. PatchTransaction therefore creates and
    // validates the original backup/journal before replacing files.
    static func setEnabled(_ enabled: Bool, fileName: String, configuredPassword: String) -> Result<String, Error> {
        do {
            let url = try bundledPatchURL(fileName: fileName)
            let data = try Data(contentsOf: url, options: [.mappedIfSafe])

            // "0" = package without password. Any other value is passed to the
            // same decoder used by the original 3105 password flow.
            let password: String? = configuredPassword == "0" ? nil : configuredPassword
            let decoded = try PatchPackageCodec.decode(data, password: password)

            if enabled {
                _ = try DevicePatchService.apply(project: decoded.project)
                return .success("Patch aplicado. Backup original criado.")
            } else {
                guard let receipt = DevicePatchService.latestReceipt(projectID: decoded.project.id) else {
                    throw PatchSlotError.noBackup
                }
                try DevicePatchService.restore(receipt: receipt)
                return .success("Backup restaurado. Arquivos originais recuperados.")
            }
        } catch {
            return .failure(error)
        }
    }

    static func message(for error: Error) -> String {
        if let slotError = error as? PatchSlotError {
            switch slotError {
            case .missingFile(let name):
                return "Arquivo não encontrado em Patches: \(name)"
            case .noBackup:
                return "Não existe backup aplicado para este patch."
            }
        }
        if let patchError = error as? PatchPackageError {
            return "Falha no patch: \(patchError.localizationKey)"
        }
        return "Falha: \(error.localizedDescription)"
    }

    private static func bundledPatchURL(fileName: String) throws -> URL {
        let fm = FileManager.default
        let expectedName = (fileName as NSString).lastPathComponent

        // 1) Exact path used by the GitHub workflow:
        // Payload/3105.app/Patches/<file>.3105
        if let bundleRoot = Bundle.main.resourceURL {
            let exact = bundleRoot
                .appendingPathComponent("Patches", isDirectory: true)
                .appendingPathComponent(expectedName, isDirectory: false)

            if fm.fileExists(atPath: exact.path) {
                return exact
            }

            // 2) Some packagers flatten resources into the .app root.
            let flat = bundleRoot.appendingPathComponent(expectedName, isDirectory: false)
            if fm.fileExists(atPath: flat.path) {
                return flat
            }

            // 3) Last fallback: recursively locate the exact filename anywhere
            // inside the installed application bundle.
            if let enumerator = fm.enumerator(
                at: bundleRoot,
                includingPropertiesForKeys: [.isRegularFileKey],
                options: [.skipsHiddenFiles, .skipsPackageDescendants]
            ) {
                for case let candidate as URL in enumerator {
                    if candidate.lastPathComponent == expectedName,
                       fm.fileExists(atPath: candidate.path) {
                        return candidate
                    }
                }
            }
        }

        // 4) Bundle API fallback.
        let ns = expectedName as NSString
        let resource = ns.deletingPathExtension
        let ext = ns.pathExtension.isEmpty ? "3105" : ns.pathExtension

        if let url = Bundle.main.url(
            forResource: resource,
            withExtension: ext,
            subdirectory: "Patches"
        ) ?? Bundle.main.url(forResource: resource, withExtension: ext) {
            return url
        }

        throw PatchSlotError.missingFile(expectedName)
    }

    private enum PatchSlotError: Error {
        case missingFile(String)
        case noBackup
    }
}

private struct TexturasView: View {
    let darkMode: Bool
    var body: some View {
        ZStack {
            (darkMode ? Color.black : Color(uiColor:.systemGroupedBackground)).ignoresSafeArea()
            Text("Em desenvolvimento pra nova atualização")
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(darkMode ? Color.white.opacity(0.62) : Color.black.opacity(0.55))
                .multilineTextAlignment(.center).padding(.horizontal, 34)
        }
    }
}

private struct ConfigDashboardView: View {
    @EnvironmentObject private var appState: AppState
    @Binding var darkMode: Bool
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            List {
                Section("CONTA") {
                    LabeledContent("Key", value: "–")
                    LabeledContent("Expira em", value: "–")
                    LabeledContent("Build", value: "10")
                    LabeledContent("Versão", value: "1.10")
                }
                Section {
                    LabeledContent("Phone", value: DeviceInfo.machine)
                    LabeledContent("Modelo de hardware", value: DeviceInfo.machine)
                    LabeledContent("Versão do iOS", value: UIDevice.current.systemVersion)
                    HStack {
                        Text("Compatibilidade"); Spacer()
                        Label(appState.isSupported ? "Suportado" : "Não suportado",
                              systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                } header: { Text("DISPOSITIVO") }
                footer: { Text("Verificado: iOS 26.0–26.6.1 e builds listados do iOS 27.") }

                Section("APARÊNCIA") {
                    Toggle(isOn: Binding(get: { darkMode }, set: { darkMode = $0 })) {
                        Label(darkMode ? "Modo escuro" : "Modo claro",
                              systemImage: darkMode ? "moon.fill" : "sun.max.fill")
                    }
                }
                Section("INSTALAÇÃO") {
                    Label("Certificado enterprise", systemImage: "checkmark.seal")
                }
            }
            .font(.system(size: 15))
            .navigationTitle("Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName:"gearshape") }
                }
            }
            .tint(Color(red:0.58,green:0.77,blue:0.94))
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(darkMode ? .dark : .light)
            }
        }
    }
}

private enum DeviceInfo {
    static var machine: String {
        var systemInfo = utsname(); uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }
}

private struct BottomItem: View {
    let icon:String; let title:String; let selected:Bool; let darkMode:Bool; let action:()->Void
    var body: some View {
        Button(action:action) {
            VStack(spacing:3) {
                Image(systemName:icon).font(.system(size:19))
                Text(title).font(.system(size:11.5))
            }
            .foregroundStyle(selected ? Color(red:0.58,green:0.77,blue:0.94) :
                                (darkMode ? Color.white.opacity(0.50) : Color.black.opacity(0.48)))
            .frame(maxWidth:.infinity).frame(height:56)
            .background(selected ? (darkMode ? Color.white.opacity(0.09) : Color.black.opacity(0.07)) : .clear,
                        in: RoundedRectangle(cornerRadius:24))
        }.buttonStyle(.plain)
    }
}
