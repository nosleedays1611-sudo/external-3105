PATCHES
Coloque os .3105 nesta pasta.

ContentView.swift > PatchSlots:
- nome do arquivo = nome exato do .3105
- Password = "0" para sem senha
- caso tenha senha, coloque a senha entre aspas.

Esta pasta é sincronizada pelo projeto Xcode e copiada para o bundle.
