import Foundation
import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var auth: AuthProtection
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab = 0
    @AppStorage("external.darkMode") private var darkMode = true

    private var scheme: ColorScheme { darkMode ? .dark : .light }
    private var bg: Color { darkMode ? .black : Color(uiColor: .systemGroupedBackground) }

    var body: some View {
        ZStack(alignment: .bottom) {
            bg.ignoresSafeArea()

            Group {
                if tab == 0 {
                    ExternalFunctionsView(darkMode: darkMode)
                } else if tab == 1 {
                    TexturasView(darkMode: darkMode)
                } else {
                    ConfigDashboardView(darkMode: $darkMode)
                }
            }
            .padding(.bottom, 72)

            HStack(spacing: 8) {
                BottomItem(icon: "house.fill", title: "Function", selected: tab == 0, darkMode: darkMode) { requestTab(0) }
                BottomItem(icon: "figure.stand", title: "Texturas", selected: tab == 1, darkMode: darkMode) { requestTab(1) }
                BottomItem(icon: "cube.fill", title: "Config", selected: tab == 2, darkMode: darkMode) { requestTab(2) }
            }
            .padding(.horizontal, 22)
            .padding(.bottom, 8)

            if !auth.isAuthorized {
                AuthLockOverlay(message: auth.lockMessage, darkMode: darkMode)
                    .zIndex(100)
            }
        }
        .environment(\.colorScheme, scheme)
        .preferredColorScheme(scheme)
        .task {
            await auth.bootstrap()
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { @MainActor in
                await auth.appBecameActive()
            }
        }
    }

    private func requestTab(_ newTab: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .tabNavigation),
                  AuthProtection.validatePermit(permit, for: .tabNavigation) else { return }
            tab = newTab
        }
    }
}

private struct AuthLockOverlay: View {
    let message: String
    let darkMode: Bool

    var body: some View {
        ZStack {
            (darkMode ? Color.black.opacity(0.96) : Color(uiColor: .systemBackground).opacity(0.96))
                .ignoresSafeArea()

            VStack(spacing: 14) {
                ProgressView()
                    .scaleEffect(1.05)
                Text("External Auth")
                    .font(.system(size: 19, weight: .semibold))
                Text(message)
                    .font(.system(size: 14))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
            }
        }
        .allowsHitTesting(true)
    }
}

private struct PatchOption: Identifiable {
    let id: String
    let title: String
    let subtitle: String?
    let patchFile: String
    let patchPassword: String
}

private enum PatchSlots {
    // EDITE SOMENTE os nomes e senhas abaixo.
    // password = "0" significa SEM SENHA.
    static let aimAssist = "aim-assist.3105"
    static let aimAssistPassword = "0"

    static let aimBotEsp = "aim-bot-esp.3105"
    static let aimBotEspPassword = "OG"

    static let hsAltoNeck = "hs-alto-neck.3105"
    static let hsAltoNeckPassword = "0"

    static let hsNeck = "hs-neck.3105"
    static let hsNeckPassword = "0"

    static let hsPeito = "hs-peito.3105"
    static let hsPeitoPassword = "0"

    static let magicBullet = "magic-bullet.3105"
    static let magicBulletPassword = "0"

    static let fps120144 = "120-144-fps.3105"
    static let fps120144Password = "0"

    static let hologramaPreto = "holograma-preto.3105"
    static let hologramaPretoPassword = "0"
}

private struct ExternalFunctionsView: View {
    @EnvironmentObject private var auth: AuthProtection
    let darkMode: Bool
    @State private var game = 0
    @State private var enabled: Set<String> = []
    @State private var successMessage = "Ativado com sucesso!"

    private let aimEsp = [
        PatchOption(id: "aimbot-esp", title: "AIM BOT + ESP 4 DEDOS", subtitle: nil, patchFile: PatchSlots.aimBotEsp, patchPassword: PatchSlots.aimBotEspPassword)
    ]
    private let headshots = [
        PatchOption(id: "alto-pescoco", title: "HS ALTO + PESCOÇO", subtitle: "no antena", patchFile: PatchSlots.hsAltoNeck, patchPassword: PatchSlots.hsAltoNeckPassword),
        PatchOption(id: "pescoco", title: "HS PESCOÇO", subtitle: "antena", patchFile: PatchSlots.hsNeck, patchPassword: PatchSlots.hsNeckPassword),
        PatchOption(id: "peito", title: "HS PEITO", subtitle: "antena", patchFile: PatchSlots.hsPeito, patchPassword: PatchSlots.hsPeitoPassword),
        PatchOption(id: "magic-bullet", title: "MAGIC BULLET", subtitle: "bala magica (off)", patchFile: PatchSlots.magicBullet, patchPassword: PatchSlots.magicBulletPassword),
        PatchOption(id: "120-144-fps", title: "120/144 FPS", subtitle: nil, patchFile: PatchSlots.fps120144, patchPassword: PatchSlots.fps120144Password)
    ]
    private let holograms = [
        PatchOption(id: "holograma-preto", title: "HOLOGRAMA GUNS", subtitle: "holograma nas armas", patchFile: PatchSlots.hologramaPreto, patchPassword: PatchSlots.hologramaPretoPassword)
    ]

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Spacer().frame(height: 155)

                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }

                if game == 0 {
                    SectionBlock(title: "AIM / ESP", rows: aimEsp, enabled: $enabled, darkMode: darkMode, manualControls: false).padding(.top, 24)
                    SectionBlock(title: "HEADSHOTS", rows: headshots, enabled: $enabled, darkMode: darkMode, manualControls: true).padding(.top, 24)
                    SectionBlock(title: "HOLOGRAMAS", rows: holograms, enabled: $enabled, darkMode: darkMode, manualControls: false).padding(.top, 24)
                    Spacer().frame(height: 75)
                } else {
                    VStack {
                        Spacer().frame(height: 125)
                        Text("Na próxima atualização da external :)")
                            .font(.system(size: 16, weight: .medium))
                            .foregroundStyle(darkMode ? Color.white.opacity(0.62) : Color.black.opacity(0.55))
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                        Spacer().frame(height: 160)
                    }
                }
            }
            .padding(.horizontal, 22)
        }
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            game = newGame
        }
    }
}

private struct GameButton: View {
    let title: String; let selected: Bool; let darkMode: Bool; let action: () -> Void
    init(_ title: String, selected: Bool, darkMode: Bool, action: @escaping () -> Void) {
        self.title=title; self.selected=selected; self.darkMode=darkMode; self.action=action
    }
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(darkMode ? .white : .black)
                .frame(maxWidth: .infinity).frame(height: 54)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(
                    selected ? Color(red:0.58,green:0.78,blue:0.98) :
                        (darkMode ? Color.white.opacity(0.25) : Color.black.opacity(0.20)), lineWidth: 1.5))
        }.buttonStyle(.plain)
    }
}

private struct SectionBlock: View {
    @EnvironmentObject private var auth: AuthProtection
    let title: String
    let rows: [PatchOption]
    @Binding var enabled: Set<String>
    let darkMode: Bool
    let manualControls: Bool

    @State private var busy: Set<String> = []
    @State private var successPresented = false
    @State private var errorMessage: String?

    var body: some View {
        VStack(alignment: .leading, spacing: 17) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(Color(red:0.60,green:0.77,blue:0.94))

            ForEach(rows) { row in
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(row.title)
                                .font(.system(size: 16, weight: .medium))
                                .foregroundStyle(darkMode ? .white : .black)

                            if let subtitle = row.subtitle, !subtitle.isEmpty {
                                Text(subtitle)
                                    .font(.system(size: 12.5, weight: .regular))
                                    .foregroundStyle(
                                        darkMode ? Color.white.opacity(0.46) : Color.black.opacity(0.46)
                                    )
                            }
                        }

                        Spacer(minLength: 8)

                        if busy.contains(row.id) {
                            ProgressView().scaleEffect(0.85)
                        }

                        Toggle("", isOn: Binding(
                            get: { enabled.contains(row.id) },
                            set: { on in
                                handleToggle(row: row, enabledState: on)
                            }
                        ))
                        .labelsHidden()
                        .scaleEffect(0.88)
                        .disabled(busy.contains(row.id))
                    }
                    .frame(minHeight: 36)

                    if manualControls && row.id != "120-144-fps" && enabled.contains(row.id) {
                        HStack(spacing: 12) {
                            actionCard("INJETAR (40%)") {
                                runManual(row: row, apply: true)
                            }
                            actionCard("LOBBY") {
                                runManual(row: row, apply: false)
                            }
                        }
                        .padding(.bottom, 4)
                    }
                }
            }
        }
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert("Canva", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
    }

    private func actionCard(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13.5, weight: .bold))
                .foregroundStyle(.black)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 11))
        }
        .buttonStyle(.plain)
    }

    private func handleToggle(row: PatchOption, enabledState: Bool) {
        guard !busy.contains(row.id) else { return }

        if manualControls && row.id != "120-144-fps" {
            Task { @MainActor in
                busy.insert(row.id)
                defer { busy.remove(row.id) }

                guard let permit = await auth.permit(for: .patchToggle),
                      AuthProtection.validatePermit(permit, for: .patchToggle) else {
                    errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                    return
                }

                if enabledState { enabled.insert(row.id) }
                else { enabled.remove(row.id) }
            }
        } else {
            run(row: row, enabledState: enabledState)
        }
    }

    private func run(row: PatchOption, enabledState: Bool) {
        guard !busy.contains(row.id) else { return }
        busy.insert(row.id)

        Task { @MainActor in
            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                busy.remove(row.id)
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(
                    enabledState,
                    fileName: row.patchFile,
                    configuredPassword: row.patchPassword,
                    permit: permit,
                    action: .patchToggle
                )
                DispatchQueue.main.async {
                    busy.remove(row.id)
                    switch result {
                    case .success:
                        if enabledState {
                            enabled.insert(row.id)
                            successMessage = row.id == "120-144-fps" ? "Ativado. Feche seu jogo e abra de novo." : "Ativado com sucesso!"
                            successPresented = true
                        }
                        else { enabled.remove(row.id) }
                    case .failure(let error):
                        errorMessage = PatchSlotRunner.message(for: error)
                    }
                }
            }
        }
    }

    private func runManual(row: PatchOption, apply: Bool) {
        guard !busy.contains(row.id) else { return }
        busy.insert(row.id)

        Task { @MainActor in
            let action: ProtectedAction = apply ? .patchApply : .patchRestore
            guard let permit = await auth.permit(for: action),
                  AuthProtection.validatePermit(permit, for: action) else {
                busy.remove(row.id)
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            DispatchQueue.global(qos: .userInitiated).async {
                let result = PatchSlotRunner.setEnabled(
                    apply,
                    fileName: row.patchFile,
                    configuredPassword: row.patchPassword,
                    permit: permit,
                    action: action
                )
                DispatchQueue.main.async {
                    busy.remove(row.id)
                    switch result {
                    case .success:
                        if apply {
                            successPresented = true
                        } else {
                            enabled.remove(row.id)
                        }
                    case .failure(let error):
                        errorMessage = PatchSlotRunner.message(for: error)
                    }
                }
            }
        }
    }

}

private enum PatchSlotRunner {
    // Uses the SAME package decoder + DevicePatchService used by the original
    // project's Apply/Restore buttons. PatchTransaction therefore creates and
    // validates the original backup/journal before replacing files.
    static func setEnabled(
        _ enabled: Bool,
        fileName: String,
        configuredPassword: String,
        permit: ActionPermit,
        action: ProtectedAction
    ) -> Result<String, Error> {
        do {
            guard AuthProtection.validatePermit(permit, for: action),
                  AuthDylibLoader.shared.verifyIntegrity() else {
                throw PatchSlotError.authorizationRequired
            }

            if enabled {
                let data: Data
                do {
                    data = try EmbeddedPatchVault.data(named: fileName)
                } catch EmbeddedPatchVaultError.missingPatch {
                    throw PatchSlotError.missingPatch
                }

                // "0" = package without password. Any other value is passed to the
                // same decoder used by the original 3105 password flow.
                let password: String? = configuredPassword == "0" ? nil : configuredPassword
                let decoded = try PatchPackageCodec.decode(data, password: password)

                // PatchTransaction creates + verifies every original backup before
                // it writes the first replacement byte. Persist the exact receipt
                // by UI slot so Restore never needs the patch package again.
                let receipt = try DevicePatchService.apply(project: decoded.project)
                PatchSlotBackupRegistry.save(receipt, for: fileName)
                return .success("Patch aplicado. Backup original criado.")
            } else {
                guard let receipt = PatchSlotBackupRegistry.receipt(for: fileName) else {
                    throw PatchSlotError.noBackup
                }
                try DevicePatchService.restore(receipt: receipt)
                PatchSlotBackupRegistry.remove(for: fileName)
                return .success("Backup restaurado. Arquivos originais recuperados.")
            }
        } catch {
            return .failure(error)
        }
    }

    static func message(for error: Error) -> String {
        if let slotError = error as? PatchSlotError {
            switch slotError {
            case .missingPatch:
                return "Patch não encontrado."
            case .noBackup:
                return "Backup não encontrado."
            case .authorizationRequired:
                return "Autenticação obrigatória."
            }
        }
        if let patchError = error as? PatchPackageError {
            switch patchError {
            case .restoreFailed:
                return "Falha ao restaurar backup."
            default:
                return "Falha ao aplicar patch."
            }
        }
        return "Operação não concluída."
    }


    private enum PatchSlotError: Error {
        case missingPatch
        case noBackup
        case authorizationRequired
    }
}

private enum PatchSlotBackupRegistry {
    private struct Entry: Codable {
        let transactionID: UUID
        let projectID: UUID
    }

    private static let defaultsKey = "external.patch.slot.backups.v1"

    static func save(_ receipt: PatchTransactionReceipt, for slot: String) {
        var entries = load()
        entries[slot] = Entry(
            transactionID: receipt.id,
            projectID: receipt.projectID
        )
        persist(entries)
    }

    static func receipt(for slot: String) -> PatchTransactionReceipt? {
        var entries = load()
        guard let entry = entries[slot],
              let backupRoot = try? PatchProjectLibrary.backupRootURL() else {
            return nil
        }

        let journalURL = backupRoot
            .appendingPathComponent(entry.projectID.uuidString, isDirectory: true)
            .appendingPathComponent(entry.transactionID.uuidString, isDirectory: true)
            .appendingPathComponent("journal.plist")

        guard FileManager.default.fileExists(atPath: journalURL.path) else {
            entries.removeValue(forKey: slot)
            persist(entries)
            return nil
        }

        return PatchTransactionReceipt(
            id: entry.transactionID,
            projectID: entry.projectID,
            journalURL: journalURL
        )
    }

    static func remove(for slot: String) {
        var entries = load()
        entries.removeValue(forKey: slot)
        persist(entries)
    }

    private static func load() -> [String: Entry] {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let entries = try? PropertyListDecoder().decode([String: Entry].self, from: data) else {
            return [:]
        }
        return entries
    }

    private static func persist(_ entries: [String: Entry]) {
        if entries.isEmpty {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            return
        }
        guard let data = try? PropertyListEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: defaultsKey)
    }
}

private struct TexturasView: View {
    let darkMode: Bool
    var body: some View {
        ZStack {
            (darkMode ? Color.black : Color(uiColor:.systemGroupedBackground)).ignoresSafeArea()
            Text("Em desenvolvimento pra nova atualização")
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(darkMode ? Color.white.opacity(0.62) : Color.black.opacity(0.55))
                .multilineTextAlignment(.center).padding(.horizontal, 34)
        }
    }
}

private struct ConfigDashboardView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var auth: AuthProtection
    @Binding var darkMode: Bool
    @State private var showSettings = false

    var body: some View {
        NavigationStack {
            List {
                Section("CONTA") {
                    LabeledContent("Key", value: auth.displayedKey)
                    LabeledContent("Expira em", value: auth.expirationDisplay)
                    LabeledContent("Build", value: "10")
                    LabeledContent("Versão", value: "1.10")
                }
                Section {
                    LabeledContent("Phone", value: DeviceInfo.machine)
                    LabeledContent("Modelo de hardware", value: DeviceInfo.machine)
                    LabeledContent("Versão do iOS", value: UIDevice.current.systemVersion)
                    HStack {
                        Text("Compatibilidade"); Spacer()
                        Label(appState.isSupported ? "Suportado" : "Não suportado",
                              systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                } header: { Text("DISPOSITIVO") }
                footer: { Text("Verificado: iOS 26.0–26.6.1 e builds listados do iOS 27.") }

                Section("APARÊNCIA") {
                    Toggle(isOn: Binding(get: { darkMode }, set: { darkMode = $0 })) {
                        Label(darkMode ? "Modo escuro" : "Modo claro",
                              systemImage: darkMode ? "moon.fill" : "sun.max.fill")
                    }
                }
                Section("INSTALAÇÃO") {
                    Label("Certificado enterprise", systemImage: "checkmark.seal")
                }
            }
            .font(.system(size: 15))
            .navigationTitle("Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName:"gearshape") }
                }
            }
            .tint(Color(red:0.58,green:0.77,blue:0.94))
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(darkMode ? .dark : .light)
            }
        }
    }
}

private enum DeviceInfo {
    static var machine: String {
        var systemInfo = utsname(); uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }
}

private struct BottomItem: View {
    let icon:String; let title:String; let selected:Bool; let darkMode:Bool; let action:()->Void
    var body: some View {
        Button(action:action) {
            VStack(spacing:3) {
                Image(systemName:icon).font(.system(size:19))
                Text(title).font(.system(size:11.5))
            }
            .foregroundStyle(selected ? Color(red:0.58,green:0.77,blue:0.94) :
                                (darkMode ? Color.white.opacity(0.50) : Color.black.opacity(0.48)))
            .frame(maxWidth:.infinity).frame(height:56)
            .background(selected ? (darkMode ? Color.white.opacity(0.09) : Color.black.opacity(0.07)) : .clear,
                        in: RoundedRectangle(cornerRadius:24))
        }.buttonStyle(.plain)
    }
}
