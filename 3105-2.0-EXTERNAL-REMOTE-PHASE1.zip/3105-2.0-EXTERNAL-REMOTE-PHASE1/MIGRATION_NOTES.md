# EXTERNAL → 3105 2.0 — Phase 1

## Base

This package starts from the supplied `3105-2.0` source. The `exploit/` and `kexploit/` directories are preserved byte-for-byte from that source.

## Ported from V41

- `ExternalAuth.dylib`
- `AuthProtection.swift`
- `ExternalAuthRuntimeBridge.h/.m`
- V41 texture card assets
- EXTERNAL dark/light shell and bottom navigation
- Function / No Relog / Texturas / Config presentation

## Remote control implemented

`RemoteConfigStore` controls:

- tab `visible`
- tab `enabled`
- tab title/icon/order
- feature `visible`
- feature `enabled`
- feature title/subtitle/category/game/order
- revision and polling interval
- local cache when the server is unavailable

When a selected tab disappears remotely, the client automatically moves to the first remaining enabled tab.

## 3105 2.0 package flow

The new UI opens the native 3105 2.0 installed-patches manager for package operations, so the 2.0 `PatchProjectStore`, `PatchPackageCodec`, `DevicePatchService` and restore transaction flow remain the source of truth.

The included backend intentionally controls configuration and availability only; it does not push `.3105` payload bytes directly into the patch engine. Package import/update remains through the 3105 2.0 repository/import path.

## Connect the app to the server

Set `ExternalRemoteConfigURL` in `ThreeOneOSFive/Info.plist` to your HTTPS endpoint:

`https://YOUR-DOMAIN/api/config`

The field is left blank in the delivered source because no deployment domain was supplied in this turn.

## Server

`server/` is dependency-free Node.js. Set `ADMIN_TOKEN` and start `node server.js`. Open `/` for the admin panel.
