import Foundation
import SwiftUI
import UIKit

struct RemoteExternalConfig: Codable, Equatable {
    var schema: Int
    var revision: Int
    var pollIntervalSeconds: Int
    var tabs: [RemoteTabConfig]
    var features: [RemoteFeatureConfig]
}

struct RemoteTabConfig: Codable, Identifiable, Equatable {
    let id: String
    var title: String
    var icon: String
    var visible: Bool
    var enabled: Bool
    var order: Int
}

struct RemoteFeatureConfig: Codable, Identifiable, Equatable {
    let id: String
    var tabID: String
    var title: String
    var subtitle: String?
    var category: String
    var game: String
    var imageName: String?
    var visible: Bool
    var enabled: Bool
    var order: Int
    var packageIdentifier: String?
}

@MainActor
final class RemoteConfigStore: ObservableObject {
    @Published private(set) var config: RemoteExternalConfig = .externalDefault
    @Published private(set) var isRefreshing = false
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var lastError: String?

    private var bootstrapped = false
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    var visibleTabs: [RemoteTabConfig] {
        config.tabs
            .filter(\.visible)
            .sorted { lhs, rhs in
                if lhs.order != rhs.order { return lhs.order < rhs.order }
                return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
            }
    }

    var pollIntervalSeconds: Int {
        min(max(config.pollIntervalSeconds, 15), 3600)
    }

    func features(tabID: String, game: String? = nil) -> [RemoteFeatureConfig] {
        config.features
            .filter { feature in
                guard feature.visible, feature.tabID == tabID else { return false }
                guard let game else { return true }
                return feature.game == "all" || feature.game == game
            }
            .sorted { lhs, rhs in
                if lhs.order != rhs.order { return lhs.order < rhs.order }
                return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
            }
    }

    func bootstrap() async {
        guard !bootstrapped else { return }
        bootstrapped = true
        loadCachedConfig()
        await refresh()
    }

    func refresh() async {
        guard !isRefreshing else { return }
        guard let url = endpointURL else {
            lastError = nil
            return
        }

        isRefreshing = true
        defer { isRefreshing = false }

        do {
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.timeoutInterval = 12
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            request.setValue("application/json", forHTTPHeaderField: "Accept")

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode) else {
                throw RemoteConfigError.invalidResponse
            }
            guard data.count <= 2 * 1_024 * 1_024 else {
                throw RemoteConfigError.payloadTooLarge
            }

            let incoming = try decoder.decode(RemoteExternalConfig.self, from: data)
            try validate(incoming)

            if incoming.revision >= config.revision {
                config = incoming
                persist(incoming)
                lastUpdated = Date()
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    private var endpointURL: URL? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "ExternalRemoteConfigURL") as? String else {
            return nil
        }
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              let url = URL(string: trimmed),
              url.scheme?.lowercased() == "https",
              url.host != nil else {
            return nil
        }
        return url
    }

    private var cacheURL: URL? {
        guard let directory = try? FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        ) else { return nil }
        return directory.appendingPathComponent("external-remote-config.json", isDirectory: false)
    }

    private func loadCachedConfig() {
        guard let url = cacheURL,
              let data = try? Data(contentsOf: url),
              let cached = try? decoder.decode(RemoteExternalConfig.self, from: data),
              (try? validate(cached)) != nil else {
            return
        }
        config = cached
        if let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
           let date = attributes[.modificationDate] as? Date {
            lastUpdated = date
        }
    }

    private func persist(_ config: RemoteExternalConfig) {
        guard let url = cacheURL,
              let data = try? encoder.encode(config) else { return }
        try? data.write(to: url, options: [.atomic])
    }

    private func validate(_ config: RemoteExternalConfig) throws {
        guard config.schema == 1,
              config.revision >= 0,
              config.tabs.count <= 32,
              config.features.count <= 512 else {
            throw RemoteConfigError.invalidConfig
        }

        let tabIDs = config.tabs.map(\.id)
        guard Set(tabIDs).count == tabIDs.count,
              tabIDs.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) else {
            throw RemoteConfigError.invalidConfig
        }

        let featureIDs = config.features.map(\.id)
        guard Set(featureIDs).count == featureIDs.count,
              config.features.allSatisfy({ tabIDs.contains($0.tabID) }) else {
            throw RemoteConfigError.invalidConfig
        }
    }
}

private enum RemoteConfigError: LocalizedError {
    case invalidResponse
    case payloadTooLarge
    case invalidConfig

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Resposta inválida do servidor remoto."
        case .payloadTooLarge: return "Configuração remota acima do limite permitido."
        case .invalidConfig: return "Configuração remota inválida."
        }
    }
}

extension RemoteExternalConfig {
    static let externalDefault = RemoteExternalConfig(
        schema: 1,
        revision: 1,
        pollIntervalSeconds: 30,
        tabs: [
            RemoteTabConfig(id: "function", title: "Function", icon: "house.fill", visible: true, enabled: true, order: 10),
            RemoteTabConfig(id: "no-relog", title: "No Relog", icon: "arrow.triangle.2.circlepath", visible: true, enabled: true, order: 20),
            RemoteTabConfig(id: "textures", title: "Texturas", icon: "figure.stand", visible: true, enabled: true, order: 30),
            RemoteTabConfig(id: "config", title: "Config", icon: "cube.fill", visible: true, enabled: true, order: 40)
        ],
        features: [
            RemoteFeatureConfig(id: "aimbot-esp-normal", tabID: "function", title: "Aim Bot + Esp 4 Dedos", subtitle: nil, category: "AIM", game: "normal", imageName: nil, visible: true, enabled: true, order: 10, packageIdentifier: nil),
            RemoteFeatureConfig(id: "aim-silent-normal", tabID: "function", title: "Aim Silent + 4 Dedos", subtitle: nil, category: "AIM", game: "normal", imageName: nil, visible: true, enabled: true, order: 20, packageIdentifier: nil),
            RemoteFeatureConfig(id: "hs-alto-pescoco-normal", tabID: "function", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 30, packageIdentifier: nil),
            RemoteFeatureConfig(id: "hs-alto-normal", tabID: "function", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 40, packageIdentifier: nil),
            RemoteFeatureConfig(id: "hs-pescoco-normal", tabID: "function", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 50, packageIdentifier: nil),
            RemoteFeatureConfig(id: "hs-peito-normal", tabID: "function", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 60, packageIdentifier: nil),
            RemoteFeatureConfig(id: "magic-bullet-normal", tabID: "function", title: "Magic Bullet", subtitle: "Bala magica", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 70, packageIdentifier: nil),
            RemoteFeatureConfig(id: "fps-normal", tabID: "function", title: "120/144 FPS", subtitle: "Força 120/144 Fps o seu Jogo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 80, packageIdentifier: nil),
            RemoteFeatureConfig(id: "holograma-normal", tabID: "function", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "normal", imageName: nil, visible: true, enabled: true, order: 90, packageIdentifier: nil),

            RemoteFeatureConfig(id: "hs-alto-pescoco-max", tabID: "function", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 30, packageIdentifier: nil),
            RemoteFeatureConfig(id: "hs-pescoco-max", tabID: "function", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 50, packageIdentifier: nil),
            RemoteFeatureConfig(id: "hs-peito-max", tabID: "function", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 60, packageIdentifier: nil),
            RemoteFeatureConfig(id: "magic-bullet-max", tabID: "function", title: "Magic Bullet", subtitle: "Bala magica", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 70, packageIdentifier: nil),
            RemoteFeatureConfig(id: "fps-max", tabID: "function", title: "120/144 FPS", subtitle: "Força 120/144 Fps o seu Jogo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 80, packageIdentifier: nil),
            RemoteFeatureConfig(id: "holograma-max", tabID: "function", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "max", imageName: nil, visible: true, enabled: false, order: 90, packageIdentifier: nil),

            RemoteFeatureConfig(id: "nr-alto-pescoco-normal", tabID: "no-relog", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 10, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-alto-normal", tabID: "no-relog", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 20, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-pescoco-normal", tabID: "no-relog", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 30, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-peito-normal", tabID: "no-relog", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 40, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-caveira-normal", tabID: "no-relog", title: "Hs Caveira", subtitle: "Hs Caveira", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 50, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-holograma-normal", tabID: "no-relog", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "normal", imageName: nil, visible: true, enabled: true, order: 60, packageIdentifier: nil),

            RemoteFeatureConfig(id: "nr-alto-pescoco-max", tabID: "no-relog", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 10, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-alto-max", tabID: "no-relog", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 20, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-pescoco-max", tabID: "no-relog", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 30, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-peito-max", tabID: "no-relog", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 40, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-caveira-max", tabID: "no-relog", title: "Hs Caveira", subtitle: "Hs Caveira", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 50, packageIdentifier: nil),
            RemoteFeatureConfig(id: "nr-holograma-max", tabID: "no-relog", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "max", imageName: nil, visible: true, enabled: true, order: 60, packageIdentifier: nil),

            RemoteFeatureConfig(id: "texture-1-normal", tabID: "textures", title: "Textura 1", subtitle: "personagem: santino", category: "TEXTURAS", game: "normal", imageName: "Texture1Card", visible: true, enabled: true, order: 10, packageIdentifier: nil),
            RemoteFeatureConfig(id: "texture-2-normal", tabID: "textures", title: "Textura 2", subtitle: "personagem: santino", category: "TEXTURAS", game: "normal", imageName: "Texture2Card", visible: true, enabled: true, order: 20, packageIdentifier: nil),
            RemoteFeatureConfig(id: "texture-3-normal", tabID: "textures", title: "Textura 3", subtitle: "personagem: santino", category: "TEXTURAS", game: "normal", imageName: "Texture3Card", visible: true, enabled: true, order: 30, packageIdentifier: nil),
            RemoteFeatureConfig(id: "texture-4-normal", tabID: "textures", title: "Textura 4", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "normal", imageName: "Texture4Card", visible: true, enabled: true, order: 40, packageIdentifier: nil),
            RemoteFeatureConfig(id: "texture-5-normal", tabID: "textures", title: "Textura 5", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "normal", imageName: "Texture5Card", visible: true, enabled: true, order: 50, packageIdentifier: nil),
            RemoteFeatureConfig(id: "texture-4-max", tabID: "textures", title: "Textura 4", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "max", imageName: "Texture4Card", visible: true, enabled: true, order: 40, packageIdentifier: nil),
            RemoteFeatureConfig(id: "texture-5-max", tabID: "textures", title: "Textura 5", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "max", imageName: "Texture5Card", visible: true, enabled: true, order: 50, packageIdentifier: nil)
        ]
    )
}

struct ContentView: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var selectedTabID = "function"
    @AppStorage("external.darkMode") private var darkMode = true

    private var scheme: ColorScheme { darkMode ? .dark : .light }
    private var background: Color { darkMode ? .black : Color(uiColor: .systemGroupedBackground) }

    var body: some View {
        ZStack(alignment: .bottom) {
            background.ignoresSafeArea()

            tabContent(selectedTabID)
                .padding(.bottom, 72)
                .disabled(!auth.isAuthorized)
                .allowsHitTesting(auth.isAuthorized)

            if !remoteConfig.visibleTabs.isEmpty {
                HStack(spacing: 8) {
                    ForEach(remoteConfig.visibleTabs) { tab in
                        ExternalBottomItem(
                            icon: tab.icon,
                            title: tab.title,
                            selected: selectedTabID == tab.id,
                            darkMode: darkMode,
                            enabled: tab.enabled
                        ) {
                            requestTab(tab)
                        }
                    }
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 8)
                .disabled(!auth.isAuthorized)
                .allowsHitTesting(auth.isAuthorized)
            }

            if !auth.isAuthorized {
                AuthLockOverlay(
                    message: auth.lockMessage,
                    darkMode: darkMode,
                    showSpinner: auth.isChecking
                )
                .zIndex(100)
            }
        }
        .environment(\.colorScheme, scheme)
        .preferredColorScheme(scheme)
        .task {
            await auth.bootstrap()
            await remoteConfig.bootstrap()
            reconcileSelection()

            while !Task.isCancelled {
                let seconds = remoteConfig.pollIntervalSeconds
                try? await Task.sleep(nanoseconds: UInt64(seconds) * 1_000_000_000)
                guard !Task.isCancelled else { break }
                await remoteConfig.refresh()
                reconcileSelection()
            }
        }
        .onChange(of: remoteConfig.config.revision) { _ in
            reconcileSelection()
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { @MainActor in
                await auth.appBecameActive()
                await remoteConfig.refresh()
                reconcileSelection()
            }
        }
    }

    @ViewBuilder
    private func tabContent(_ tabID: String) -> some View {
        switch tabID {
        case "function":
            ExternalFeatureDashboard(tabID: "function", title: "Function", darkMode: darkMode)
        case "no-relog":
            ExternalFeatureDashboard(tabID: "no-relog", title: "No Relog", darkMode: darkMode)
        case "textures":
            ExternalTexturesDashboard(darkMode: darkMode)
        case "config":
            ExternalConfigDashboard(darkMode: $darkMode)
        default:
            ExternalFeatureDashboard(tabID: tabID, title: remoteConfig.visibleTabs.first(where: { $0.id == tabID })?.title ?? "External", darkMode: darkMode)
        }
    }

    private func requestTab(_ tab: RemoteTabConfig) {
        guard tab.enabled, tab.id != selectedTabID else { return }
        Task { @MainActor in
            guard let permit = await auth.permit(for: .tabNavigation),
                  AuthProtection.validatePermit(permit, for: .tabNavigation) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                selectedTabID = tab.id
            }
        }
    }

    private func reconcileSelection() {
        let visible = remoteConfig.visibleTabs
        guard let selected = visible.first(where: { $0.id == selectedTabID }), selected.enabled else {
            selectedTabID = visible.first(where: \.enabled)?.id ?? visible.first?.id ?? "config"
            return
        }
    }
}

private struct AuthLockOverlay: View {
    let message: String
    let darkMode: Bool
    let showSpinner: Bool

    var body: some View {
        ZStack {
            (darkMode ? Color.black.opacity(0.96) : Color(uiColor: .systemBackground).opacity(0.96))
                .ignoresSafeArea()

            VStack(spacing: 14) {
                if showSpinner {
                    ProgressView().scaleEffect(1.05)
                } else {
                    Image(systemName: "key.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(Color(red: 0.58, green: 0.77, blue: 0.94))
                }
                Text("External Auth")
                    .font(.system(size: 19, weight: .semibold))
                Text(message)
                    .font(.system(size: 14))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
            }
        }
        .allowsHitTesting(true)
    }
}

private struct ExternalFeatureDashboard: View {
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let tabID: String
    let title: String
    let darkMode: Bool

    @State private var game = "normal"
    @State private var showInstalled = false

    private var features: [RemoteFeatureConfig] {
        remoteConfig.features(tabID: tabID, game: game)
    }

    private var categories: [String] {
        var result: [String] = []
        for feature in features where !result.contains(feature.category) {
            result.append(feature.category)
        }
        return result
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 0) {
                Spacer().frame(height: 88)

                HStack(spacing: 12) {
                    ExternalGameButton("Free Fire Normal", selected: game == "normal", darkMode: darkMode) {
                        withAnimation(.easeOut(duration: 0.14)) { game = "normal" }
                    }
                    ExternalGameButton("Free Fire Max", selected: game == "max", darkMode: darkMode) {
                        withAnimation(.easeOut(duration: 0.14)) { game = "max" }
                    }
                }

                if features.isEmpty {
                    ExternalEmptyState(title: title, darkMode: darkMode)
                        .padding(.top, 26)
                } else {
                    ForEach(categories, id: \.self) { category in
                        VStack(alignment: .leading, spacing: 15) {
                            Text(category)
                                .font(.system(size: 14, weight: .bold))
                                .foregroundStyle(Color(red: 0.60, green: 0.77, blue: 0.94))

                            ForEach(features.filter { $0.category == category }) { feature in
                                ExternalFeatureRow(feature: feature, darkMode: darkMode) {
                                    guard feature.enabled else { return }
                                    showInstalled = true
                                }
                            }
                        }
                        .padding(.top, 24)
                    }
                }

                Spacer().frame(height: 88)
            }
            .padding(.horizontal, 22)
        }
        .background((darkMode ? Color.black : Color(uiColor: .systemGroupedBackground)).ignoresSafeArea())
        .sheet(isPresented: $showInstalled) {
            NavigationStack {
                PatchProjectsView(onOpenSettings: {}, onOpenLogs: {})
                    .navigationTitle("Patches 2.0")
                    .navigationBarTitleDisplayMode(.inline)
            }
            .preferredColorScheme(darkMode ? .dark : .light)
        }
    }
}

private struct ExternalFeatureRow: View {
    let feature: RemoteFeatureConfig
    let darkMode: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(feature.title)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(darkMode ? .white : .black)

                    if let subtitle = feature.subtitle, !subtitle.isEmpty {
                        Text(subtitle)
                            .font(.system(size: 12.5))
                            .foregroundStyle(darkMode ? Color.white.opacity(0.46) : Color.black.opacity(0.46))
                    }
                }

                Spacer(minLength: 8)

                if feature.enabled {
                    Image(systemName: "chevron.right")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(Color(red: 0.58, green: 0.77, blue: 0.94))
                } else {
                    Text("Indisponível")
                        .font(.system(size: 11.5, weight: .semibold))
                        .foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity, minHeight: 56)
            .background(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(darkMode ? Color.white.opacity(0.035) : Color.black.opacity(0.035))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(darkMode ? Color.white.opacity(0.10) : Color.black.opacity(0.08), lineWidth: 1)
            )
            .opacity(feature.enabled ? 1 : 0.38)
        }
        .buttonStyle(.plain)
        .disabled(!feature.enabled)
    }
}

private struct ExternalTexturesDashboard: View {
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let darkMode: Bool

    @State private var game = "normal"
    @State private var showInstalled = false

    private var textures: [RemoteFeatureConfig] {
        remoteConfig.features(tabID: "textures", game: game)
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                Spacer().frame(height: 88)

                HStack(spacing: 12) {
                    ExternalGameButton("Free Fire Normal", selected: game == "normal", darkMode: darkMode) {
                        withAnimation(.easeOut(duration: 0.14)) { game = "normal" }
                    }
                    ExternalGameButton("Free Fire Max", selected: game == "max", darkMode: darkMode) {
                        withAnimation(.easeOut(duration: 0.14)) { game = "max" }
                    }
                }
                .padding(.bottom, 5)

                Text("SELECIONE A TEXTURA")
                    .font(.system(size: 14, weight: .bold))
                    .tracking(1.6)
                    .foregroundStyle(Color(red: 0.60, green: 0.77, blue: 0.94))
                    .padding(.bottom, 3)

                ForEach(textures) { texture in
                    Button {
                        guard texture.enabled else { return }
                        showInstalled = true
                    } label: {
                        HStack(spacing: 16) {
                            if let imageName = texture.imageName, UIImage(named: imageName) != nil {
                                Image(imageName)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 82, height: 108)
                                    .padding(7)
                                    .background(Color.white.opacity(darkMode ? 0.96 : 1.0))
                                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            }

                            VStack(alignment: .leading, spacing: 5) {
                                Text(texture.title)
                                    .font(.system(size: 16, weight: .semibold))
                                    .foregroundStyle(darkMode ? Color.white : Color.black)
                                if let subtitle = texture.subtitle {
                                    Text(subtitle)
                                        .font(.system(size: 12.5))
                                        .foregroundStyle(darkMode ? Color.white.opacity(0.48) : Color.black.opacity(0.48))
                                }
                            }

                            Spacer(minLength: 8)

                            Image(systemName: texture.enabled ? "chevron.right" : "lock.fill")
                                .foregroundStyle(texture.enabled ? Color(red: 0.58, green: 0.77, blue: 0.94) : .secondary)
                        }
                        .padding(.horizontal, 15)
                        .padding(.vertical, 14)
                        .frame(maxWidth: .infinity, minHeight: 142)
                        .background {
                            RoundedRectangle(cornerRadius: 20, style: .continuous)
                                .fill(darkMode ? Color.white.opacity(0.012) : Color.black.opacity(0.018))
                        }
                        .overlay {
                            RoundedRectangle(cornerRadius: 20, style: .continuous)
                                .stroke(Color(red: 0.58, green: 0.78, blue: 0.98).opacity(0.95), lineWidth: 1.5)
                        }
                        .opacity(texture.enabled ? 1 : 0.38)
                    }
                    .buttonStyle(.plain)
                    .disabled(!texture.enabled)
                }

                Spacer().frame(height: 92)
            }
            .padding(.horizontal, 22)
        }
        .background((darkMode ? Color.black : Color(uiColor: .systemGroupedBackground)).ignoresSafeArea())
        .sheet(isPresented: $showInstalled) {
            NavigationStack {
                PatchProjectsView(onOpenSettings: {}, onOpenLogs: {})
                    .navigationTitle("Patches 2.0")
                    .navigationBarTitleDisplayMode(.inline)
            }
            .preferredColorScheme(darkMode ? .dark : .light)
        }
    }
}

private struct ExternalConfigDashboard: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    @Binding var darkMode: Bool
    @State private var showSettings = false
    @State private var showInstalled = false

    var body: some View {
        NavigationStack {
            List {
                Section("CONTA") {
                    HStack(spacing: 10) {
                        Text("Key")
                        Spacer(minLength: 12)
                        Text(auth.displayedKey)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)

                        Button {
                            guard auth.displayedKey != "–" else { return }
                            UIPasteboard.general.string = auth.displayedKey
                        } label: {
                            Image(systemName: "doc.on.doc")
                                .font(.system(size: 15, weight: .semibold))
                        }
                        .buttonStyle(.plain)
                        .disabled(auth.displayedKey == "–")
                    }

                    LabeledContent("Expira em", value: auth.expirationDisplay)
                    LabeledContent("Base", value: "3105 2.0")
                    LabeledContent("Remote revision", value: String(remoteConfig.config.revision))
                }

                Section("DISPOSITIVO") {
                    LabeledContent("Phone", value: ExternalDeviceInfo.machine)
                    LabeledContent("Modelo de hardware", value: ExternalDeviceInfo.machine)
                    LabeledContent("Versão do iOS", value: UIDevice.current.systemVersion)
                    HStack {
                        Text("Compatibilidade")
                        Spacer()
                        Label(
                            appState.isSupported ? "Suportado" : "Não suportado",
                            systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill"
                        )
                        .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                }

                Section("REMOTE") {
                    HStack {
                        Text("Status")
                        Spacer()
                        if remoteConfig.isRefreshing {
                            ProgressView().scaleEffect(0.8)
                        } else if remoteConfig.lastError == nil {
                            Label("Sincronizado", systemImage: "checkmark.circle.fill")
                                .foregroundStyle(.green)
                        } else {
                            Label("Cache local", systemImage: "exclamationmark.triangle.fill")
                                .foregroundStyle(.orange)
                        }
                    }

                    if let lastUpdated = remoteConfig.lastUpdated {
                        LabeledContent("Última atualização", value: lastUpdated.formatted(date: .abbreviated, time: .standard))
                    }

                    Button("Atualizar agora") {
                        Task { await remoteConfig.refresh() }
                    }

                    Button("Gerenciar patches 2.0") {
                        showInstalled = true
                    }
                }

                Section("APARÊNCIA") {
                    Toggle(isOn: Binding(get: { darkMode }, set: { darkMode = $0 })) {
                        Label(
                            darkMode ? "Modo escuro" : "Modo claro",
                            systemImage: darkMode ? "moon.fill" : "sun.max.fill"
                        )
                    }
                }

                Section("INSTALAÇÃO") {
                    Label("External Auth", systemImage: "checkmark.seal")
                    Label("Remote Config", systemImage: "network")
                    Label("3105 2.0 Core", systemImage: "shippingbox")
                }
            }
            .font(.system(size: 15))
            .navigationTitle("Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName: "gearshape") }
                }
            }
            .tint(Color(red: 0.58, green: 0.77, blue: 0.94))
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(darkMode ? .dark : .light)
            }
            .sheet(isPresented: $showInstalled) {
                NavigationStack {
                    PatchProjectsView(onOpenSettings: {}, onOpenLogs: {})
                        .navigationTitle("Patches 2.0")
                        .navigationBarTitleDisplayMode(.inline)
                }
                .preferredColorScheme(darkMode ? .dark : .light)
            }
        }
    }
}

private enum ExternalDeviceInfo {
    static var machine: String {
        var systemInfo = utsname()
        uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }
}

private struct ExternalGameButton: View {
    let title: String
    let selected: Bool
    let darkMode: Bool
    let action: () -> Void

    init(_ title: String, selected: Bool, darkMode: Bool, action: @escaping () -> Void) {
        self.title = title
        self.selected = selected
        self.darkMode = darkMode
        self.action = action
    }

    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(darkMode ? .white : .black)
                .frame(maxWidth: .infinity)
                .frame(height: 54)
                .overlay(
                    RoundedRectangle(cornerRadius: 14)
                        .stroke(
                            selected
                                ? Color(red: 0.58, green: 0.78, blue: 0.98)
                                : (darkMode ? Color.white.opacity(0.25) : Color.black.opacity(0.20)),
                            lineWidth: 1.5
                        )
                )
        }
        .buttonStyle(.plain)
    }
}

private struct ExternalEmptyState: View {
    let title: String
    let darkMode: Bool

    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "eye.slash")
                .font(.system(size: 28, weight: .semibold))
                .foregroundStyle(Color(red: 0.58, green: 0.77, blue: 0.94))
            Text("Nenhuma função disponível em \(title)")
                .font(.system(size: 14, weight: .medium))
                .foregroundStyle(darkMode ? Color.white.opacity(0.55) : Color.black.opacity(0.55))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 36)
    }
}

private struct ExternalBottomItem: View {
    let icon: String
    let title: String
    let selected: Bool
    let darkMode: Bool
    let enabled: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: icon).font(.system(size: 19))
                Text(title).font(.system(size: 11.5)).lineLimit(1)
            }
            .foregroundStyle(
                selected
                    ? Color(red: 0.58, green: 0.77, blue: 0.94)
                    : (darkMode ? Color.white.opacity(0.50) : Color.black.opacity(0.48))
            )
            .frame(maxWidth: .infinity)
            .frame(height: 56)
            .background(
                selected ? (darkMode ? Color.white.opacity(0.09) : Color.black.opacity(0.07)) : .clear,
                in: RoundedRectangle(cornerRadius: 24)
            )
            .opacity(enabled ? 1 : 0.30)
        }
        .buttonStyle(.plain)
        .disabled(!enabled)
        .animation(.easeOut(duration: 0.14), value: selected)
    }
}
