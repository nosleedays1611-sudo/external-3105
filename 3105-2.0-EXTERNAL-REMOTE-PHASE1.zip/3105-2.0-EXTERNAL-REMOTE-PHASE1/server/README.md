# EXTERNAL Remote Control

Servidor sem dependências externas para o controle remoto da interface da EXTERNAL.

## Variáveis

- `ADMIN_TOKEN`: token longo usado pelo painel administrativo.
- `PORT`: opcional; padrão `3000`.

## Rodar

```bash
ADMIN_TOKEN='troque-por-um-token-longo' node server.js
```

Abra `/` no navegador. O app iOS lê `GET /api/config`.

No `ThreeOneOSFive/Info.plist`, preencha `ExternalRemoteConfigURL` com a URL HTTPS pública, por exemplo `https://seu-dominio.com/api/config`.

## Semântica

- `visible=false`: a aba/função não é renderizada.
- `visible=true, enabled=false`: aparece, mas fica indisponível.
- `visible=true, enabled=true`: disponível.
- toda alteração administrativa incrementa `revision`.

O servidor deste pacote controla configuração, visibilidade e disponibilidade. A entrega/aplicação automática de payloads `.3105` não está conectada ao backend; o app mantém o fluxo de pacotes/importação da base 3105 2.0.
