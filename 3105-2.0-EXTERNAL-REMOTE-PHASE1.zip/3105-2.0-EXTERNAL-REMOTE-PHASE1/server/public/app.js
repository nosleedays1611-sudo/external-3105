let config = null;
const $ = id => document.getElementById(id);

function token() { return $('token').value.trim(); }
function headers(json = false) {
  return {
    Authorization: `Bearer ${token()}`,
    ...(json ? { 'Content-Type': 'application/json' } : {})
  };
}
function status(message, error = false) {
  $('status').textContent = message;
  $('status').style.borderColor = error ? '#6b2d35' : '#242b35';
}
async function api(url, options = {}) {
  const res = await fetch(url, { ...options, headers: { ...headers(Boolean(options.body)), ...(options.headers || {}) } });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(body.message || body.error || `HTTP ${res.status}`);
  return body;
}
async function load() {
  try {
    config = await api('/api/admin/config');
    localStorage.setItem('external.admin.token', token());
    render();
    status('Configuração carregada. Alterações salvas incrementam a revision automaticamente.');
  } catch (e) {
    status(`Erro: ${e.message}`, true);
  }
}
function field(label, value, type = 'text') {
  const row = document.createElement('div');
  row.className = 'row';
  const l = document.createElement('label'); l.textContent = label;
  const input = document.createElement('input'); input.type = type; input.value = value ?? '';
  row.append(l, input);
  return { row, input };
}
function toggle(label, checked) {
  const row = document.createElement('div'); row.className = 'row';
  const l = document.createElement('label'); l.textContent = label;
  const input = document.createElement('input'); input.type = 'checkbox'; input.className = 'switch'; input.checked = Boolean(checked);
  row.append(l, input); return { row, input };
}
function saveButton(handler) {
  const actions = document.createElement('div'); actions.className = 'actions';
  const button = document.createElement('button'); button.textContent = 'Salvar'; button.onclick = handler;
  actions.append(button); return actions;
}
function renderTabs() {
  $('tabs').replaceChildren();
  for (const tab of [...config.tabs].sort((a,b) => a.order-b.order)) {
    const card = document.createElement('div'); card.className = 'card';
    const h = document.createElement('h3'); h.textContent = tab.id; card.append(h);
    const title = field('Título', tab.title); card.append(title.row);
    const icon = field('SF Symbol', tab.icon); card.append(icon.row);
    const order = field('Ordem', tab.order, 'number'); card.append(order.row);
    const visible = toggle('Visível', tab.visible); card.append(visible.row);
    const enabled = toggle('Ativável', tab.enabled); card.append(enabled.row);
    card.append(saveButton(async () => {
      try {
        config = await api(`/api/admin/tabs/${encodeURIComponent(tab.id)}`, {
          method:'PATCH', body: JSON.stringify({ title:title.input.value, icon:icon.input.value, order:Number(order.input.value), visible:visible.input.checked, enabled:enabled.input.checked })
        });
        render(); status(`${tab.title}: salvo.`);
      } catch (e) { status(`Erro: ${e.message}`, true); }
    }));
    $('tabs').append(card);
  }
}
function renderFeatureFilter() {
  const select = $('featureTab');
  const prior = select.value;
  select.replaceChildren();
  for (const tab of config.tabs) {
    if (tab.id === 'config') continue;
    const opt = document.createElement('option'); opt.value = tab.id; opt.textContent = tab.title; select.append(opt);
  }
  if ([...select.options].some(o => o.value === prior)) select.value = prior;
  select.onchange = renderFeatures;
}
function renderFeatures() {
  const tabID = $('featureTab').value;
  $('features').replaceChildren();
  const list = config.features.filter(x => x.tabID === tabID).sort((a,b) => a.order-b.order);
  for (const feature of list) {
    const card = document.createElement('div'); card.className = 'card';
    const h = document.createElement('h3'); h.textContent = feature.title; card.append(h);
    const id = document.createElement('div'); id.className='muted'; id.textContent=feature.id; card.append(id);
    const title = field('Título', feature.title); card.append(title.row);
    const subtitle = field('Subtítulo', feature.subtitle || ''); card.append(subtitle.row);
    const category = field('Categoria', feature.category); card.append(category.row);
    const game = field('Game', feature.game); card.append(game.row);
    const order = field('Ordem', feature.order, 'number'); card.append(order.row);
    const visible = toggle('Visível', feature.visible); card.append(visible.row);
    const enabled = toggle('Ativável', feature.enabled); card.append(enabled.row);
    card.append(saveButton(async () => {
      try {
        config = await api(`/api/admin/features/${encodeURIComponent(feature.id)}`, {
          method:'PATCH', body: JSON.stringify({ title:title.input.value, subtitle:subtitle.input.value || null, category:category.input.value, game:game.input.value, order:Number(order.input.value), visible:visible.input.checked, enabled:enabled.input.checked })
        });
        render(); status(`${feature.title}: salvo.`);
      } catch (e) { status(`Erro: ${e.message}`, true); }
    }));
    $('features').append(card);
  }
}
function render() {
  $('revision').textContent = `revision ${config.revision}`;
  renderTabs(); renderFeatureFilter(); renderFeatures();
}
$('load').onclick = load;
$('token').value = localStorage.getItem('external.admin.token') || '';
