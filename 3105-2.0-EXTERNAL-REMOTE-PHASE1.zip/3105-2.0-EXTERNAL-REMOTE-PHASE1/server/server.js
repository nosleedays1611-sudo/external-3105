import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = String(process.env.ADMIN_TOKEN || '');
const DATA_DIR = path.join(__dirname, 'data');
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
const DEFAULT_CONFIG_PATH = path.join(__dirname, 'config.default.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const MAX_BODY = 512 * 1024;

if (!ADMIN_TOKEN || ADMIN_TOKEN.length < 16) {
  console.error('ADMIN_TOKEN precisa existir e ter pelo menos 16 caracteres.');
  process.exit(1);
}

fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(CONFIG_PATH)) {
  fs.copyFileSync(DEFAULT_CONFIG_PATH, CONFIG_PATH);
}

function readConfig() {
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
}

function writeConfig(config) {
  validateConfig(config);
  const temp = `${CONFIG_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(config, null, 2));
  fs.renameSync(temp, CONFIG_PATH);
}

function validateConfig(config) {
  if (!config || config.schema !== 1 || !Number.isInteger(config.revision) || config.revision < 0) {
    throw new Error('config inválida');
  }
  if (!Array.isArray(config.tabs) || config.tabs.length > 32) throw new Error('tabs inválidas');
  if (!Array.isArray(config.features) || config.features.length > 512) throw new Error('features inválidas');

  const tabIDs = new Set();
  for (const tab of config.tabs) {
    if (!tab || typeof tab.id !== 'string' || !tab.id.trim() || tabIDs.has(tab.id)) throw new Error('tab id inválido');
    tabIDs.add(tab.id);
    if (typeof tab.title !== 'string' || typeof tab.icon !== 'string') throw new Error('tab inválida');
    if (typeof tab.visible !== 'boolean' || typeof tab.enabled !== 'boolean') throw new Error('tab flags inválidas');
    if (!Number.isInteger(tab.order)) throw new Error('tab order inválido');
  }

  const featureIDs = new Set();
  for (const feature of config.features) {
    if (!feature || typeof feature.id !== 'string' || !feature.id.trim() || featureIDs.has(feature.id)) throw new Error('feature id inválido');
    featureIDs.add(feature.id);
    if (!tabIDs.has(feature.tabID)) throw new Error('feature tabID inválido');
    if (typeof feature.title !== 'string' || typeof feature.category !== 'string' || typeof feature.game !== 'string') throw new Error('feature inválida');
    if (typeof feature.visible !== 'boolean' || typeof feature.enabled !== 'boolean') throw new Error('feature flags inválidas');
    if (!Number.isInteger(feature.order)) throw new Error('feature order inválido');
  }
}

function json(res, status, body, publicConfig = false) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': data.length,
    'Cache-Control': 'no-store',
    ...(publicConfig ? { 'Access-Control-Allow-Origin': '*' } : {})
  });
  res.end(data);
}

function text(res, status, body, type = 'text/plain; charset=utf-8') {
  const data = Buffer.from(body);
  res.writeHead(status, {
    'Content-Type': type,
    'Content-Length': data.length,
    'Cache-Control': 'no-store'
  });
  res.end(data);
}

function authorized(req) {
  const header = String(req.headers.authorization || '');
  const supplied = header.startsWith('Bearer ') ? header.slice(7) : '';
  const expected = Buffer.from(ADMIN_TOKEN);
  const actual = Buffer.from(supplied);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

async function readJSON(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw new Error('body muito grande');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function applyAllowed(target, patch, fields) {
  for (const field of fields) {
    if (Object.prototype.hasOwnProperty.call(patch, field)) target[field] = patch[field];
  }
}

function increment(config) {
  config.revision += 1;
  config.updatedAt = new Date().toISOString();
  return config;
}

function serveStatic(req, res) {
  const requestPath = req.url === '/' ? '/index.html' : req.url;
  const clean = path.normalize(requestPath).replace(/^([.][.][/\\])+/, '');
  const full = path.join(PUBLIC_DIR, clean);
  if (!full.startsWith(PUBLIC_DIR) || !fs.existsSync(full) || fs.statSync(full).isDirectory()) return false;

  const ext = path.extname(full).toLowerCase();
  const types = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8'
  };
  text(res, 200, fs.readFileSync(full), types[ext] || 'application/octet-stream');
  return true;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, { ok: true, service: 'external-remote-control' });
    }

    if (req.method === 'GET' && url.pathname === '/api/config') {
      return json(res, 200, readConfig(), true);
    }

    if (url.pathname.startsWith('/api/admin/')) {
      if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });

      if (req.method === 'GET' && url.pathname === '/api/admin/config') {
        return json(res, 200, readConfig());
      }

      const tabMatch = url.pathname.match(/^\/api\/admin\/tabs\/([^/]+)$/);
      if (req.method === 'PATCH' && tabMatch) {
        const patch = await readJSON(req);
        const config = readConfig();
        const tab = config.tabs.find(x => x.id === decodeURIComponent(tabMatch[1]));
        if (!tab) return json(res, 404, { error: 'tab_not_found' });
        applyAllowed(tab, patch, ['title', 'icon', 'visible', 'enabled', 'order']);
        increment(config);
        writeConfig(config);
        return json(res, 200, config);
      }

      const featureMatch = url.pathname.match(/^\/api\/admin\/features\/([^/]+)$/);
      if (req.method === 'PATCH' && featureMatch) {
        const patch = await readJSON(req);
        const config = readConfig();
        const feature = config.features.find(x => x.id === decodeURIComponent(featureMatch[1]));
        if (!feature) return json(res, 404, { error: 'feature_not_found' });
        applyAllowed(feature, patch, [
          'title', 'subtitle', 'category', 'game', 'imageName',
          'visible', 'enabled', 'order', 'packageIdentifier'
        ]);
        increment(config);
        writeConfig(config);
        return json(res, 200, config);
      }

      if (req.method === 'PUT' && url.pathname === '/api/admin/config') {
        const incoming = await readJSON(req);
        const current = readConfig();
        incoming.schema = 1;
        incoming.revision = Math.max(Number(incoming.revision || 0), current.revision) + 1;
        incoming.updatedAt = new Date().toISOString();
        writeConfig(incoming);
        return json(res, 200, incoming);
      }

      return json(res, 404, { error: 'not_found' });
    }

    if (req.method === 'GET' && serveStatic(req, res)) return;
    return json(res, 404, { error: 'not_found' });
  } catch (error) {
    console.error(error);
    return json(res, 400, { error: 'bad_request', message: String(error.message || error) });
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`EXTERNAL Remote Control ouvindo na porta ${PORT}`);
});
