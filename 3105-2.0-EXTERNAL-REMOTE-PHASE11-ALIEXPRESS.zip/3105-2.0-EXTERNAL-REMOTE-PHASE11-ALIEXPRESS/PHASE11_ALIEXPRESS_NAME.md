# PHASE11 — Aliexpress display name

- CFBundleDisplayName changed from `EXTERNAL` to `Aliexpress`.
- Xcode build-setting override updated to `Aliexpress` in Debug and Release.
- Popup titles remain `External` as requested in PHASE10.
- No remote, patch, auth, Settings, icon, or engine behavior changed.
