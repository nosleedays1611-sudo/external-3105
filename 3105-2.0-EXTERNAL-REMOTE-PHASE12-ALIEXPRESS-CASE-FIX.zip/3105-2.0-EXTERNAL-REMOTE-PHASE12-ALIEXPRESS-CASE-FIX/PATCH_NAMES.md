# Nomes canônicos dos .3105

A PHASE4 volta a usar os mesmos nomes de arquivo definidos no `PatchSlots` da V41.

Os IDs internos abaixo continuam existindo somente para não quebrar o servidor/cache já publicado. No painel e no cache, use os nomes `.3105` da coluna **Arquivo V41**.

## FUNCTION / FREE FIRE NORMAL

| ID interno | Arquivo V41 | Senha padrão |
|---|---|---|
| `fn-normal-hs-alto-pescoco-sem` | `hs-alto-neck-sem-antena.3105` | `0` |
| `fn-normal-hs-alto-pescoco-com` | `hs-alto-neck-com-antena.3105` | `0` |
| `fn-normal-hs-alto-sem` | `hs-alto-sem-antena.3105` | `0` |
| `fn-normal-hs-alto-com` | `hs-alto.3105` | `0` |
| `fn-normal-hs-pescoco-sem` | `hs-neck-sem-antena.3105` | `0` |
| `fn-normal-hs-pescoco-com` | `hs-neck-com-antena.3105` | `0` |
| `fn-normal-hs-peito-sem` | `hs-peito-sem-antena.3105` | `0` |
| `fn-normal-hs-peito-com` | `hs-peito.3105` | `0` |
| `fn-normal-magic-bullet-sem` | `magic-bullet-sem-antena.3105` | `0` |
| `fn-normal-magic-bullet-com` | `magic-bullet-com-antena.3105` | `0` |
| `fn-normal-120-144-fps` | `120-144-fps.3105` | `OG` |
| `fn-normal-holograma` | `holograma-preto.3105` | `0` |

## FUNCTION / FREE FIRE MAX

| ID interno | Arquivo V41 | Senha padrão |
|---|---|---|
| `fn-max-hs-alto-pescoco-sem` | `hs-alto-neck-sem-antena-max.3105` | `0` |
| `fn-max-hs-alto-pescoco-com` | `hs-alto-neck-com-antena-max.3105` | `0` |
| `fn-max-hs-pescoco-sem` | `hs-neck-sem-antena-max.3105` | `0` |
| `fn-max-hs-pescoco-com` | `hs-neck-com-antena-max.3105` | `0` |
| `fn-max-hs-peito-sem` | `hs-peito-sem-antena-max.3105` | `0` |
| `fn-max-hs-peito-com` | `hs-peito-com-antena-max.3105` | `0` |
| `fn-max-magic-bullet-sem` | `magic-bullet-sem-antena-max.3105` | `0` |
| `fn-max-magic-bullet-com` | `magic-bullet-com-antena-max.3105` | `0` |
| `fn-max-120-144-fps` | `120-144-fps-max.3105` | `OG` |
| `fn-max-holograma` | `holograma-preto-max.3105` | `0` |

## NO RELOG / FREE FIRE NORMAL

| ID interno | Arquivo V41 | Senha padrão |
|---|---|---|
| `nr-normal-hs-alto-pescoco` | `hs-alto-neck-sem-antena-cache.3105` | `0` |
| `nr-normal-hs-alto` | `hs-alto-sem-antena-cache.3105` | `0` |
| `nr-normal-hs-pescoco` | `hs-neck-sem-antena-cache.3105` | `0` |
| `nr-normal-hs-peito` | `hs-peito-sem-antena-cache.3105` | `0` |
| `nr-normal-hs-caveira` | `hs-caveira-cache.3105` | `0` |
| `nr-normal-holograma` | `holograma-preto.3105` | `0` |

## NO RELOG / FREE FIRE MAX

| ID interno | Arquivo V41 | Senha padrão |
|---|---|---|
| `nr-max-hs-alto-pescoco` | `hs-alto-neck-sem-antena-cache-max.3105` | `0` |
| `nr-max-hs-alto` | `hs-alto-sem-antena-cache-max.3105` | `0` |
| `nr-max-hs-pescoco` | `hs-neck-sem-antena-cache-max.3105` | `0` |
| `nr-max-hs-peito` | `hs-peito-sem-antena-cache-max.3105` | `0` |
| `nr-max-hs-caveira` | `hs-caveira-cache-max.3105` | `0` |
| `nr-max-holograma` | `holograma-preto-max.3105` | `0` |

## TEXTURAS

| ID interno | Arquivo V41 | Senha padrão |
|---|---|---|
| `texture-normal-1` | `textura-1.3105` | `0` |
| `texture-normal-2` | `textura-2.3105` | `0` |
| `texture-normal-3` | `textura-3.3105` | `0` |
| `texture-normal-4` | `textura-4.3105` | `0` |
| `texture-normal-5` | `textura-5.3105` | `0` |
| `texture-max-4` | `textura-4-max.3105` | `0` |
| `texture-max-5` | `textura-5-max.3105` | `0` |
