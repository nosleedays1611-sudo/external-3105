# PHASE10 — Branding + Settings V41

- AppIcon replaced with the user-supplied red/yellow shopping-bag icon.
- User-facing alert title `Canva` changed to `External` everywhere in the source.
- Settings restored to the V41 layout.
- Realm GIF/banner intentionally removed from Settings.
- Portuguese option restored to the language picker; as in V41, app strings outside the custom Settings labels fall back to English.
- PHASE9 binary-resource packing and all prior remote/patch fixes remain unchanged.
