# PHASE11 — AliExpress display name

- CFBundleDisplayName changed from `EXTERNAL` to `AliExpress`.
- Xcode build-setting override updated to `AliExpress` in Debug and Release.
- Popup titles remain `External` as requested in PHASE10.
- No remote, patch, auth, Settings, icon, or engine behavior changed.
