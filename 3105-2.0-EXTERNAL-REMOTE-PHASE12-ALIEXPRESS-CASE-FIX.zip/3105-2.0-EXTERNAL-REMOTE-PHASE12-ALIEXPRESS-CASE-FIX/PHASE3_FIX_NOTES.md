# PHASE3 — Background / Restore recovery fix

This revision fixes the failure loop observed after backgrounding the app:

- Restores the 3105 2.0 `scenePhase` support re-check when the app becomes active.
- Allows the runtime-access layer to recover after sandbox access is lost on resume.
- Serializes runtime access recovery so Apply/Restore do not race a second exploit run.
- Makes the EXTERNAL switch restore semantics handle `restoreTargetsChanged` by restoring the saved original backup.
- Reconciles switch state from transaction journals whenever the view appears or returns active.
- Validates saved slot receipts against the real active transaction journal.
- Recovers a missing slot registry entry from the decoded patch project and journal when possible.
- Self-heals `projectAlreadyApplied` instead of leaving the switch permanently stuck until reinstall.

No changes were made to `exploit/`, `kexploit/`, `DevicePatchService.swift`, `PatchTransaction.swift`, or `PatchPackageCodec.swift`.
