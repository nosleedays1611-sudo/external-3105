# PHASE4 — Legacy patch names

- Mantém integralmente a correção de background/restore da PHASE3.
- Restaura um único catálogo `PatchSlots` no `ContentView.swift`.
- Todos os 41 slots remotos agora possuem o mesmo `fileName` usado pela V41.
- `120-144-fps.3105` e `120-144-fps-max.3105` voltam a usar senha padrão `OG`.
- O cache privado salva o patch com o nome V41 em vez de `vN.3105`.
- IDs técnicos (`fn-*`, `nr-*`, `texture-*`) continuam apenas como chaves estáveis de API para não quebrar o servidor já publicado.
- AIM 4 dedos continua removido, conforme solicitado.
- `PATCH_NAMES.md` contém o mapa completo.
