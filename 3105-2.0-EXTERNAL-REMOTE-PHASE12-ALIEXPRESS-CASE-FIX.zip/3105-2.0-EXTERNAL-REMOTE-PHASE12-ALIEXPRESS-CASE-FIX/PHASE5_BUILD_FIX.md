# PHASE5 — Build fix

Fixes the Swift compiler error introduced in PHASE4:

- `ContentView.swift:1842:13: error: switch must be exhaustive`
- Added handling for `RemotePatchStoreError.invalidFileName`.

No backend/API/patch IDs or UI behavior were changed by this build-only fix.
PHASE3 background/restore fix and PHASE4 legacy patch names remain included.
