# PHASE6 — Dynamic Functions

Fixes remote-created functions not appearing in the iOS app.

- Function and No Relog tabs now render every category returned by `/api/config`, not only HEADSHOTS/HOLOGRAMA.
- Empty `slotID` no longer hides a feature; the feature ID becomes the runtime row ID.
- A feature without `patchID` remains visible but disabled until a patch is linked.
- Remotely-created tabs no longer open a blank screen; unknown tab IDs use a generic dynamic renderer.
- Any dynamic feature with `withAntennaPatchID` can use the sem/com antenna chooser.
- Textures also remain visible when slotID is omitted and stay disabled until a patch is linked.
- Existing legacy categories/behavior are preserved for HEADSHOTS, HOLOGRAMA, No Relog, and Texturas.
