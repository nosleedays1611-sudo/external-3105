# PHASE7 — Background stability

- Keeps process-established runtime access across ordinary background/foreground transitions.
- Stops treating a single transient sandbox probe failure on resume as a hard loss of access.
- Prevents the false `runtimeAccessUnavailable` alert before Apply/Restore.
- Fresh process launches still begin with no cached access and follow the normal runtime bootstrap.
- PHASE3 restore/journal recovery, PHASE4 legacy names, PHASE5 build fix, and PHASE6 dynamic functions remain included.
