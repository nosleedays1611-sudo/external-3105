# PHASE8 — false background access gate removed

The PHASE7 client still called `RuntimeAccessCoordinator.ensureAccess()` before every Apply/Restore in `PatchSlotRunner.setEnabled`.
That preflight could transiently fail after returning from background and prevented `DevicePatchService` from running at all, producing the false alert:

`Acesso ao sistema foi perdido ao voltar do background...`

PHASE8 removes only that preflight gate from the switch Apply/Restore path. Existing authentication permit/integrity validation remains in place. DevicePatchService/PatchTransaction remain responsible for the actual patch transaction and error reporting.

Preserved from prior phases:
- restore of changed targets via saved original backup
- journal/backup reconciliation
- legacy V41 patch names
- dynamic remote functions/categories/tabs
- remote patch download/cache/integrity verification
