# PHASE9 — MAX BINARY PACKING

This phase keeps the PHASE8 behavior and moves additional runtime resources into the main `3105` Mach-O executable.

## Now linked into `3105`
- All Swift / Objective-C / C source from `views`, `helpers`, `exploit`, and `kexploit` (already compiled by Xcode).
- Texture1Card … Texture5Card image payloads, via custom `__DATA` sections.
- English localization (653 keys), via `__locen`.
- Vietnamese localization (653 keys), via `__locvi`.
- Simplified Chinese localization (653 keys), via `__loczh`.

The `.lproj` folders and texture image sets are no longer copied to the final app bundle.

## Intentionally still outside the executable
- `Info.plist`: iOS/LaunchServices must read bundle metadata before launching the executable.
- App icon payload (`Assets.car` / generated app icon PNGs): SpringBoard needs these without running the app.
- `Frameworks/ExternalAuth.dylib`: current auth/integrity code explicitly verifies the dylib as a separate Mach-O and the server contract includes its hash. Folding it into the main executable would require a coordinated auth protocol + integrity migration, not just a linker change.
- `PkgInfo`: generated compatibility metadata; only 8 bytes and not worth destabilizing packaging.

## Release build hardening / packing
- whole-module Swift compilation retained
- `-O` optimization
- dead-code stripping
- installed-product stripping
- source localization emission disabled

The app bundle should therefore no longer contain `en.lproj`, `vi.lproj`, `zh-Hans.lproj`, or texture card assets as loose resources.
