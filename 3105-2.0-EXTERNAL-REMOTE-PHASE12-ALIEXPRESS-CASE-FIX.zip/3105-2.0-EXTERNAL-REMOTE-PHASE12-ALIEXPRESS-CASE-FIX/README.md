> PHASE6: remote-created functions/categories/tabs are rendered dynamically from /api/config.

# 3105 2.0 — EXTERNAL Remote

Esta árvore usa a engine 3105 2.0 com a interface EXTERNAL V41 restaurada e controle remoto.

O cliente final não apresenta a tela de importação/editor de `.3105`. Function/No Relog/Texturas usam os switches da EXTERNAL e os arquivos são publicados pelo painel em `server/`.

Consulte `MIGRATION_NOTES.md` para o fluxo remoto.


PHASE4 keeps the PHASE3 background/restore fix and restores the V41 `.3105` naming catalog. See `PATCH_NAMES.md`.
