import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState: AppState
    @StateObject private var patchDraftCoordinator: PatchDraftCoordinator
    @StateObject private var fileOperationCoordinator: FileOperationCoordinator
    @StateObject private var patchStore: PatchProjectStore
    @StateObject private var repositoryStore: PackageRepositoryStore
    @StateObject private var authProtection: AuthProtection
    @StateObject private var remoteConfigStore: RemoteConfigStore
    @AppStorage(AppLanguage.storageKey) private var languageCode = AppLanguage.english.rawValue
    @Environment(\.scenePhase) private var scenePhase

    private var language: AppLanguage {
        AppLanguage(rawValue: languageCode) ?? .english
    }

    init() {
        setupLogCapture()
        log("app: EXTERNAL on 3105 2.0 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")

        guard AuthDylibLoader.shared.loadAndVerify() else {
            fatalError("Required authentication module failed integrity.")
        }
        EAExternalAuthEnsureStarted()

        _appState = StateObject(wrappedValue: AppState())
        _patchDraftCoordinator = StateObject(wrappedValue: PatchDraftCoordinator())
        _fileOperationCoordinator = StateObject(wrappedValue: FileOperationCoordinator())
        _patchStore = StateObject(wrappedValue: PatchProjectStore())
        _repositoryStore = StateObject(wrappedValue: PackageRepositoryStore())
        _authProtection = StateObject(wrappedValue: AuthProtection.shared)
        _remoteConfigStore = StateObject(wrappedValue: RemoteConfigStore())
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(appState)
                .environmentObject(patchDraftCoordinator)
                .environmentObject(fileOperationCoordinator)
                .environmentObject(patchStore)
                .environmentObject(repositoryStore)
                .environmentObject(authProtection)
                .environmentObject(remoteConfigStore)
                .environment(\.appLanguage, language)
                .environment(\.locale, language.locale)
                .onAppear {
                    appState.detectSupport()
                }
                .onChange(of: scenePhase) { phase in
                    guard phase == .active else { return }
                    appState.detectSupport()
                }
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // A sandbox probe can transiently report false immediately after the app
        // returns from background. Do not throw away an access state that was
        // already established by this process just because of that one probe.
        // The process-local coordinator remains authoritative until the process
        // exits; a fresh launch starts with no established access and runs the
        // normal bootstrap path again.
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
                Task { await RuntimeAccessCoordinator.shared.noteAccessAvailable() }
            } else if exploitStatus.isSuccess {
                log("app: sandbox probe was temporarily unavailable after resume; preserving established process access")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        Task {
            let ok = await RuntimeAccessCoordinator.shared.ensureAccess()
            await MainActor.run {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

actor RuntimeAccessCoordinator {
    static let shared = RuntimeAccessCoordinator()

    private var activeRun: Task<Bool, Never>?
    private var processAccessEstablished = false

    func noteAccessAvailable() {
        processAccessEstablished = true
    }

    func invalidateSandboxAccess() {
        if KernelExploit.requiresSandboxEscape {
            processAccessEstablished = false
        }
    }

    func ensureAccess() async -> Bool {
        let version = AppInfo.versionTuple
        guard KernelExploit.isApplicable(
            major: version.major,
            minor: version.minor,
            patch: version.patch,
            build: AppInfo.osBuild
        ) else {
            return false
        }

        // Once this process has successfully established runtime access, keep
        // that state across scenePhase/background transitions. iOS can briefly
        // make the filesystem probe fail while the app is resuming, which used
        // to cause a false "access lost" error before Apply/Restore even ran.
        if processAccessEstablished {
            return true
        }

        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                processAccessEstablished = true
                return true
            }
        }

        if let activeRun {
            return await activeRun.value
        }

        let task = Task.detached(priority: .userInitiated) {
            KernelExploit.run()
        }
        activeRun = task
        let ok = await task.value
        activeRun = nil

        if ok {
            processAccessEstablished = true
        }

        if KernelExploit.requiresSandboxEscape {
            return ok && KernelExploit.hasSandboxAccess()
        }
        return ok
    }
}
