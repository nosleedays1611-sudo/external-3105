#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/// Returns a read-only pointer to a custom section embedded in the main Mach-O executable.
/// sectionName must include the leading double underscore, e.g. "__tex1".
FOUNDATION_EXPORT const void * _Nullable EAEmbeddedResourceBytes(
    const char *sectionName,
    unsigned long *size
);

NS_ASSUME_NONNULL_END
