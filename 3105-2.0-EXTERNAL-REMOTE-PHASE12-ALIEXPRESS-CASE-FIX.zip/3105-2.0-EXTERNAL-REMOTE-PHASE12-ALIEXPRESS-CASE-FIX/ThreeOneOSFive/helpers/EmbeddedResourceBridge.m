#import "EmbeddedResourceBridge.h"

#import <mach-o/dyld.h>
#import <mach-o/getsect.h>
#import <mach-o/loader.h>
#include <stdint.h>

const void *EAEmbeddedResourceBytes(const char *sectionName, unsigned long *size) {
    if (!sectionName || !size) return NULL;
    *size = 0;

#if __LP64__
    const struct mach_header_64 *header =
        (const struct mach_header_64 *)_dyld_get_image_header(0);
    if (!header) return NULL;

    const struct section_64 *section =
        getsectbynamefromheader_64(header, "__DATA", sectionName);
    if (!section || section->size == 0) return NULL;

    intptr_t slide = _dyld_get_image_vmaddr_slide(0);
    *size = (unsigned long)section->size;
    return (const void *)((uintptr_t)section->addr + (uintptr_t)slide);
#else
    return NULL;
#endif
}
