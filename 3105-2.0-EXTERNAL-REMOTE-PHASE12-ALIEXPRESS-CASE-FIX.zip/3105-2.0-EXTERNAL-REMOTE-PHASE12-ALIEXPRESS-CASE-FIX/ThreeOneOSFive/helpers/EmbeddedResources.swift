import Foundation
import UIKit

/// Resources intentionally linked into custom sections of the main 3105 Mach-O.
/// They do not need to exist as loose files inside 3105.app.
enum EmbeddedResources {
    private static let imageCache = NSCache<NSString, UIImage>()
    private static var localizationCache: [String: [String: String]] = [:]
    private static let lock = NSLock()

    private static let textureSections: [String: String] = [
        "Texture1Card": "__tex1",
        "Texture2Card": "__tex2",
        "Texture3Card": "__tex3",
        "Texture4Card": "__tex4",
        "Texture5Card": "__tex5"
    ]

    private static let localizationSections: [String: String] = [
        "en": "__locen",
        "vi": "__locvi",
        "zh-Hans": "__loczh"
    ]

    static func data(in section: String) -> Data? {
        section.withCString { name in
            var size: UInt = 0
            guard let bytes = EAEmbeddedResourceBytes(name, &size), size > 0 else {
                return nil
            }
            return Data(bytes: bytes, count: Int(size))
        }
    }

    static func image(named name: String) -> UIImage? {
        if let cached = imageCache.object(forKey: name as NSString) {
            return cached
        }

        guard let section = textureSections[name],
              let data = data(in: section),
              let image = UIImage(data: data, scale: UIScreen.main.scale) else {
            // Keep normal asset lookup as a compatibility fallback for any future
            // remote imageName not part of the embedded catalog.
            return UIImage(named: name)
        }

        imageCache.setObject(image, forKey: name as NSString)
        return image
    }

    static func localizedTable(languageCode: String) -> [String: String] {
        let code = normalizedLanguageCode(languageCode)

        lock.lock()
        if let cached = localizationCache[code] {
            lock.unlock()
            return cached
        }
        lock.unlock()

        guard let section = localizationSections[code],
              let data = data(in: section),
              let object = try? JSONSerialization.jsonObject(with: data),
              let table = object as? [String: String] else {
            return [:]
        }

        lock.lock()
        localizationCache[code] = table
        lock.unlock()
        return table
    }

    static func localizedText(_ key: String, languageCode: String) -> String {
        let code = normalizedLanguageCode(languageCode)
        if let value = localizedTable(languageCode: code)[key] {
            return value
        }
        if code != "en", let fallback = localizedTable(languageCode: "en")[key] {
            return fallback
        }
        return key
    }

    static func currentLocalizedText(_ key: String) -> String {
        let stored = UserDefaults.standard.string(forKey: "appLanguage")
        let preferred = Locale.preferredLanguages.first ?? "en"
        return localizedText(key, languageCode: stored ?? preferred)
    }

    private static func normalizedLanguageCode(_ code: String) -> String {
        let lower = code.lowercased()
        if lower.hasPrefix("vi") { return "vi" }
        if lower.hasPrefix("zh") { return "zh-Hans" }
        return "en"
    }
}
