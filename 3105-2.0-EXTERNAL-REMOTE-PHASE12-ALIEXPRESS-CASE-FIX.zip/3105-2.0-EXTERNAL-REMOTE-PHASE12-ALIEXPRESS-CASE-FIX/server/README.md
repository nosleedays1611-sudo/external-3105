# EXTERNAL Remote Control v2

Servidor sem dependências npm externas.

## Iniciar

```bash
export ADMIN_TOKEN='um-token-com-pelo-menos-16-caracteres'
export PORT=3000
node server.js
```

Opcional:

```bash
export MAX_PATCH_BYTES=536870912
```

## Painel

Abra `/`, informe o `ADMIN_TOKEN` e controle:

- abas: visibilidade, ativação, título, ícone e ordem;
- funções: visibilidade, ativação, título, descrição, categoria e ordem;
- arquivos `.3105`: publicar, substituir, alterar senha e despublicar.

## API pública usada pela EXTERNAL

- `GET /health`
- `GET /api/config`
- `GET /api/patches/:id`

## API admin

Requer `Authorization: Bearer <ADMIN_TOKEN>`.

- `GET /api/admin/config`
- `PATCH /api/admin/tabs/:id`
- `PATCH /api/admin/features/:id`
- `PUT /api/admin/patches/:id/file`
- `PATCH /api/admin/patches/:id`
- `DELETE /api/admin/patches/:id`
- `PUT /api/admin/config`

O upload usa o corpo bruto do `.3105` (`application/octet-stream`) e os headers `X-Patch-Filename` e `X-Patch-Password`.
