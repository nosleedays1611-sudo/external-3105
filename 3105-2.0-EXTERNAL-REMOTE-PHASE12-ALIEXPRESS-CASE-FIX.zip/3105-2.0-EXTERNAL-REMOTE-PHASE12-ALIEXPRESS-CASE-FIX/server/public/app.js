const $ = id => document.getElementById(id);
let config = null;

function token() {
  return $('token').value.trim();
}

function status(message, error = false) {
  const node = $('status');
  node.textContent = message;
  node.classList.toggle('error', error);
}

async function api(url, options = {}) {
  const headers = new Headers(options.headers || {});
  headers.set('Authorization', `Bearer ${token()}`);
  if (options.body && typeof options.body === 'string') headers.set('Content-Type', 'application/json');
  const response = await fetch(url, { ...options, headers });
  const type = response.headers.get('content-type') || '';
  const body = type.includes('application/json') ? await response.json() : await response.text();
  if (!response.ok) throw new Error(body?.message || body?.error || response.statusText);
  return body;
}

function field(label, value = '', type = 'text') {
  const row = document.createElement('label');
  row.className = 'field';
  const span = document.createElement('span');
  span.textContent = label;
  const input = document.createElement('input');
  input.type = type;
  input.value = value ?? '';
  row.append(span, input);
  return { row, input };
}

function toggle(label, checked) {
  const row = document.createElement('label');
  row.className = 'toggle';
  const span = document.createElement('span');
  span.textContent = label;
  const input = document.createElement('input');
  input.type = 'checkbox';
  input.checked = !!checked;
  row.append(span, input);
  return { row, input };
}

function button(text, onclick, className = '') {
  const b = document.createElement('button');
  b.textContent = text;
  if (className) b.className = className;
  b.onclick = onclick;
  return b;
}

function cardTitle(title, subtitle) {
  const wrap = document.createElement('div');
  wrap.className = 'card-title';
  const h = document.createElement('h3');
  h.textContent = title;
  wrap.append(h);
  if (subtitle) {
    const p = document.createElement('p');
    p.textContent = subtitle;
    wrap.append(p);
  }
  return wrap;
}

async function load() {
  if (!token()) return status('Informe o ADMIN_TOKEN.', true);
  localStorage.setItem('external.admin.token', token());
  try {
    config = await api('/api/admin/config');
    render();
    status('Configuração carregada.');
  } catch (error) {
    status(`Erro: ${error.message}`, true);
  }
}

function renderTabs() {
  $('tabs').replaceChildren();
  for (const tab of [...config.tabs].sort((a,b) => a.order - b.order)) {
    const card = document.createElement('article');
    card.className = 'card';
    card.append(cardTitle(tab.title, tab.id));
    const title = field('Nome', tab.title); card.append(title.row);
    const icon = field('SF Symbol', tab.icon); card.append(icon.row);
    const order = field('Ordem', tab.order, 'number'); card.append(order.row);
    const visible = toggle('Visível no app', tab.visible); card.append(visible.row);
    const enabled = toggle('Ativável', tab.enabled); card.append(enabled.row);
    card.append(button('Salvar', async () => {
      try {
        config = await api(`/api/admin/tabs/${encodeURIComponent(tab.id)}`, {
          method: 'PATCH',
          body: JSON.stringify({
            title: title.input.value,
            icon: icon.input.value,
            order: Number(order.input.value),
            visible: visible.input.checked,
            enabled: enabled.input.checked
          })
        });
        render();
        status(`${tab.title}: salvo.`);
      } catch (error) { status(`Erro: ${error.message}`, true); }
    }));
    $('tabs').append(card);
  }
}

function renderFeatureFilter() {
  const previous = $('featureTab').value;
  $('featureTab').replaceChildren();
  for (const tab of config.tabs) {
    if (!['function','no-relog','textures'].includes(tab.id)) continue;
    const option = document.createElement('option');
    option.value = tab.id;
    option.textContent = tab.title;
    $('featureTab').append(option);
  }
  if ([...$('featureTab').options].some(o => o.value === previous)) $('featureTab').value = previous;
  $('featureTab').onchange = renderFeatures;
}

function renderFeatures() {
  $('features').replaceChildren();
  const tabID = $('featureTab').value || 'function';
  const features = config.features.filter(x => x.tabID === tabID).sort((a,b) => a.order - b.order);
  for (const feature of features) {
    const card = document.createElement('article');
    card.className = 'card';
    card.append(cardTitle(feature.title, `${feature.game} • ${feature.slotID || feature.id}`));
    const title = field('Nome', feature.title); card.append(title.row);
    const subtitle = field('Descrição', feature.subtitle || ''); card.append(subtitle.row);
    const category = field('Categoria', feature.category); card.append(category.row);
    const order = field('Ordem', feature.order, 'number'); card.append(order.row);
    const visible = toggle('Visível no app', feature.visible); card.append(visible.row);
    const enabled = toggle('Ativável', feature.enabled); card.append(enabled.row);

    const refs = document.createElement('div');
    refs.className = 'meta';
    refs.textContent = feature.withAntennaPatchID
      ? `sem: ${feature.patchID}  •  com: ${feature.withAntennaPatchID}`
      : `arquivo: ${feature.patchID || '—'}`;
    card.append(refs);

    card.append(button('Salvar', async () => {
      try {
        config = await api(`/api/admin/features/${encodeURIComponent(feature.id)}`, {
          method:'PATCH',
          body: JSON.stringify({
            title: title.input.value,
            subtitle: subtitle.input.value || null,
            category: category.input.value,
            order: Number(order.input.value),
            visible: visible.input.checked,
            enabled: enabled.input.checked
          })
        });
        render();
        status(`${feature.title}: salvo.`);
      } catch (error) { status(`Erro: ${error.message}`, true); }
    }));
    $('features').append(card);
  }
}

function patchUsage(id) {
  const list = [];
  for (const feature of config.features) {
    if (feature.patchID === id) list.push(`${feature.title} / ${feature.tabID} / ${feature.game}${feature.withAntennaPatchID ? ' / sem' : ''}`);
    if (feature.withAntennaPatchID === id) list.push(`${feature.title} / ${feature.tabID} / ${feature.game} / com`);
  }
  return list.join(' | ') || id;
}

function renderPatches() {
  $('patches').replaceChildren();
  for (const patch of [...config.patches].sort((a,b) => patchUsage(a.id).localeCompare(patchUsage(b.id)))) {
    const card = document.createElement('article');
    card.className = 'card';
    const published = patch.version > 0 && patch.sha256 && patch.size > 0;
    card.append(cardTitle(patchUsage(patch.id), patch.id));

    const meta = document.createElement('div');
    meta.className = 'meta';
    meta.textContent = published
      ? `Publicado • v${patch.version} • ${(patch.size / 1024).toFixed(1)} KB • SHA ${patch.sha256.slice(0,12)}…`
      : 'Ainda não publicado';
    card.append(meta);

    const password = field('Senha do .3105 (0 = sem senha)', patch.password || '0');
    card.append(password.row);

    const fileLabel = document.createElement('label');
    fileLabel.className = 'field';
    const span = document.createElement('span');
    span.textContent = 'Arquivo .3105';
    const file = document.createElement('input');
    file.type = 'file';
    file.accept = '.3105,application/octet-stream';
    fileLabel.append(span, file);
    card.append(fileLabel);

    const actions = document.createElement('div');
    actions.className = 'actions';
    actions.append(button(published ? 'Substituir .3105' : 'Publicar .3105', async () => {
      const selected = file.files?.[0];
      if (!selected) return status(`Selecione o .3105 de ${patch.id}.`, true);
      try {
        status(`Enviando ${selected.name}…`);
        const headers = new Headers();
        headers.set('Authorization', `Bearer ${token()}`);
        headers.set('Content-Type', 'application/octet-stream');
        headers.set('X-Patch-Filename', selected.name);
        headers.set('X-Patch-Password', password.input.value || '0');
        const response = await fetch(`/api/admin/patches/${encodeURIComponent(patch.id)}/file`, {
          method: 'PUT', headers, body: selected
        });
        const body = await response.json();
        if (!response.ok) throw new Error(body.message || body.error || response.statusText);
        config = body.config;
        render();
        status(`${selected.name}: publicado como ${patch.id}.`);
      } catch (error) { status(`Erro no upload: ${error.message}`, true); }
    }));

    if (published) {
      actions.append(button('Despublicar', async () => {
        if (!confirm(`Despublicar ${patch.id}? O app não conseguirá ativá-lo até um novo upload.`)) return;
        try {
          config = await api(`/api/admin/patches/${encodeURIComponent(patch.id)}`, { method:'DELETE' });
          render();
          status(`${patch.id}: despublicado.`);
        } catch (error) { status(`Erro: ${error.message}`, true); }
      }, 'danger'));
    }
    card.append(actions);
    $('patches').append(card);
  }
}

function render() {
  $('revision').textContent = `revision ${config.revision}`;
  renderTabs();
  renderFeatureFilter();
  renderFeatures();
  renderPatches();
}

$('load').onclick = load;
$('token').value = localStorage.getItem('external.admin.token') || '';
if ($('token').value) load();
