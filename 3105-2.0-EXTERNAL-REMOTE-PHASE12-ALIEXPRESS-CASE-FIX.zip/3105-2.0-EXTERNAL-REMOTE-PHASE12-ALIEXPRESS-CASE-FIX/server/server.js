import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const ADMIN_TOKEN = String(process.env.ADMIN_TOKEN || '');
const DATA_DIR = path.join(__dirname, 'data');
const PATCH_DIR = path.join(DATA_DIR, 'patches');
const CONFIG_PATH = path.join(DATA_DIR, 'config.json');
const DEFAULT_CONFIG_PATH = path.join(__dirname, 'config.default.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const MAX_JSON_BODY = 2 * 1024 * 1024;
const MAX_PATCH_BYTES = Number(process.env.MAX_PATCH_BYTES || 512 * 1024 * 1024);

if (!ADMIN_TOKEN || ADMIN_TOKEN.length < 16) {
  console.error('ADMIN_TOKEN precisa existir e ter pelo menos 16 caracteres.');
  process.exit(1);
}

fs.mkdirSync(PATCH_DIR, { recursive: true });
if (!fs.existsSync(CONFIG_PATH)) fs.copyFileSync(DEFAULT_CONFIG_PATH, CONFIG_PATH);

function readConfig() {
  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  validateConfig(config);
  return config;
}

function writeConfig(config) {
  validateConfig(config);
  const temp = `${CONFIG_PATH}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(config, null, 2));
  fs.renameSync(temp, CONFIG_PATH);
}

function validateConfig(config) {
  if (!config || config.schema !== 2 || !Number.isInteger(config.revision) || config.revision < 0) {
    throw new Error('config inválida');
  }
  if (!Array.isArray(config.tabs) || config.tabs.length > 32) throw new Error('tabs inválidas');
  if (!Array.isArray(config.features) || config.features.length > 512) throw new Error('features inválidas');
  if (!Array.isArray(config.patches) || config.patches.length > 1024) throw new Error('patches inválidos');

  const tabIDs = new Set();
  for (const tab of config.tabs) {
    if (!tab || typeof tab.id !== 'string' || !tab.id.trim() || tabIDs.has(tab.id)) throw new Error('tab id inválido');
    tabIDs.add(tab.id);
    if (typeof tab.title !== 'string' || typeof tab.icon !== 'string') throw new Error('tab inválida');
    if (typeof tab.visible !== 'boolean' || typeof tab.enabled !== 'boolean') throw new Error('tab flags inválidas');
    if (!Number.isInteger(tab.order)) throw new Error('tab order inválido');
  }

  const patchIDs = new Set();
  for (const patch of config.patches) {
    if (!patch || typeof patch.id !== 'string' || !patch.id.trim() || patchIDs.has(patch.id)) throw new Error('patch id inválido');
    patchIDs.add(patch.id);
    if (typeof patch.fileName !== 'string' || typeof patch.password !== 'string') throw new Error('patch metadata inválido');
    if (!Number.isInteger(patch.version) || patch.version < 0) throw new Error('patch version inválido');
    if (typeof patch.sha256 !== 'string' || typeof patch.size !== 'number' || patch.size < 0) throw new Error('patch integrity inválido');
  }

  const featureIDs = new Set();
  for (const feature of config.features) {
    if (!feature || typeof feature.id !== 'string' || !feature.id.trim() || featureIDs.has(feature.id)) throw new Error('feature id inválido');
    featureIDs.add(feature.id);
    if (!tabIDs.has(feature.tabID)) throw new Error('feature tabID inválido');
    if (typeof feature.title !== 'string' || typeof feature.category !== 'string' || typeof feature.game !== 'string') throw new Error('feature inválida');
    if (typeof feature.visible !== 'boolean' || typeof feature.enabled !== 'boolean') throw new Error('feature flags inválidas');
    if (!Number.isInteger(feature.order)) throw new Error('feature order inválido');
    if (feature.patchID != null && !patchIDs.has(feature.patchID)) throw new Error(`patchID desconhecido: ${feature.patchID}`);
    if (feature.withAntennaPatchID != null && !patchIDs.has(feature.withAntennaPatchID)) throw new Error(`withAntennaPatchID desconhecido: ${feature.withAntennaPatchID}`);
  }
}

function publicConfig(config) {
  return config;
}

function json(res, status, body, cors = false) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': data.length,
    'Cache-Control': 'no-store',
    ...(cors ? { 'Access-Control-Allow-Origin': '*' } : {})
  });
  res.end(data);
}

function text(res, status, body, type = 'text/plain; charset=utf-8') {
  const data = Buffer.isBuffer(body) ? body : Buffer.from(body);
  res.writeHead(status, {
    'Content-Type': type,
    'Content-Length': data.length,
    'Cache-Control': 'no-store'
  });
  res.end(data);
}

function authorized(req) {
  const header = String(req.headers.authorization || '');
  const supplied = header.startsWith('Bearer ') ? header.slice(7) : '';
  const expected = Buffer.from(ADMIN_TOKEN);
  const actual = Buffer.from(supplied);
  return expected.length === actual.length && crypto.timingSafeEqual(expected, actual);
}

async function readJSON(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_JSON_BODY) throw new Error('body muito grande');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function applyAllowed(target, patch, fields) {
  for (const field of fields) {
    if (Object.prototype.hasOwnProperty.call(patch, field)) target[field] = patch[field];
  }
}

function increment(config) {
  config.revision += 1;
  config.updatedAt = new Date().toISOString();
  return config;
}

function safePatchPath(id) {
  const digest = crypto.createHash('sha256').update(id).digest('hex');
  return path.join(PATCH_DIR, `${digest}.3105`);
}

async function receivePatch(req, finalPath) {
  const temp = `${finalPath}.${process.pid}.${Date.now()}.tmp`;
  const hash = crypto.createHash('sha256');
  let size = 0;
  const stream = fs.createWriteStream(temp, { flags: 'wx' });

  try {
    for await (const chunk of req) {
      size += chunk.length;
      if (size > MAX_PATCH_BYTES) throw new Error('arquivo .3105 acima do limite');
      hash.update(chunk);
      if (!stream.write(chunk)) {
        await new Promise((resolve, reject) => {
          stream.once('drain', resolve);
          stream.once('error', reject);
        });
      }
    }
    await new Promise((resolve, reject) => stream.end(err => err ? reject(err) : resolve()));
    if (size === 0) throw new Error('arquivo vazio');
    fs.renameSync(temp, finalPath);
    return { size, sha256: hash.digest('hex') };
  } catch (error) {
    stream.destroy();
    try { fs.unlinkSync(temp); } catch {}
    throw error;
  }
}

function serveStatic(req, res) {
  const pathname = new URL(req.url, 'http://local').pathname;
  const requestPath = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const full = path.resolve(PUBLIC_DIR, requestPath);
  if (!full.startsWith(path.resolve(PUBLIC_DIR) + path.sep) && full !== path.resolve(PUBLIC_DIR, 'index.html')) return false;
  if (!fs.existsSync(full) || fs.statSync(full).isDirectory()) return false;

  const ext = path.extname(full).toLowerCase();
  const types = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'text/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8'
  };
  text(res, 200, fs.readFileSync(full), types[ext] || 'application/octet-stream');
  return true;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, { ok: true, service: 'external-remote-control', schema: 2 });
    }

    if (req.method === 'GET' && url.pathname === '/api/config') {
      return json(res, 200, publicConfig(readConfig()), true);
    }

    const publicPatchMatch = url.pathname.match(/^\/api\/patches\/([^/]+)$/);
    if (req.method === 'GET' && publicPatchMatch) {
      const id = decodeURIComponent(publicPatchMatch[1]);
      const config = readConfig();
      const patch = config.patches.find(x => x.id === id);
      if (!patch || patch.version <= 0 || !patch.sha256 || patch.size <= 0) {
        return json(res, 404, { error: 'patch_not_published' }, true);
      }
      const file = safePatchPath(id);
      if (!fs.existsSync(file)) return json(res, 404, { error: 'patch_file_missing' }, true);

      res.writeHead(200, {
        'Content-Type': 'application/octet-stream',
        'Content-Length': fs.statSync(file).size,
        'Cache-Control': 'public, max-age=31536000, immutable',
        'ETag': `"${patch.sha256}"`,
        'X-Patch-Version': String(patch.version),
        'X-Patch-SHA256': patch.sha256,
        'Access-Control-Allow-Origin': '*'
      });
      fs.createReadStream(file).pipe(res);
      return;
    }

    if (url.pathname.startsWith('/api/admin/')) {
      if (!authorized(req)) return json(res, 401, { error: 'unauthorized' });

      if (req.method === 'GET' && url.pathname === '/api/admin/config') {
        return json(res, 200, readConfig());
      }

      const tabMatch = url.pathname.match(/^\/api\/admin\/tabs\/([^/]+)$/);
      if (req.method === 'PATCH' && tabMatch) {
        const patch = await readJSON(req);
        const config = readConfig();
        const tab = config.tabs.find(x => x.id === decodeURIComponent(tabMatch[1]));
        if (!tab) return json(res, 404, { error: 'tab_not_found' });
        applyAllowed(tab, patch, ['title', 'icon', 'visible', 'enabled', 'order']);
        increment(config);
        writeConfig(config);
        return json(res, 200, config);
      }

      const featureMatch = url.pathname.match(/^\/api\/admin\/features\/([^/]+)$/);
      if (req.method === 'PATCH' && featureMatch) {
        const patch = await readJSON(req);
        const config = readConfig();
        const feature = config.features.find(x => x.id === decodeURIComponent(featureMatch[1]));
        if (!feature) return json(res, 404, { error: 'feature_not_found' });
        applyAllowed(feature, patch, [
          'title', 'subtitle', 'category', 'game', 'imageName',
          'visible', 'enabled', 'order'
        ]);
        increment(config);
        writeConfig(config);
        return json(res, 200, config);
      }

      const patchFileMatch = url.pathname.match(/^\/api\/admin\/patches\/([^/]+)\/file$/);
      if (req.method === 'PUT' && patchFileMatch) {
        const id = decodeURIComponent(patchFileMatch[1]);
        const config = readConfig();
        const patch = config.patches.find(x => x.id === id);
        if (!patch) return json(res, 404, { error: 'patch_not_found' });

        const fileNameHeader = String(req.headers['x-patch-filename'] || '').trim();
        const passwordHeader = String(req.headers['x-patch-password'] || '0');
        const finalPath = safePatchPath(id);
        const uploaded = await receivePatch(req, finalPath);

        patch.fileName = fileNameHeader || `${id}.3105`;
        patch.password = passwordHeader || '0';
        patch.version = Number(patch.version || 0) + 1;
        patch.sha256 = uploaded.sha256;
        patch.size = uploaded.size;
        increment(config);
        writeConfig(config);
        return json(res, 200, { config, patch });
      }

      const patchMetaMatch = url.pathname.match(/^\/api\/admin\/patches\/([^/]+)$/);
      if (req.method === 'PATCH' && patchMetaMatch) {
        const id = decodeURIComponent(patchMetaMatch[1]);
        const incoming = await readJSON(req);
        const config = readConfig();
        const patch = config.patches.find(x => x.id === id);
        if (!patch) return json(res, 404, { error: 'patch_not_found' });
        applyAllowed(patch, incoming, ['fileName', 'password']);
        increment(config);
        writeConfig(config);
        return json(res, 200, config);
      }

      if (req.method === 'DELETE' && patchMetaMatch) {
        const id = decodeURIComponent(patchMetaMatch[1]);
        const config = readConfig();
        const patch = config.patches.find(x => x.id === id);
        if (!patch) return json(res, 404, { error: 'patch_not_found' });
        try { fs.unlinkSync(safePatchPath(id)); } catch {}
        patch.version = 0;
        patch.sha256 = '';
        patch.size = 0;
        increment(config);
        writeConfig(config);
        return json(res, 200, config);
      }

      if (req.method === 'PUT' && url.pathname === '/api/admin/config') {
        const incoming = await readJSON(req);
        const current = readConfig();
        incoming.schema = 2;
        incoming.revision = Math.max(Number(incoming.revision || 0), current.revision) + 1;
        incoming.updatedAt = new Date().toISOString();
        writeConfig(incoming);
        return json(res, 200, incoming);
      }

      return json(res, 404, { error: 'not_found' });
    }

    if (req.method === 'GET' && serveStatic(req, res)) return;
    return json(res, 404, { error: 'not_found' });
  } catch (error) {
    console.error(error);
    if (!res.headersSent) return json(res, 400, { error: 'bad_request', message: String(error.message || error) });
    res.destroy();
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`EXTERNAL Remote Control v2 ouvindo na porta ${PORT}`);
});
