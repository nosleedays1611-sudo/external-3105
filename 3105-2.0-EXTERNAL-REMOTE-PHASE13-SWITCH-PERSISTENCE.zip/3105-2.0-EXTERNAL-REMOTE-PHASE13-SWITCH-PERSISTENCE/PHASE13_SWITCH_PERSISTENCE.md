# PHASE13 — Switch Persistence

Base: PHASE12 AliExpress case fix.

Correção:
- O estado lógico dos switches agora é persistido por feature remota (remoteID) em UserDefaults.
- Sair/minimizar a IPA e voltar não desliga mais visualmente um switch selecionado.
- Funções manuais da aba Function/HEADSHOTS também persistem mesmo antes de INJETAR, pois seleção de UI e receipt de patch são estados diferentes.
- A escolha sem/com antena também é persistida.
- Texturas usam a mesma persistência.
- O registro do backup não é mais apagado só porque latestReceipt ficou temporariamente indisponível ao retornar do background.
- O estado só é limpo por ação explícita de OFF/Restore concluída com sucesso (ou quando a opção nunca esteve ligada/aplicada).

Nenhuma alteração de branding, servidor, remote config, PatchPackageCodec, DevicePatchService ou PatchTransaction nesta fase.
