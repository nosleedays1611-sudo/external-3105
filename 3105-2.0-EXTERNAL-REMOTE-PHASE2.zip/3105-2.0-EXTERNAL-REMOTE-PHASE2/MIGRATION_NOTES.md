# EXTERNAL 3105 2.0 — Phase 2

## O que foi corrigido

- A UI principal voltou para o layout da V41: Function, No Relog, Texturas e Config.
- A tela `Installed / New Patch` da UI oficial 3105 2.0 não é mais exposta ao cliente.
- As linhas voltaram a usar switches.
- Function voltou a exibir os cards `INJETAR (40%)` e `LOBBY` para as opções manuais.
- `Aim Bot + Esp 4 Dedos` e `Aim Silent + 4 Dedos` foram removidos do catálogo padrão.
- O core da 3105 2.0 (`exploit/`, `kexploit/`, DevicePatchService, PatchTransaction, PatchPackageCodec, SupportPolicy e KernelExploit) foi mantido.

## Controle remoto

O app recebe `/api/config` e monta abas/funções dinamicamente:

- `visible=false`: remove a aba/função do visual.
- `enabled=false`: mantém visível, mas inativável.
- título, ícone e ordem são remotos.
- os arquivos `.3105` não são escolhidos/importados pelo cliente.

## .3105 remoto

O painel web possui uma seção `Arquivos .3105`.

Cada slot remoto tem:

- ID estável;
- nome do arquivo;
- senha (`0` = sem senha);
- versão;
- SHA-256;
- tamanho.

Ao publicar/substituir um arquivo no painel:

1. o servidor salva o `.3105`;
2. calcula SHA-256;
3. incrementa a versão do slot;
4. incrementa `revision` da configuração;
5. o cliente recebe a nova revisão;
6. no próximo Apply, o arquivo é baixado e validado antes de `PatchPackageCodec.decode`;
7. `DevicePatchService.apply` e `DevicePatchService.restore` continuam sendo os da 2.0.

O cliente mantém cache por `patchID + version` e não baixa novamente quando hash/tamanho continuam válidos.

## Endpoint no Info.plist

Configure `ExternalRemoteConfigURL`, por exemplo:

`https://seu-dominio.com/api/config`

## Servidor

```bash
cd server
export ADMIN_TOKEN='troque-por-um-token-longo'
node server.js
```

Painel: `/`

Health: `/health`

Config pública: `/api/config`

Download de patch: `/api/patches/:id`
