# Correção do build – teste de diretório remoto

Alteração exclusiva em `ThreeOneOSFive/ContentView.swift`:

- Substituído o inicializador incorreto de SwiftUI `Section("TESTE DE DIRETÓRIO REMOTO") { ... } footer: { ... }` por `Section { ... } header: { ... } footer: { ... }`, suportado pelo SwiftUI.
- Os botões de aplicar/restaurar, lógica de download, SHA-256, backup e limite à pasta `Documents/RemoteTests` permanecem iguais.
- Não foram alterados os recursos, configuração de assinatura ou o projeto Xcode.

Verificações no ambiente: análise sintática com `swiftc -frontend -parse` e comparação do código-fonte; **não foi executado build com SDK iOS**, indisponível aqui. O exit code 65 é apenas um resumo e a captura exibida não contém as mensagens `error:`; caso o build persista, envie as linhas `error:` acima do resumo no log do job.
