# Remote image support

`TexturasView` now accepts both existing embedded image asset names and remote image URLs/paths returned by the server. Existing bundled images remain compatible; uploaded images can be delivered from `/api/images/:featureID` without rebuilding the image asset catalog.
