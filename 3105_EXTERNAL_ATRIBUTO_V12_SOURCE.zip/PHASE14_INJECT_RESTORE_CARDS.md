# PHASE14 — INJETAR / DESINJETAR (40%)

Base: PHASE13.

Mudanças na versão REMOTE:
- preservado o fluxo manual de Apply/Restore usado pela EXTERNAL antiga;
- card `INJETAR (40%)` renomeado para `INJETAR`;
- card `LOBBY` renomeado para `DESINJETAR (40%)`;
- `INJETAR` continua chamando o fluxo protegido `.patchApply` e `DevicePatchService.apply`;
- `DESINJETAR (40%)` continua chamando `.patchRestore` e `DevicePatchService.restore` usando o backup/receipt existente;
- mensagens que orientavam `Use LOBBY` agora orientam `Use DESINJETAR (40%)`;
- nenhuma mudança no backend, RemoteConfig, nomes dos patches ou engine 2.0.
