# PHASE15 — Tema remoto + função seletora

## Tema remoto

- `/api/config` agora pode publicar `theme.accentColor` em `#RRGGBB`.
- A EXTERNAL reaplica a cor de destaque em SwiftUI ao receber uma revision nova.
- O polling mínimo do cliente foi reduzido para 3 segundos; o seed usa 5 segundos.
- A cor afeta navegação, bordas, títulos de seção, cards, toggles/tint e Settings.

## Função seletora

Uma função remota pode usar:

```json
{
  "controlType": "selector",
  "selectorOptions": [
    { "id": "head", "title": "Cabeça", "call": "head", "order": 10 },
    { "id": "neck", "title": "Pescoço", "call": "neck", "order": 20 }
  ]
}
```

Fluxo da IPA:

1. Switch ON apenas habilita a função e exibe `INJETAR` / `DESINJETAR 40%`.
2. `INJETAR` aplica somente o patch base, quando houver, e então libera o seletor.
3. Escolher uma opção NÃO executa outro Apply. A escolha grava somente a chamada em `ExternalSelectorRuntime` e publica `Notification.Name.externalSelectorCallChanged`.
4. `DESINJETAR 40%` restaura o backup base, limpa a chamada selecionada e desliga a função.
5. O estado de chamada/injeção é persistido em `UserDefaults`, portanto sobrevive a fechamento/reabertura da IPA.

## Backup persistente

O Apply continua salvando `PatchTransactionReceipt` no `PatchSlotBackupRegistry` e os arquivos originais no diretório de backup da aplicação. Fechar/reabrir a IPA não apaga o receipt. O marcador só é removido depois de Restore concluído com sucesso.
