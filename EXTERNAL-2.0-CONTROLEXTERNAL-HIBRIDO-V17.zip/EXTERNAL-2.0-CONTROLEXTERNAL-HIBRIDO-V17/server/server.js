import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

import { config } from './config.js';
import { Store } from './database.js';
import { createAuth } from './lib/auth.js';
import {
  HTTPError,
  clientIP,
  readJSON,
  readBuffer,
  sendEmpty,
  sendJSON,
  serveStatic,
  setCommonHeaders,
  streamUploadToFile
} from './lib/http.js';
import {
  ValidationError,
  featureCreate,
  featurePatch,
  id,
  loginBody,
  patchCreate,
  patchMetadata,
  rollbackBody,
  settingsPatch,
  tabCreate,
  tabPatch
} from './lib/validation.js';


// EXTERNAL V14: per-installation HTTPS control plane. No filesystem IPC in the game.
// Sessions are bound to a separately verified EXTERNAL license and its HWID.
const AUTH_URL = process.env.EXTERNAL_ATTRIBUTE_AUTH_URL || 'https://externalconfig.shardweb.app/api/keys/check';
const TOKEN_RE = /^[a-f0-9]{48}$/;
const MAX_SESSION_MS = 12 * 60 * 60 * 1000;
let lastMissingChannelWarning = 0;
const attributeLog = (event, status) => console.log(`[EXTERNAL-ATTRIBUTE V15] ${event} ${status}`);

function json(res, status, body) {
  const data = Buffer.from(JSON.stringify(body));
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Content-Length':data.length,'Cache-Control':'no-store'});
  res.end(data);
}
function ascii(res, body) {
  res.writeHead(200, {'Content-Type':'text/plain; charset=us-ascii', 'Cache-Control':'no-store, no-cache, must-revalidate, max-age=0','Pragma':'no-cache','Content-Length':Buffer.byteLength(body)});
  res.end(body, 'ascii');
}
async function bodyJSON(req) {
  let chunks=[],size=0;
  for await(const chunk of req) { size+=chunk.length; if(size>8192) throw new Error('too_large'); chunks.push(chunk); }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}
function payload(level) {
  // Exact wire format expected by the existing, tested Remote iFix parser:
  // version/ESP/aim/target/FOV/attribute/remaining flags/FOV visibility.
  const bits=['7','0','0','0','0','120',String(level),'0','0','0','0','0','0','0','1','0','0','0'];
  const result=bits.join('')+'1'; // hide the unused Remote FOV widget
  if(result.length!==21 || !/^7[01]{3}[0-2]\d{3}[0-4][01]{6}[0-2][1-5][01]{3}[01]$/.test(result)) throw new Error('invalid_wire_payload');
  return result;
}

function createExternalAttributeControl(db, secret, opts={}) {
  if(!secret) throw new Error('External Attribute needs the existing server admin secret');
  const connection=db.db || db;
  connection.exec(`CREATE TABLE IF NOT EXISTS external_attribute_v14 (
    id INTEGER PRIMARY KEY,
    identity_digest TEXT NOT NULL,
    read_digest TEXT NOT NULL UNIQUE,
    write_digest TEXT NOT NULL UNIQUE,
    level INTEGER NOT NULL DEFAULT 0 CHECK (level BETWEEN 0 AND 4),
    expires_ms INTEGER NOT NULL,
    updated_ms INTEGER NOT NULL,
    last_poll_ms INTEGER NOT NULL DEFAULT 0
  )`);
  const lookupRead=connection.prepare('SELECT * FROM external_attribute_v14 WHERE read_digest=?');
  const lookupWrite=connection.prepare('SELECT * FROM external_attribute_v14 WHERE write_digest=?');
  const upsert=connection.prepare(`INSERT INTO external_attribute_v14 (identity_digest,read_digest,write_digest,level,expires_ms,updated_ms)
    VALUES (?,?,?,?,?,?)`);
  const renew=connection.prepare('UPDATE external_attribute_v14 SET level=0,expires_ms=?,updated_ms=? WHERE id=?');
  const setLevel=connection.prepare('UPDATE external_attribute_v14 SET level=?,updated_ms=? WHERE id=?');
  const touchRead=connection.prepare('UPDATE external_attribute_v14 SET last_poll_ms=? WHERE id=?');
  const digest = token => crypto.createHash('sha256').update(token).digest('hex');
  const identity = (key,hwid) => crypto.createHmac('sha256',String(secret)).update(key+'\n'+hwid).digest('hex');
  const generate=()=>crypto.randomBytes(24).toString('hex');
  const authURL=opts.authURL || AUTH_URL;
  const authorize=opts.authorize || (async (key, hwid) => {
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),7500);
    try {
      const response=await fetch(authURL,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify({key,device_token:hwid}),signal:controller.signal});
      if(!response.ok) return null;
      const result=await response.json();
      if(result.success!==true || result.found!==true || String(result.status).toLowerCase()!=='active') return null;
      const expiresAt=result.expires_at?Date.parse(result.expires_at):NaN;
      if(result.expires_at && (!Number.isFinite(expiresAt) || expiresAt<=Date.now())) return null;
      return {expiresAt:Number.isFinite(expiresAt)?expiresAt:null};
    } finally { clearTimeout(timeout); }
  });
  const fail=(res,status,error)=>json(res,status,{ok:false,error});

  return async function handleAttribute(req,res,url) {
    const path=url.pathname;
    if(path==='/api/attribute/health' && req.method==='GET') {
      json(res,200,{ok:true,service:'external-attribute-v14',transport:'https-poll'});
      return true;
    }
    if(path==='/api/attribute/state' && req.method==='GET') {
      const token=url.searchParams.get('ch') || '';
      const record=TOKEN_RE.test(token)?lookupRead.get(digest(token)):null;
      const valid=record && record.expires_ms>Date.now();
      // Always send a valid OFF state for invalid/expired sessions. The original
      // iFix networking code forcibly exits on HTTP 403, so never emit it here.
      if(valid && Date.now()-record.last_poll_ms > 60000) touchRead.run(Date.now(),record.id);
      if(!valid && Date.now()-lastMissingChannelWarning > 60000) {
        lastMissingChannelWarning = Date.now();
        attributeLog('GET /state', 'unknown/expired channel; returning OFF, HTTP 200 for iFix compatibility');
      }
      // Diagnostic header only: does not alter the 21-byte iFix wire payload.
      res.setHeader('X-External-Attribute-Channel', valid ? 'active' : 'invalid');
      ascii(res,payload(valid?record.level:0));
      return true;
    }
    if(path==='/api/attribute/session' && req.method==='POST') {
      let data;
      try{ data=await bodyJSON(req); }catch{return fail(res,400,'invalid_json'),true;}
      const key=String(data.key||''); const hwid=String(data.hwid||'');
      if(key.length<6 || key.length>160 || hwid.length<8 || hwid.length>160) {fail(res,400,'invalid_identity');return true;}
      let license;
      try { license=await authorize(key,hwid); } catch { attributeLog('POST /session','license backend unavailable');fail(res,503,'license_service_unavailable'); return true; }
      if(!license){attributeLog('POST /session','rejected: invalid EXTERNAL license');fail(res,401,'license_invalid');return true;}
      const now=Date.now(); const expires=Math.min(now+MAX_SESSION_MS,license.expiresAt || Infinity);
      if(expires<=now){fail(res,401,'license_expired');return true;}
      const ident=identity(key,hwid);
      let readToken=String(data.readToken||''),writeToken=String(data.writeToken||'');
      let existing=null;
      if(TOKEN_RE.test(readToken)&&TOKEN_RE.test(writeToken)) {
        existing=lookupRead.get(digest(readToken));
        if(!existing || existing.identity_digest!==ident || existing.write_digest!==digest(writeToken)) existing=null;
      }
      if(existing) renew.run(expires,now,existing.id);
      else {
        readToken=generate();writeToken=generate();
        upsert.run(ident,digest(readToken),digest(writeToken),0,expires,now);
      }
      attributeLog('POST /session', 'authorized (tokens hidden)');
      json(res,200,{ok:true,readToken,writeToken,expiresAt:new Date(expires).toISOString()});
      return true;
    }
    if(path==='/api/attribute/level' && req.method==='POST') {
      const bearer=String(req.headers.authorization||'');
      const token=bearer.startsWith('Bearer ')?bearer.slice(7):'';
      const record=TOKEN_RE.test(token)?lookupWrite.get(digest(token)):null;
      if(!record || record.expires_ms<=Date.now()) {attributeLog('POST /level','rejected: invalid session');fail(res,401,'session_invalid');return true;}
      let data;
      try {data=await bodyJSON(req);}catch {fail(res,400,'invalid_json');return true;}
      if(!Number.isInteger(data.level)||data.level<0||data.level>4){fail(res,400,'invalid_level');return true;}
      setLevel.run(data.level,Date.now(),record.id);
      attributeLog('POST /level', 'level=' + data.level + ', applied');
      json(res,200,{ok:true,level:data.level});return true;
    }
    return false;
  };
}



const here = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(here, 'public');
const db = new Store(config);
const auth = createAuth({ db, config });
const uploadLocks = new Set();
// Separate product-specific IPA <-> assembly channel. No RemoteIOS URLs or key sharing.
const externalAttribute = createExternalAttributeControl(db, config.adminToken || config.adminPassword);
// Two-file deployment. Intentionally compatible with the original database.js and lib/*.
const CONTROL_BUILD = '2.2.1-hybrid-flexible-app-paths-v17';
const HYBRID_MAX_BYTES = Math.min(config.maxPatchBytes || 33554432, 33554432);
const manualRoot = path.join(config.dataDir, 'manual-directory-patches');
db.db.exec(`CREATE TABLE IF NOT EXISTS external_manual_patches (
  id TEXT PRIMARY KEY, title TEXT NOT NULL, target_path TEXT NOT NULL,
  file_name TEXT, sha256 TEXT, size INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS external_feature_options (
  feature_id TEXT PRIMARY KEY, patch_mode TEXT NOT NULL DEFAULT 'automatic',
  manual_patch_id TEXT, warning_icon INTEGER NOT NULL DEFAULT 0
);`);
const selectManual = db.db.prepare('SELECT * FROM external_manual_patches ORDER BY title COLLATE NOCASE');
const selectFeatureOpts = db.db.prepare('SELECT * FROM external_feature_options WHERE feature_id=?');
const selectManualByID = db.db.prepare('SELECT * FROM external_manual_patches WHERE id=?');
const manualSummary = r => ({
  id:r.id, title:r.title, targetPath:r.target_path, fileName:r.file_name || '',
  sha256:r.sha256 || '', size:r.size, version:r.version,
  downloadPath:`/api/manual-patches/${encodeURIComponent(r.id)}`
});
const manualList = () => selectManual.all().map(manualSummary);
function manualPath(input) {
  // Any relative file inside an app-owned Documents/, Library/ or tmp/ directory.
  // Reject traversal and the local backup journal; the client rechecks before writing.
  if (typeof input !== 'string' || !input.length || input.length > 2048 ||
      /[\\\u0000-\u001F\u007F]/.test(input) || input.startsWith('/')) {
    throw new HTTPError(400, 'Destino inválido: use um caminho relativo ao contêiner do app');
  }
  const parts = input.split('/');
  if (parts.length < 2 || !['Documents', 'Library', 'tmp'].includes(parts[0]) ||
      parts.some(part => !part || part === '.' || part === '..' || part.length > 255)) {
    throw new HTTPError(400, 'Use Documents/..., Library/... ou tmp/... sem . e ..');
  }
  if (parts[0] === 'Library' && parts[1] === 'Application Support' &&
      parts[2] === 'external-manual-receipts-v1') {
    throw new HTTPError(400, 'Diretório interno de backup não pode ser sobrescrito');
  }
  return input;
}
function optionFields(featureID) {
  const opts=selectFeatureOpts.get(featureID);
  return {patchMode:opts?.patch_mode || 'automatic',manualPatchID:opts?.manual_patch_id || null,warningIcon:!!opts?.warning_icon};
}
function checkFeatureOptions(data) {
  const mode=data.patchMode || 'automatic';
  if (!['automatic','manual'].includes(mode)) throw new HTTPError(400,'Método de patch inválido');
  const manualID=data.manualPatchID ? id(data.manualPatchID) : null;
  if (mode==='manual' && (!manualID || !selectManualByID.get(manualID))) throw new HTTPError(400,'Selecione um patch manual existente');
  if (typeof data.warningIcon !== 'boolean') throw new HTTPError(400,'Ícone de alerta deve ser booleano');
  return {mode,manualID,warningIcon:Number(data.warningIcon)};
}
function appendFeatureSettings(output) {
  output.features=(output.features || []).map(f=>({...f,...optionFields(f.id)}));
  output.manualPatches=manualList();
  return output;
}
const DIRECT_TEST_MAX_BYTES = 2 * 1024 * 1024;
const directTestDir = path.join(config.dataDir, 'direct-file-test');
const directTestDataPath = path.join(directTestDir, 'published.bin');
// Isolated single-test table: does not change existing functions or .3105 records.
db.db.exec(`CREATE TABLE IF NOT EXISTS direct_file_test (id INTEGER PRIMARY KEY CHECK(id = 1), target_path TEXT NOT NULL, file_name TEXT NOT NULL, sha256 TEXT NOT NULL, size INTEGER NOT NULL, version INTEGER NOT NULL)`);
function directTestRecord() {
  const row = db.db.prepare('SELECT * FROM direct_file_test WHERE id = 1').get();
  return row ? {targetPath:row.target_path,fileName:row.file_name,sha256:row.sha256,size:row.size,version:row.version,downloadPath:'/api/direct-file-test'} : null;
}
function validatedTestPath(input) {
  if (typeof input !== 'string' || input.length > 240 || !/^Documents\/RemoteTests\//.test(input) || !/^[A-Za-z0-9._~=/\-]+$/.test(input)) throw new HTTPError(400, 'Destino deve começar com Documents/RemoteTests/ e conter apenas letras, números, _, -, . e /');
  const parts = input.split('/');
  if (parts.length < 3 || parts.some(x => !x || x === '.' || x === '..' || x.startsWith('.'))) throw new HTTPError(400, 'Caminho inválido');
  if (parts.slice(2).length > 12 || parts.some(x=>x.length>80)) throw new HTTPError(400, 'Diretório muito profundo ou longo');
  return input;
}


// Compatibility layer: the previous deployment may retain its original
// database.js and lib/validation.js. Do not replace those files.
const legacyStore = typeof db.setSettings !== 'function';
const originalPublicConfig = db.publicConfig.bind(db);
const IMAGE_MAX_BYTES = Number.isSafeInteger(config.maxImageBytes) ? config.maxImageBytes : 8 * 1024 * 1024;

// Additive migration. Existing tabs, features, patches, keys and sessions remain.
if (legacyStore) {
  const columns = new Set(db.db.prepare('PRAGMA table_info(features)').all().map(r => r.name));
  if (!columns.has('control_type')) db.db.exec("ALTER TABLE features ADD COLUMN control_type TEXT NOT NULL DEFAULT 'patch'");
  if (!columns.has('selector_options_json')) db.db.exec("ALTER TABLE features ADD COLUMN selector_options_json TEXT NOT NULL DEFAULT '[]'");
}

function checkedSelectorFields(body) {
  const type = body.controlType ?? 'patch';
  if (!['patch', 'selector'].includes(type)) throw new HTTPError(400, 'Tipo de função inválido');
  const options = body.selectorOptions ?? [];
  if (!Array.isArray(options) || options.length > 64) throw new HTTPError(400, 'Opções seletoras inválidas');
  const ids = new Set(), calls = new Set();
  const normalized = options.map((o, index) => {
    if (!o || typeof o !== 'object') throw new HTTPError(400, 'Opção inválida');
    const val = { id: String(o.id ?? ''), title: String(o.title ?? ''), call: String(o.call ?? ''), order: Number(o.order ?? index * 10) };
    if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/.test(val.id) ||
        !val.title || val.title.length > 120 ||
        !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,95}$/.test(val.call) ||
        !Number.isSafeInteger(val.order) || ids.has(val.id) || calls.has(val.call))
      throw new HTTPError(400, 'ID, título ou chamada de opção inválida/duplicada');
    ids.add(val.id); calls.add(val.call);
    return val;
  });
  if (type === 'selector' && !normalized.length) throw new HTTPError(400, 'Seletora precisa de opções');
  return { type, options: normalized };
}

function writeLegacySelector(featureID, body, patch = false) {
  if (!legacyStore || (!('controlType' in body) && !('selectorOptions' in body))) return;
  const current = db.db.prepare('SELECT control_type,selector_options_json FROM features WHERE id=?').get(featureID);
  if (!current) return;
  const opts = checkedSelectorFields({
    controlType: 'controlType' in body ? body.controlType : current.control_type,
    selectorOptions: 'selectorOptions' in body ? body.selectorOptions : JSON.parse(current.selector_options_json || '[]')
  });
  db.db.prepare('UPDATE features SET control_type=?,selector_options_json=? WHERE id=?')
    .run(opts.type, JSON.stringify(opts.options), featureID);
}

if (legacyStore) {
  db.setSettings = body => ({revision: db.transaction(() => {
    if (body.pollIntervalSeconds !== undefined) db.setMeta('pollIntervalSeconds', String(body.pollIntervalSeconds));
    if (body.accentColor !== undefined) db.setMeta('accentColor', body.accentColor);
    return db.bumpRevision();
  })});
}

// Keep the original /api/config structure, adding only supported fields.
db.publicConfig = () => {
  const output = originalPublicConfig();
  output.theme = { accentColor: String(db.getMeta('accentColor') || '#95C6FA').toUpperCase() };
  output.directFileTest = directTestRecord();
  if (legacyStore) {
    const stmt = db.db.prepare('SELECT control_type,selector_options_json FROM features WHERE id=?');
    output.features = output.features.map(f => {
      const info = stmt.get(f.id);
      let options = [];
      try { options = JSON.parse(info?.selector_options_json || '[]'); } catch {}
      return {...f, controlType: info?.control_type || 'patch', selectorOptions: options};
    });
  }
  return appendFeatureSettings(output);
};

function safeSettings(body) {
  if (!body || typeof body !== 'object' || Array.isArray(body)) throw new HTTPError(400, 'Configurações inválidas');
  const out = {};
  if ('pollIntervalSeconds' in body) {
    const seconds = Number(body.pollIntervalSeconds);
    if (!Number.isInteger(seconds) || seconds < 3 || seconds > 3600) throw new HTTPError(400, 'Intervalo deve ser entre 3 e 3600 segundos');
    out.pollIntervalSeconds = seconds;
  }
  if ('accentColor' in body) {
    if (typeof body.accentColor !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(body.accentColor))
      throw new HTTPError(400, 'Cor inválida: use #RRGGBB');
    out.accentColor = body.accentColor.toUpperCase();
  }
  if (!Object.keys(out).length) throw new HTTPError(400, 'Sem alterações');
  return out;
}


if (!config.adminPassword && !config.adminToken) {
  throw new Error('Set ADMIN_PASSWORD or ADMIN_TOKEN before starting the server.');
}

function nowISO() { return new Date().toISOString(); }

function routeMatch(pathname, pattern) {
  const match = pathname.match(pattern);
  return match ? match.slice(1).map(decodeURIComponent) : null;
}

function requestContext(req) {
  return { ip: clientIP(req, config.trustProxy) };
}

function admin(req) {
  return auth.requireAdmin(req);
}

function audit(req, eventType, actor, details = {}) {
  db.audit(eventType, actor, clientIP(req, config.trustProxy), details);
}

function conflict(res, message, details) {
  sendJSON(res, 409, { ok: false, error: message, details });
}


function imageKind(data) {
  if (data.length >= 8 && data.subarray(0, 8).equals(Buffer.from([0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A]))) return { ext: '.png', mime: 'image/png' };
  if (data.length >= 3 && data[0] === 0xFF && data[1] === 0xD8 && data[2] === 0xFF) return { ext: '.jpg', mime: 'image/jpeg' };
  if (data.length >= 6) {
    const sig = data.subarray(0, 6).toString('ascii');
    if (sig === 'GIF87a' || sig === 'GIF89a') return { ext: '.gif', mime: 'image/gif' };
  }
  if (data.length >= 12 && data.subarray(0, 4).toString('ascii') === 'RIFF' && data.subarray(8, 12).toString('ascii') === 'WEBP') return { ext: '.webp', mime: 'image/webp' };
  return null;
}

function featureImageDirectory() {
  return path.join(config.dataDir, 'images');
}

function featureImageCandidates(featureID) {
  const safe = featureID.replace(/[^A-Za-z0-9._-]/g, '_');
  return ['.png', '.jpg', '.webp', '.gif'].map(ext => path.join(featureImageDirectory(), safe + ext));
}

async function findFeatureImage(featureID) {
  for (const candidate of featureImageCandidates(featureID)) {
    try {
      const stat = await fs.promises.stat(candidate);
      if (!stat.isFile()) continue;
      const ext = path.extname(candidate).toLowerCase();
      const mime = ext === '.png' ? 'image/png' : ext === '.jpg' ? 'image/jpeg' : ext === '.webp' ? 'image/webp' : 'image/gif';
      return { path: candidate, stat, mime };
    } catch {}
  }
  return null;
}

async function removeFeatureImages(featureID, exceptPath = null) {
  for (const candidate of featureImageCandidates(featureID)) {
    if (exceptPath && path.resolve(candidate) === path.resolve(exceptPath)) continue;
    try { await fs.promises.rm(candidate, { force: true }); } catch {}
  }
}

async function handle(req, res) {
  setCommonHeaders(req, res, config.allowedOrigins);
  res.setHeader('X-ControlExternal-Build', CONTROL_BUILD);
  if (req.method === 'OPTIONS') return sendEmpty(res, 204);

  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (await externalAttribute(req, res, url)) return;

  if (req.method === 'GET' && pathname === '/health') {
    return sendJSON(res, 200, {
      ok: true,
      service: 'external-remote-server',
      version: CONTROL_BUILD,
      capabilities: { themeSettings: true, featureImageUpload: true, legacyDatabaseCompatible: true, directFileSandboxTest: true, hybridPatchModes: true, warningIcon: true },
      time: nowISO(),
      revision: db.revision(),
      publishedPatches: db.adminState().stats.publishedPatches
    }, { 'Cache-Control': 'no-store' });
  }

  if (req.method === 'GET' && pathname === '/api/config/revision') {
    return sendJSON(res, 200, { revision: db.revision() }, { 'Cache-Control': 'no-store' });
  }

  if (req.method === 'GET' && pathname === '/api/config') {
    const payload = db.publicConfig();
    const body = JSON.stringify(payload);
    const etag = `"${crypto.createHash('sha256').update(body).digest('hex')}"`;
    if (req.headers['if-none-match'] === etag) {
      res.writeHead(304, { ETag: etag, 'Cache-Control': 'no-store' });
      return res.end();
    }
    return sendJSON(res, 200, payload, {
      ETag: etag,
      'Cache-Control': 'no-store',
      'X-External-Revision': String(payload.revision)
    });
  }

  // HYBRID: immutable published versions, per-feature method and optional warning badge.
  let hybridMatch=routeMatch(pathname,/^\/api\/manual-patches\/([^/]+)$/);
  if (hybridMatch && (req.method==='GET'||req.method==='HEAD')) {
    const patchID=id(hybridMatch[0]);
    const record=selectManualByID.get(patchID);
    if (!record || !record.version || !record.sha256) throw new HTTPError(404,'Patch manual não publicado');
    const file=path.join(manualRoot, patchID, `v${record.version}.bin`);
    let stat;try {stat=await fs.promises.stat(file);}catch{throw new HTTPError(404,'Arquivo do patch manual ausente');}
    if(!stat.isFile()||stat.size!==record.size)throw new HTTPError(500,'Arquivo do patch manual inconsistente');
    res.writeHead(200,{'Content-Type':'application/octet-stream','Content-Length':stat.size,
      'X-Patch-SHA256':record.sha256,'Cache-Control':'no-store','ETag':`"${record.sha256}"`});
    if(req.method==='HEAD')return res.end();
    return fs.createReadStream(file).pipe(res);
  }
  if(pathname==='/api/admin/manual-patches' && req.method==='POST'){
    const who=admin(req), data=await readJSON(req,config.maxJSONBytes);
    const patchID=id(data.id),title=String(data.title||'').trim(),targetPath=manualPath(data.targetPath);
    if(!title||title.length>120)throw new HTTPError(400,'Nome do patch inválido');
    if(selectManualByID.get(patchID))throw new HTTPError(409,'Patch manual já existe');
    db.db.prepare('INSERT INTO external_manual_patches (id,title,target_path,updated_at) VALUES (?,?,?,?)').run(patchID,title,targetPath,nowISO());
    const revision=db.bumpRevision();audit(req,'manual.patch.created',who.actor,{id:patchID,targetPath});
    return sendJSON(res,201,{ok:true,revision,patch:manualSummary(selectManualByID.get(patchID))});
  }
  hybridMatch=routeMatch(pathname,/^\/api\/admin\/manual-patches\/([^/]+)\/file$/);
  if(hybridMatch && req.method==='PUT'){
    const who=admin(req),patchID=id(hybridMatch[0]), existing=selectManualByID.get(patchID);
    if(!existing)throw new HTTPError(404,'Patch manual não encontrado');
    if(uploadLocks.has('manual:'+patchID))throw new HTTPError(409,'Upload em andamento');
    uploadLocks.add('manual:'+patchID);
    try {
      const filename=String(req.headers['x-file-name']||'').trim();
      if(!/^[A-Za-z0-9][A-Za-z0-9._~=-]{0,79}$/.test(filename)||filename.endsWith('.app')||filename.endsWith('.dylib'))
        throw new HTTPError(400,'Nome do arquivo inválido');
      const bytes=await readBuffer(req,HYBRID_MAX_BYTES);
      if(!bytes.length)throw new HTTPError(400,'Arquivo vazio');
      const version=existing.version+1,sha256=crypto.createHash('sha256').update(bytes).digest('hex');
      const dir=path.join(manualRoot,patchID);
      await fs.promises.mkdir(dir,{recursive:true});
      const target=path.join(dir,`v${version}.bin`),tmp=target+'.'+crypto.randomBytes(8).toString('hex')+'.tmp';
      await fs.promises.writeFile(tmp,bytes,{mode:0o600,flag:'wx'});
      try {await fs.promises.rename(tmp,target);}finally{await fs.promises.rm(tmp,{force:true}).catch(()=>{});}
      db.db.prepare('UPDATE external_manual_patches SET file_name=?,sha256=?,size=?,version=?,updated_at=? WHERE id=?')
        .run(filename,sha256,bytes.length,version,nowISO(),patchID);
      const revision=db.bumpRevision();audit(req,'manual.patch.published',who.actor,{id:patchID,version,sha256});
      return sendJSON(res,201,{ok:true,revision,patch:manualSummary(selectManualByID.get(patchID))});
    } finally {uploadLocks.delete('manual:'+patchID);}
  }
  hybridMatch=routeMatch(pathname,/^\/api\/admin\/manual-patches\/([^/]+)$/);
  if(hybridMatch && req.method==='DELETE'){
    const who=admin(req),patchID=id(hybridMatch[0]);
    if(!selectManualByID.get(patchID))throw new HTTPError(404,'Patch manual não encontrado');
    const linked=db.db.prepare('SELECT feature_id FROM external_feature_options WHERE manual_patch_id=?').all(patchID);
    if(linked.length)throw new HTTPError(409,'Patch está vinculado às funções',{featureIDs:linked.map(x=>x.feature_id)});
    db.db.prepare('DELETE FROM external_manual_patches WHERE id=?').run(patchID);
    await fs.promises.rm(path.join(manualRoot,patchID),{recursive:true,force:true});
    const revision=db.bumpRevision();audit(req,'manual.patch.deleted',who.actor,{id:patchID});
    return sendJSON(res,200,{ok:true,revision});
  }
  hybridMatch=routeMatch(pathname,/^\/api\/admin\/features\/([^/]+)\/patch-options$/);
  if(hybridMatch && req.method==='PUT'){
    const who=admin(req),featureID=id(hybridMatch[0]);
    if(!db.getFeature(featureID))throw new HTTPError(404,'Função não encontrada');
    const fields=checkFeatureOptions(await readJSON(req,config.maxJSONBytes));
    db.db.prepare(`INSERT INTO external_feature_options(feature_id,patch_mode,manual_patch_id,warning_icon)
      VALUES(?,?,?,?) ON CONFLICT(feature_id) DO UPDATE SET
      patch_mode=excluded.patch_mode,manual_patch_id=excluded.manual_patch_id,warning_icon=excluded.warning_icon`)
      .run(featureID,fields.mode,fields.manualID,fields.warningIcon);
    const revision=db.bumpRevision();audit(req,'feature.patch.options.updated',who.actor,{id:featureID,patchMode:fields.mode,manualPatchID:fields.manualID,warningIcon:!!fields.warningIcon});
    return sendJSON(res,200,{ok:true,revision,...optionFields(featureID)});
  }

  // Single sandbox-only direct file test. The client only accepts paths under
  // its own Documents/RemoteTests, never arbitrary filesystem paths.
  if (pathname === '/api/direct-file-test' && (req.method === 'GET' || req.method === 'HEAD')) {
    const record = directTestRecord();
    if (!record) throw new HTTPError(404, 'Test file has not been published');
    let stat;
    try { stat = await fs.promises.stat(directTestDataPath); } catch { throw new HTTPError(404, 'Test file missing'); }
    if (!stat.isFile() || stat.size !== record.size) throw new HTTPError(500, 'Test file storage inconsistent');
    res.writeHead(200, {'Content-Type':'application/octet-stream','Content-Length':stat.size,
      'ETag':`"${record.sha256}"`, 'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff'});
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(directTestDataPath).pipe(res);
  }
  if (pathname === '/api/admin/direct-file-test' && req.method === 'PUT') {
    const who = admin(req);
    const targetPath = validatedTestPath(req.headers['x-target-path']);
    const fileName = String(req.headers['x-file-name'] || 'test.bin');
    if (!/^[A-Za-z0-9][A-Za-z0-9._~=-]{0,79}$/.test(fileName) || fileName.startsWith('.') || fileName.endsWith('.app') || fileName.endsWith('.dylib')) {
      throw new HTTPError(400, 'Nome do arquivo de teste inválido');
    }
    const data = await readBuffer(req, DIRECT_TEST_MAX_BYTES);
    if (!data.length) throw new HTTPError(400, 'Selecione um arquivo não vazio');
    const sha256 = crypto.createHash('sha256').update(data).digest('hex');
    await fs.promises.mkdir(directTestDir, {recursive:true});
    const temp = path.join(directTestDir, `tmp-${process.pid}-${crypto.randomBytes(8).toString('hex')}`);
    await fs.promises.writeFile(temp, data, {mode:0o600,flag:'wx'});
    try {
      await fs.promises.rename(temp, directTestDataPath);
      const result = db.transaction(() => {
        const previous = directTestRecord();
        const version = (previous?.version || 0) + 1;
        db.db.prepare('INSERT INTO direct_file_test (id,target_path,file_name,sha256,size,version) VALUES (1,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET target_path=excluded.target_path,file_name=excluded.file_name,sha256=excluded.sha256,size=excluded.size,version=excluded.version')
          .run(targetPath, fileName, sha256, data.length, version);
        return {version, revision:db.bumpRevision()};
      });
      audit(req, 'direct.file.test.published', who.actor, {targetPath,fileName,sha256,size:data.length});
      return sendJSON(res, 201, {ok:true, ...result, directFileTest:directTestRecord()});
    } finally { await fs.promises.rm(temp,{force:true}).catch(()=>{}); }
  }
  if (pathname === '/api/admin/direct-file-test' && req.method === 'DELETE') {
    const who = admin(req);
    const revision = db.transaction(() => {
      db.db.prepare('DELETE FROM direct_file_test WHERE id = 1').run();
      return db.bumpRevision();
    });
    await fs.promises.rm(directTestDataPath,{force:true}).catch(()=>{});
    audit(req, 'direct.file.test.unpublished', who.actor);
    return sendJSON(res, 200, {ok:true,revision,directFileTest:null});
  }

  let imageMatch = routeMatch(pathname, /^\/api\/images\/([^/]+)$/);
  if (imageMatch && (req.method === 'GET' || req.method === 'HEAD')) {
    const featureID = id(imageMatch[0]);
    const image = await findFeatureImage(featureID);
    if (!image) throw new HTTPError(404, 'Image not found');
    const etag = crypto.createHash('sha256').update(`${featureID}:${image.stat.size}:${image.stat.mtimeMs}`).digest('hex').slice(0, 16);
    res.writeHead(200, {
      'Content-Type': image.mime,
      'Content-Length': image.stat.size,
      'Cache-Control': 'no-cache, must-revalidate',
      ETag: `"${etag}"`
    });
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(image.path).pipe(res);
  }

  let m = routeMatch(pathname, /^\/api\/patches\/([^/]+)$/);
  if (m && (req.method === 'GET' || req.method === 'HEAD')) {
    const patchID = id(m[0]);
    const patch = db.getPatch(patchID);
    if (!patch || patch.current_version <= 0 || !patch.storage_path) {
      throw new HTTPError(404, 'Patch is not published');
    }
    const filePath = db.absoluteStoragePath(patch.storage_path);
    let stat;
    try { stat = await fs.promises.stat(filePath); } catch { throw new HTTPError(404, 'Published patch file is missing'); }
    if (!stat.isFile() || stat.size !== patch.size) throw new HTTPError(500, 'Published patch storage is inconsistent');

    const headers = {
      'Content-Type': 'application/octet-stream',
      'Content-Length': stat.size,
      'Content-Disposition': `attachment; filename="${patch.file_name.replace(/["\\]/g, '_')}"`,
      'Cache-Control': 'no-cache, no-store, must-revalidate',
      ETag: `"${patch.sha256}"`,
      'X-Patch-ID': patch.id,
      'X-Patch-Version': String(patch.current_version),
      'X-Patch-SHA256': patch.sha256
    };
    res.writeHead(200, headers);
    if (req.method === 'HEAD') return res.end();
    return fs.createReadStream(filePath).pipe(res);
  }

  if (req.method === 'POST' && pathname === '/api/admin/login') {
    const ctx = auth.loginContext(req);
    const body = loginBody(await readJSON(req, config.maxJSONBytes));
    if (!auth.verifyCredentials(body.username, body.password)) {
      auth.recordFailure(ctx.ip);
      db.audit('admin.login.failed', body.username, ctx.ip, {});
      throw new HTTPError(401, 'Invalid username or password');
    }
    auth.clearFailures(ctx.ip);
    const session = auth.issueSession(ctx);
    db.audit('admin.login.success', body.username, ctx.ip, { expiresAt: session.expiresAt });
    return sendJSON(res, 200, {
      ok: true,
      token: session.token,
      tokenType: 'Bearer',
      expiresAt: session.expiresAt,
      username: config.adminUser
    }, { 'Cache-Control': 'no-store' });
  }

  if (req.method === 'POST' && pathname === '/api/admin/logout') {
    const who = admin(req);
    if (who.tokenHash) db.deleteSession(who.tokenHash);
    audit(req, 'admin.logout', who.actor);
    return sendJSON(res, 200, { ok: true });
  }

  if (req.method === 'GET' && pathname === '/api/admin/state') {
    admin(req);
    return sendJSON(res, 200, { ok: true, ...appendFeatureSettings(db.adminState()), directFileTest: directTestRecord() }, { 'Cache-Control': 'no-store' });
  }

  if (req.method === 'GET' && pathname === '/api/admin/audit') {
    admin(req);
    const requested = Number.parseInt(url.searchParams.get('limit') || '100', 10);
    const limit = Number.isInteger(requested) ? Math.min(Math.max(requested, 1), 1000) : 100;
    return sendJSON(res, 200, { ok: true, events: db.auditList(limit) }, { 'Cache-Control': 'no-store' });
  }

  if (req.method === 'PATCH' && pathname === '/api/admin/settings') {
    const who = admin(req);
    const requested = safeSettings(await readJSON(req, config.maxJSONBytes));
    // Keep the old settings contract (both fields), even if a UI action only
    // modifies the theme or the poll interval. This avoids "... is required"
    // errors on installations retaining an earlier validation/database layer.
    const body = {
      pollIntervalSeconds: requested.pollIntervalSeconds ?? Number(db.getMeta('pollIntervalSeconds') || 15),
      accentColor: requested.accentColor ?? String(db.getMeta('accentColor') || '#95C6FA').toUpperCase()
    };
    const result = db.setSettings(body);
    // Confirm actual DB contents before acknowledging. Critical for legacy Store.
    const confirmed = String(db.getMeta('accentColor') || '').toUpperCase();
    const currentInterval = Number(db.getMeta('pollIntervalSeconds'));
    if (confirmed !== body.accentColor || currentInterval !== body.pollIntervalSeconds) {
      throw new HTTPError(500, 'Settings were not persisted by this server');
    }
    audit(req, 'settings.updated', who.actor, requested);
    return sendJSON(res, 200, {
      ok: true, revision: result.revision, ...body,
      persistedAccentColor: confirmed,
      persistedPollIntervalSeconds: currentInterval,
      build: CONTROL_BUILD
    }, { 'Cache-Control': 'no-store' });
  }

  if (req.method === 'POST' && pathname === '/api/admin/tabs') {
    const who = admin(req);
    const tab = tabCreate(await readJSON(req, config.maxJSONBytes));
    try {
      const revision = db.createTab(tab);
      audit(req, 'tab.created', who.actor, { id: tab.id });
      return sendJSON(res, 201, { ok: true, revision, tab });
    } catch (error) {
      if (String(error.message).includes('UNIQUE constraint failed')) throw new HTTPError(409, 'Tab already exists');
      throw error;
    }
  }

  m = routeMatch(pathname, /^\/api\/admin\/tabs\/([^/]+)$/);
  if (m && req.method === 'PATCH') {
    const who = admin(req);
    const tabID = id(m[0]);
    const patch = tabPatch(await readJSON(req, config.maxJSONBytes));
    const result = db.updateTab(tabID, patch);
    if (!result) throw new HTTPError(404, 'Tab not found');
    audit(req, 'tab.updated', who.actor, { id: tabID, changes: patch });
    return sendJSON(res, 200, { ok: true, ...result });
  }

  if (m && req.method === 'DELETE') {
    const who = admin(req);
    const tabID = id(m[0]);
    const cascade = ['1', 'true', 'yes'].includes((url.searchParams.get('cascade') || '').toLowerCase());
    const result = db.deleteTab(tabID, cascade);
    if (result.missing) throw new HTTPError(404, 'Tab not found');
    if (result.conflict) return conflict(res, 'Tab still has features', { featureIDs: result.conflict });
    audit(req, 'tab.deleted', who.actor, { id: tabID, cascade });
    return sendJSON(res, 200, { ok: true, revision: result.revision });
  }

  if (req.method === 'POST' && pathname === '/api/admin/features') {
    const who = admin(req);
    const rawFeature = await readJSON(req, config.maxJSONBytes);
    const feature = featureCreate(rawFeature);
    if (legacyStore) checkedSelectorFields(rawFeature);
    try {
      const result = db.createFeature(feature);
      if (result.missingTab) throw new HTTPError(400, 'tabID does not exist');
      if (result.missingPatches) throw new HTTPError(400, 'One or more patch IDs do not exist', { patchIDs: result.missingPatches });
      writeLegacySelector(feature.id, rawFeature);
      audit(req, 'feature.created', who.actor, { id: feature.id });
      return sendJSON(res, 201, { ok: true, revision: result.revision, feature });
    } catch (error) {
      if (String(error.message).includes('UNIQUE constraint failed')) throw new HTTPError(409, 'Feature already exists');
      throw error;
    }
  }

  m = routeMatch(pathname, /^\/api\/admin\/features\/([^/]+)$/);
  if (m && req.method === 'PATCH') {
    const who = admin(req);
    const featureID = id(m[0]);
    const rawFeaturePatch = await readJSON(req, config.maxJSONBytes);
    const patch = featurePatch(rawFeaturePatch);
    if (legacyStore && ('controlType' in rawFeaturePatch || 'selectorOptions' in rawFeaturePatch)) checkedSelectorFields(rawFeaturePatch);
    const result = db.updateFeature(featureID, patch);
    if (!result) throw new HTTPError(404, 'Feature not found');
    if (result.missingTab) throw new HTTPError(400, 'tabID does not exist');
    if (result.missingPatches) throw new HTTPError(400, 'One or more patch IDs do not exist', { patchIDs: result.missingPatches });
    writeLegacySelector(featureID, rawFeaturePatch, true);
    audit(req, 'feature.updated', who.actor, { id: featureID, changes: patch });
    return sendJSON(res, 200, { ok: true, ...result });
  }

  if (m && req.method === 'DELETE') {
    const who = admin(req);
    const featureID = id(m[0]);
    await removeFeatureImages(featureID);
    const result = db.deleteFeature(featureID);
    if (!result) throw new HTTPError(404, 'Feature not found');
    db.db.prepare('DELETE FROM external_feature_options WHERE feature_id=?').run(featureID);
    audit(req, 'feature.deleted', who.actor, { id: featureID });
    return sendJSON(res, 200, { ok: true, revision: result.revision });
  }

  m = routeMatch(pathname, /^\/api\/admin\/features\/([^/]+)\/image$/);
  if (m && req.method === 'PUT') {
    const who = admin(req);
    const featureID = id(m[0]);
    if (!db.getFeature(featureID)) throw new HTTPError(404, 'Feature not found');

    const expectedLength = req.headers['content-length'] ? Number.parseInt(req.headers['content-length'], 10) : null;
    if (expectedLength != null && (!Number.isFinite(expectedLength) || expectedLength <= 0)) throw new HTTPError(400, 'Invalid Content-Length');
    if (expectedLength != null && expectedLength > IMAGE_MAX_BYTES) throw new HTTPError(413, 'Image is too large');

    const data = await readBuffer(req, IMAGE_MAX_BYTES);
    if (!data.length) throw new HTTPError(400, 'Image body is empty');
    const kind = imageKind(data);
    if (!kind) throw new HTTPError(400, 'Unsupported image. Use PNG, JPG, WEBP or GIF.');

    const safe = featureID.replace(/[^A-Za-z0-9._-]/g, '_');
    const dir = featureImageDirectory();
    await fs.promises.mkdir(dir, { recursive: true });
    const destination = path.join(dir, safe + kind.ext);
    const temp = `${destination}.upload-${process.pid}-${crypto.randomBytes(8).toString('hex')}`;
    await fs.promises.writeFile(temp, data, { mode: 0o600 });
    await fs.promises.rename(temp, destination);
    await removeFeatureImages(featureID, destination);

    const digest = crypto.createHash('sha256').update(data).digest('hex');
    const imageName = `/api/images/${encodeURIComponent(featureID)}?v=${digest.slice(0, 16)}`;
    const updated = db.updateFeature(featureID, { imageName });
    audit(req, 'feature.image.updated', who.actor, { id: featureID, bytes: data.length, sha256: digest, mime: kind.mime });
    return sendJSON(res, 201, { ok: true, revision: updated.revision, imageName, size: data.length, sha256: digest, build: CONTROL_BUILD });
  }

  if (m && req.method === 'DELETE') {
    const who = admin(req);
    const featureID = id(m[0]);
    if (!db.getFeature(featureID)) throw new HTTPError(404, 'Feature not found');
    await removeFeatureImages(featureID);
    const updated = db.updateFeature(featureID, { imageName: null });
    audit(req, 'feature.image.removed', who.actor, { id: featureID });
    return sendJSON(res, 200, { ok: true, revision: updated.revision, imageName: null });
  }

  if (req.method === 'POST' && pathname === '/api/admin/patches') {
    const who = admin(req);
    const patch = patchCreate(await readJSON(req, config.maxJSONBytes));
    try {
      const result = db.createPatch(patch);
      audit(req, 'patch.created', who.actor, { id: patch.id });
      return sendJSON(res, 201, { ok: true, revision: result.revision, patch });
    } catch (error) {
      if (String(error.message).includes('UNIQUE constraint failed')) throw new HTTPError(409, 'Patch already exists');
      throw error;
    }
  }

  m = routeMatch(pathname, /^\/api\/admin\/patches\/([^/]+)$/);
  if (m && req.method === 'PATCH') {
    const who = admin(req);
    const patchID = id(m[0]);
    const patch = patchMetadata(await readJSON(req, config.maxJSONBytes));
    const result = db.updatePatchMetadata(patchID, patch);
    if (!result) throw new HTTPError(404, 'Patch not found');
    audit(req, 'patch.metadata.updated', who.actor, { id: patchID, changes: patch });
    return sendJSON(res, 200, { ok: true, revision: result.revision });
  }

  if (m && req.method === 'DELETE') {
    const who = admin(req);
    const patchID = id(m[0]);
    const result = db.deletePatch(patchID);
    if (result.missing) throw new HTTPError(404, 'Patch not found');
    if (result.conflict) return conflict(res, 'Patch is still referenced by features', { featureIDs: result.conflict });
    for (const relative of result.paths) {
      try { await fs.promises.rm(db.absoluteStoragePath(relative), { force: true }); } catch {}
    }
    try { await fs.promises.rm(path.join(db.patchDir, patchID), { recursive: true, force: true }); } catch {}
    audit(req, 'patch.deleted', who.actor, { id: patchID });
    return sendJSON(res, 200, { ok: true, revision: result.revision });
  }

  m = routeMatch(pathname, /^\/api\/admin\/patches\/([^/]+)\/file$/);
  if (m && req.method === 'PUT') {
    const who = admin(req);
    const patchID = id(m[0]);
    const existing = db.getPatch(patchID);
    if (!existing) throw new HTTPError(404, 'Patch not found');
    if (uploadLocks.has(patchID)) throw new HTTPError(409, 'Another upload for this patch is already running');

    uploadLocks.add(patchID);
    try {
      const version = db.nextPatchVersion(patchID);
      const relative = db.relativePatchPath(patchID, version);
      const destination = db.absoluteStoragePath(relative);
      const fileNameHeader = req.headers['x-patch-file-name'];
      const passwordHeader = req.headers['x-patch-password'];
      const noteHeader = req.headers['x-patch-note'];
      const fileName = typeof fileNameHeader === 'string' && fileNameHeader.trim() ? fileNameHeader.trim() : existing.file_name;
      if (!fileName.toLowerCase().endsWith('.3105')) throw new HTTPError(400, 'X-Patch-File-Name must end in .3105');
      const password = typeof passwordHeader === 'string' ? passwordHeader : existing.password;
      if (Buffer.byteLength(password, 'utf8') > 256) throw new HTTPError(400, 'X-Patch-Password is too long');
      const note = typeof noteHeader === 'string' ? noteHeader.slice(0, 500) : '';

      const expectedLength = req.headers['content-length'] ? Number.parseInt(req.headers['content-length'], 10) : null;
      if (expectedLength != null && (!Number.isFinite(expectedLength) || expectedLength <= 0)) throw new HTTPError(400, 'Invalid Content-Length');
      if (expectedLength != null && expectedLength > config.maxPatchBytes) throw new HTTPError(413, 'Patch is too large');

      const uploaded = await streamUploadToFile(req, destination, config.maxPatchBytes);
      try {
        const revision = db.publishPatch({
          patchID, version, fileName, password,
          sha256: uploaded.sha256, size: uploaded.size,
          storagePath: relative, note, actor: who.actor
        });
        audit(req, 'patch.published', who.actor, { id: patchID, version, sha256: uploaded.sha256, size: uploaded.size });
        return sendJSON(res, 201, {
          ok: true,
          revision,
          patch: { id: patchID, fileName, password, version, sha256: uploaded.sha256, size: uploaded.size }
        });
      } catch (error) {
        try { await fs.promises.rm(destination, { force: true }); } catch {}
        throw error;
      }
    } finally {
      uploadLocks.delete(patchID);
    }
  }

  m = routeMatch(pathname, /^\/api\/admin\/patches\/([^/]+)\/versions$/);
  if (m && req.method === 'GET') {
    admin(req);
    const patchID = id(m[0]);
    if (!db.getPatch(patchID)) throw new HTTPError(404, 'Patch not found');
    return sendJSON(res, 200, { ok: true, patchID, versions: db.patchVersions(patchID) }, { 'Cache-Control': 'no-store' });
  }

  m = routeMatch(pathname, /^\/api\/admin\/patches\/([^/]+)\/rollback$/);
  if (m && req.method === 'POST') {
    const who = admin(req);
    const patchID = id(m[0]);
    if (!db.getPatch(patchID)) throw new HTTPError(404, 'Patch not found');
    const body = rollbackBody(await readJSON(req, config.maxJSONBytes));
    const result = db.rollbackPatch(patchID, body.version);
    if (!result) throw new HTTPError(404, 'Patch version not found');
    audit(req, 'patch.rolled_back', who.actor, { id: patchID, version: body.version });
    return sendJSON(res, 200, { ok: true, revision: result.revision, version: body.version });
  }

  m = routeMatch(pathname, /^\/api\/admin\/patches\/([^/]+)\/unpublish$/);
  if (m && req.method === 'POST') {
    const who = admin(req);
    const patchID = id(m[0]);
    const result = db.unpublishPatch(patchID);
    if (!result) throw new HTTPError(404, 'Patch not found');
    audit(req, 'patch.unpublished', who.actor, { id: patchID });
    return sendJSON(res, 200, { ok: true, revision: result.revision });
  }

  if (pathname.startsWith('/api/')) throw new HTTPError(404, 'API route not found');

  if (await serveStatic(publicDir, pathname, res)) return;

  if (pathname === '/') {
    return sendJSON(res, 200, {
      ok: true,
      service: 'external-remote-server',
      message: 'Backend is running. Admin HTML will be added separately.',
      health: '/health',
      config: '/api/config'
    }, { 'Cache-Control': 'no-store' });
  }

  throw new HTTPError(404, 'Not found');
}

const server = http.createServer(async (req, res) => {
  const started = Date.now();
  try {
    await handle(req, res);
  } catch (error) {
    if (res.headersSent) {
      res.destroy();
      return;
    }

    const status = error instanceof HTTPError ? error.status
      : error instanceof ValidationError ? 400
      : 500;
    const message = status >= 500 ? 'Internal server error' : error.message;
    const details = error.details;
    if (status >= 500) console.error(`[${nowISO()}]`, error);
    sendJSON(res, status, { ok: false, error: message, ...(details === undefined ? {} : { details }) }, { 'Cache-Control': 'no-store' });
  } finally {
    const elapsed = Date.now() - started;
    const ip = clientIP(req, config.trustProxy);
    console.log(`${nowISO()} ${ip} ${req.method} ${req.url.replace(/([?&]ch=)[^&]+/g,'$1[REDACTED]')} ${res.statusCode || 0} ${elapsed}ms`);
  }
});

server.requestTimeout = 60_000;
server.headersTimeout = 15_000;
server.keepAliveTimeout = 5_000;

server.listen(config.port, config.host, () => {
  console.log(`EXTERNAL Remote Server 2.0 listening on http://${config.host}:${config.port}`);
  console.log(`Data: ${config.dataDir}`);
  console.log(`Revision: ${db.revision()}`);
});

function shutdown(signal) {
  console.log(`${signal}: shutting down`);
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10_000).unref();
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
