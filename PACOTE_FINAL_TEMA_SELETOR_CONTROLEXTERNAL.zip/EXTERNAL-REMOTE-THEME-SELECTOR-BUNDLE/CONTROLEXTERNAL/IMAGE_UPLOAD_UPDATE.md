# IMAGE upload update

- Admin `IMAGE NAME` text field was replaced by an `IMAGE` file picker.
- Accepted formats: PNG, JPG/JPEG, WEBP and GIF.
- Maximum size: 8 MB by default (`MAX_IMAGE_BYTES`).
- Upload route: `PUT /api/admin/features/:id/image` using raw image bytes.
- Public image route: `GET /api/images/:id`.
- After upload, the feature `imageName` is updated automatically to a versioned `/api/images/...` URL.
- Existing embedded image names continue to work until a new image is uploaded.
