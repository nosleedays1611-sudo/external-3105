# Tema e função seletora

## Cor da IPA

No Dashboard há um seletor de cor e campo HEX. Salvar publica:

```json
"theme": { "accentColor": "#95C6FA" }
```

A alteração incrementa `revision`; clientes atualizados reaplicam a cor na próxima sincronização.

## Tipo de função: Função seletora

Em **Funções → Nova/Editar função**, escolha `Função seletora`.

Cada opção tem:

- ID
- Nome da opção
- Chamada
- Ordem

Exemplo:

```json
"controlType": "selector",
"selectorOptions": [
  { "id": "head", "title": "Cabeça", "call": "head", "order": 10 },
  { "id": "neck", "title": "Pescoço", "call": "neck", "order": 20 },
  { "id": "chest", "title": "Peito", "call": "chest", "order": 30 }
]
```

O `PATCH PRINCIPAL / BASE` é opcional. Quando configurado, `INJETAR` aplica esse base e guarda o backup. As opções seletoras não fazem Apply; elas apenas alteram a chamada ativa na IPA.
