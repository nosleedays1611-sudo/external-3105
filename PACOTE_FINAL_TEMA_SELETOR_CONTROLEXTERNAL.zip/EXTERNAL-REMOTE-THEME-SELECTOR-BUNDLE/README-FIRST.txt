PHASE15 — THEME + SELECTOR

APP-SOURCE:
- tema remoto por accentColor
- função controlType=selector
- switch ON mostra INJETAR / DESINJETAR 40%
- INJETAR libera o seletor (e aplica o patch base, se configurado)
- opções só mudam a chamada local; não executam Apply
- DESINJETAR restaura o base, limpa seletor e desliga
- estado e backup persistem após fechar/reabrir

CONTROLEXTERNAL:
- seletor de cor da IPA no Dashboard
- tipo de função "Função seletora"
- editor de opções com ID, Nome, Chamada e Ordem
- migração automática do SQLite existente

Validações feitas:
- Swift syntax parse
- Node syntax check
- API E2E: login, theme, create/update selector, public config
- migração de banco antigo para novas colunas
