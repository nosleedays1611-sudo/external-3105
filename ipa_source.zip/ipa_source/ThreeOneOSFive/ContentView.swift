import CryptoKit
import Foundation
import SwiftUI
import UIKit


private struct PatchSlotDefinition {
    let remoteID: String
    let fileName: String
    let password: String
}

// Canonical patch catalog copied from the V41 ContentView.
// Keep all real .3105 names here. The remote IDs are only stable API keys.
private enum PatchSlots {
    enum FunctionNormal {
        static let hsAltoNeckSemAntena = PatchSlotDefinition(
            remoteID: "fn-normal-hs-alto-pescoco-sem",
            fileName: "hs-alto-neck-sem-antena.3105",
            password: "0"
        )
        static let hsAltoNeckComAntena = PatchSlotDefinition(
            remoteID: "fn-normal-hs-alto-pescoco-com",
            fileName: "hs-alto-neck-com-antena.3105",
            password: "0"
        )
        static let hsAltoSemAntena = PatchSlotDefinition(
            remoteID: "fn-normal-hs-alto-sem",
            fileName: "hs-alto-sem-antena.3105",
            password: "0"
        )
        static let hsAlto = PatchSlotDefinition(
            remoteID: "fn-normal-hs-alto-com",
            fileName: "hs-alto.3105",
            password: "0"
        )
        static let hsNeckSemAntena = PatchSlotDefinition(
            remoteID: "fn-normal-hs-pescoco-sem",
            fileName: "hs-neck-sem-antena.3105",
            password: "0"
        )
        static let hsNeckComAntena = PatchSlotDefinition(
            remoteID: "fn-normal-hs-pescoco-com",
            fileName: "hs-neck-com-antena.3105",
            password: "0"
        )
        static let hsPeitoSemAntena = PatchSlotDefinition(
            remoteID: "fn-normal-hs-peito-sem",
            fileName: "hs-peito-sem-antena.3105",
            password: "0"
        )
        static let hsPeito = PatchSlotDefinition(
            remoteID: "fn-normal-hs-peito-com",
            fileName: "hs-peito.3105",
            password: "0"
        )
        static let magicBulletSemAntena = PatchSlotDefinition(
            remoteID: "fn-normal-magic-bullet-sem",
            fileName: "magic-bullet-sem-antena.3105",
            password: "0"
        )
        static let magicBulletComAntena = PatchSlotDefinition(
            remoteID: "fn-normal-magic-bullet-com",
            fileName: "magic-bullet-com-antena.3105",
            password: "0"
        )
        static let fps120144 = PatchSlotDefinition(
            remoteID: "fn-normal-120-144-fps",
            fileName: "120-144-fps.3105",
            password: "OG"
        )
        static let hologramaPreto = PatchSlotDefinition(
            remoteID: "fn-normal-holograma",
            fileName: "holograma-preto.3105",
            password: "0"
        )

        static let all = [
            hsAltoNeckSemAntena, hsAltoNeckComAntena,
            hsAltoSemAntena, hsAlto,
            hsNeckSemAntena, hsNeckComAntena,
            hsPeitoSemAntena, hsPeito,
            magicBulletSemAntena, magicBulletComAntena,
            fps120144, hologramaPreto
        ]
    }

    enum FunctionMax {
        static let hsAltoNeckSemAntena = PatchSlotDefinition(
            remoteID: "fn-max-hs-alto-pescoco-sem",
            fileName: "hs-alto-neck-sem-antena-max.3105",
            password: "0"
        )
        static let hsAltoNeckComAntena = PatchSlotDefinition(
            remoteID: "fn-max-hs-alto-pescoco-com",
            fileName: "hs-alto-neck-com-antena-max.3105",
            password: "0"
        )
        static let hsNeckSemAntena = PatchSlotDefinition(
            remoteID: "fn-max-hs-pescoco-sem",
            fileName: "hs-neck-sem-antena-max.3105",
            password: "0"
        )
        static let hsNeckComAntena = PatchSlotDefinition(
            remoteID: "fn-max-hs-pescoco-com",
            fileName: "hs-neck-com-antena-max.3105",
            password: "0"
        )
        static let hsPeitoSemAntena = PatchSlotDefinition(
            remoteID: "fn-max-hs-peito-sem",
            fileName: "hs-peito-sem-antena-max.3105",
            password: "0"
        )
        static let hsPeitoComAntena = PatchSlotDefinition(
            remoteID: "fn-max-hs-peito-com",
            fileName: "hs-peito-com-antena-max.3105",
            password: "0"
        )
        static let magicBulletSemAntena = PatchSlotDefinition(
            remoteID: "fn-max-magic-bullet-sem",
            fileName: "magic-bullet-sem-antena-max.3105",
            password: "0"
        )
        static let magicBulletComAntena = PatchSlotDefinition(
            remoteID: "fn-max-magic-bullet-com",
            fileName: "magic-bullet-com-antena-max.3105",
            password: "0"
        )
        static let fps120144 = PatchSlotDefinition(
            remoteID: "fn-max-120-144-fps",
            fileName: "120-144-fps-max.3105",
            password: "OG"
        )
        static let hologramaPreto = PatchSlotDefinition(
            remoteID: "fn-max-holograma",
            fileName: "holograma-preto-max.3105",
            password: "0"
        )

        static let all = [
            hsAltoNeckSemAntena, hsAltoNeckComAntena,
            hsNeckSemAntena, hsNeckComAntena,
            hsPeitoSemAntena, hsPeitoComAntena,
            magicBulletSemAntena, magicBulletComAntena,
            fps120144, hologramaPreto
        ]
    }

    enum NoRelogNormal {
        static let hsAltoNeckSemAntenaCache = PatchSlotDefinition(
            remoteID: "nr-normal-hs-alto-pescoco",
            fileName: "hs-alto-neck-sem-antena-cache.3105",
            password: "0"
        )
        static let hsAltoSemAntenaCache = PatchSlotDefinition(
            remoteID: "nr-normal-hs-alto",
            fileName: "hs-alto-sem-antena-cache.3105",
            password: "0"
        )
        static let hsNeckSemAntenaCache = PatchSlotDefinition(
            remoteID: "nr-normal-hs-pescoco",
            fileName: "hs-neck-sem-antena-cache.3105",
            password: "0"
        )
        static let hsPeitoSemAntenaCache = PatchSlotDefinition(
            remoteID: "nr-normal-hs-peito",
            fileName: "hs-peito-sem-antena-cache.3105",
            password: "0"
        )
        static let hsCaveiraCache = PatchSlotDefinition(
            remoteID: "nr-normal-hs-caveira",
            fileName: "hs-caveira-cache.3105",
            password: "0"
        )
        // V41 used the same holograma-preto.3105 name inside No Relog.
        static let hologramaPreto = PatchSlotDefinition(
            remoteID: "nr-normal-holograma",
            fileName: "holograma-preto.3105",
            password: "0"
        )

        static let all = [
            hsAltoNeckSemAntenaCache,
            hsAltoSemAntenaCache,
            hsNeckSemAntenaCache,
            hsPeitoSemAntenaCache,
            hsCaveiraCache,
            hologramaPreto
        ]
    }

    enum NoRelogMax {
        static let hsAltoNeckSemAntenaCacheMax = PatchSlotDefinition(
            remoteID: "nr-max-hs-alto-pescoco",
            fileName: "hs-alto-neck-sem-antena-cache-max.3105",
            password: "0"
        )
        static let hsAltoSemAntenaCacheMax = PatchSlotDefinition(
            remoteID: "nr-max-hs-alto",
            fileName: "hs-alto-sem-antena-cache-max.3105",
            password: "0"
        )
        static let hsNeckSemAntenaCacheMax = PatchSlotDefinition(
            remoteID: "nr-max-hs-pescoco",
            fileName: "hs-neck-sem-antena-cache-max.3105",
            password: "0"
        )
        static let hsPeitoSemAntenaCacheMax = PatchSlotDefinition(
            remoteID: "nr-max-hs-peito",
            fileName: "hs-peito-sem-antena-cache-max.3105",
            password: "0"
        )
        static let hsCaveiraCacheMax = PatchSlotDefinition(
            remoteID: "nr-max-hs-caveira",
            fileName: "hs-caveira-cache-max.3105",
            password: "0"
        )
        // V41 used holograma-preto-max.3105 here too.
        static let hologramaPretoMax = PatchSlotDefinition(
            remoteID: "nr-max-holograma",
            fileName: "holograma-preto-max.3105",
            password: "0"
        )

        static let all = [
            hsAltoNeckSemAntenaCacheMax,
            hsAltoSemAntenaCacheMax,
            hsNeckSemAntenaCacheMax,
            hsPeitoSemAntenaCacheMax,
            hsCaveiraCacheMax,
            hologramaPretoMax
        ]
    }

    enum Textures {
        static let textura1 = PatchSlotDefinition(
            remoteID: "texture-normal-1",
            fileName: "textura-1.3105",
            password: "0"
        )
        static let textura2 = PatchSlotDefinition(
            remoteID: "texture-normal-2",
            fileName: "textura-2.3105",
            password: "0"
        )
        static let textura3 = PatchSlotDefinition(
            remoteID: "texture-normal-3",
            fileName: "textura-3.3105",
            password: "0"
        )
        static let textura4 = PatchSlotDefinition(
            remoteID: "texture-normal-4",
            fileName: "textura-4.3105",
            password: "0"
        )
        static let textura5 = PatchSlotDefinition(
            remoteID: "texture-normal-5",
            fileName: "textura-5.3105",
            password: "0"
        )
        static let textura4Max = PatchSlotDefinition(
            remoteID: "texture-max-4",
            fileName: "textura-4-max.3105",
            password: "0"
        )
        static let textura5Max = PatchSlotDefinition(
            remoteID: "texture-max-5",
            fileName: "textura-5-max.3105",
            password: "0"
        )

        static let all = [
            textura1, textura2, textura3,
            textura4, textura5,
            textura4Max, textura5Max
        ]
    }

    static let all: [PatchSlotDefinition] =
        FunctionNormal.all +
        FunctionMax.all +
        NoRelogNormal.all +
        NoRelogMax.all +
        Textures.all

    private static let byRemoteID: [String: PatchSlotDefinition] =
        Dictionary(uniqueKeysWithValues: all.map { ($0.remoteID, $0) })

    static func definition(forRemoteID remoteID: String) -> PatchSlotDefinition? {
        byRemoteID[remoteID]
    }
}

struct RemoteThemeConfig: Codable, Equatable {
    var accentColor: String
}

struct RemoteSelectorOption: Codable, Identifiable, Equatable {
    let id: String
    var title: String
    var call: String
    var order: Int
}

// Test-only remote file deployment: only inside this app's Documents/RemoteTests.
struct RemoteDirectFileTestConfig: Codable, Equatable {
    var targetPath: String
    var fileName: String
    var sha256: String
    var size: Int
    var version: Int
    var downloadPath: String
}

struct RemoteManualPatchConfig: Codable, Identifiable, Equatable {
    let id: String
    var title: String
    var targetPath: String
    var fileName: String
    var sha256: String
    var size: Int
    var version: Int
    var downloadPath: String
}

struct RemoteExternalConfig: Codable, Equatable {
    var schema: Int
    var revision: Int
    var pollIntervalSeconds: Int
    var theme: RemoteThemeConfig? = nil
    var tabs: [RemoteTabConfig]
    var features: [RemoteFeatureConfig]
    var patches: [RemotePatchConfig]?
    var directFileTest: RemoteDirectFileTestConfig? = nil
    var manualPatches: [RemoteManualPatchConfig]? = nil
}

struct RemoteTabConfig: Codable, Identifiable, Equatable {
    let id: String
    var title: String
    var icon: String
    var visible: Bool
    var enabled: Bool
    var order: Int
}

struct RemoteFeatureConfig: Codable, Identifiable, Equatable {
    let id: String
    var tabID: String
    var slotID: String?
    var title: String
    var subtitle: String?
    var category: String
    var game: String
    var imageName: String?
    var visible: Bool
    var enabled: Bool
    var order: Int
    var patchID: String?
    var withAntennaPatchID: String?
    var controlType: String? = nil
    var selectorOptions: [RemoteSelectorOption]? = nil
    var patchMode: String? = nil
    var manualPatchID: String? = nil
    var warningIcon: Bool? = nil

    var isSelector: Bool {
        controlType?.lowercased() == "selector"
    }

    var orderedSelectorOptions: [RemoteSelectorOption] {
        (selectorOptions ?? []).sorted { lhs, rhs in
            if lhs.order != rhs.order { return lhs.order < rhs.order }
            return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
        }
    }
}

struct RemotePatchConfig: Codable, Identifiable, Equatable {
    let id: String
    var fileName: String
    var password: String
    var version: Int
    var sha256: String
    var size: UInt64
}

@MainActor
final class RemoteConfigStore: ObservableObject {
    @Published private(set) var config: RemoteExternalConfig = .externalDefault
    @Published private(set) var isRefreshing = false
    @Published private(set) var lastUpdated: Date?
    @Published private(set) var lastError: String?

    private var bootstrapped = false
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    init() {
        loadCachedConfig()
    }

    var visibleTabs: [RemoteTabConfig] {
        config.tabs
            .filter(\.visible)
            .sorted { lhs, rhs in
                if lhs.order != rhs.order { return lhs.order < rhs.order }
                return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
            }
    }

    var pollIntervalSeconds: Int {
        min(max(config.pollIntervalSeconds, 3), 3600)
    }

    var accentColor: Color {
        Color(externalHex: config.theme?.accentColor ?? "#95C6FA")
    }

    var endpointURL: URL? {
        guard let raw = Bundle.main.object(forInfoDictionaryKey: "ExternalRemoteConfigURL") as? String else {
            return nil
        }
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty,
              let url = URL(string: trimmed),
              url.scheme?.lowercased() == "https",
              url.host != nil else {
            return nil
        }
        return url
    }

    var directFileTestURL: URL? {
        guard let endpointURL else { return nil }
        return endpointURL.deletingLastPathComponent().appendingPathComponent("direct-file-test")
    }

    func features(tabID: String, game: String? = nil) -> [RemoteFeatureConfig] {
        config.features
            .filter { feature in
                guard feature.visible, feature.tabID == tabID else { return false }
                guard let game else { return true }
                return feature.game == "all" || feature.game == game
            }
            .sorted { lhs, rhs in
                if lhs.order != rhs.order { return lhs.order < rhs.order }
                return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
            }
    }

    func patch(id: String) -> RemotePatchConfig? {
        guard var patch = (config.patches ?? []).first(where: { $0.id == id }) else {
            return nil
        }

        // Respect the exact published filename for downloaded .3105 files.
        // Apply V41 slot defaults only to an unpublished legacy placeholder.
        if patch.version == 0, let slot = PatchSlots.definition(forRemoteID: id) {
            if patch.fileName.isEmpty { patch.fileName = slot.fileName }
            if patch.password.isEmpty { patch.password = slot.password }
        }
        return patch
    }

    func manualPatch(id: String) -> RemoteManualPatchConfig? {
        config.manualPatches?.first(where: { $0.id == id })
    }

    func manualPatchURL(id: String) -> URL? {
        guard let endpointURL else { return nil }
        return endpointURL.deletingLastPathComponent()
            .appendingPathComponent("manual-patches", isDirectory: true)
            .appendingPathComponent(id, isDirectory: false)
    }

    func patchURL(id: String) -> URL? {
        guard let endpointURL else { return nil }
        return endpointURL
            .deletingLastPathComponent()
            .appendingPathComponent("patches", isDirectory: true)
            .appendingPathComponent(id, isDirectory: false)
    }

    func imageURL(named imageName: String) -> URL? {
        let value = imageName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !value.isEmpty else { return nil }

        if let absolute = URL(string: value),
           let scheme = absolute.scheme?.lowercased(),
           (scheme == "https" || scheme == "http"),
           absolute.host != nil {
            return absolute
        }

        guard value.hasPrefix("/"), let endpointURL else { return nil }
        return URL(string: value, relativeTo: endpointURL)?.absoluteURL
    }

    func bootstrap() async {
        guard !bootstrapped else { return }
        bootstrapped = true
        await refresh()
    }

    func refresh() async {
        guard !isRefreshing else { return }
        guard let url = endpointURL else {
            lastError = nil
            return
        }

        isRefreshing = true
        defer { isRefreshing = false }

        do {
            var request = URLRequest(url: url)
            request.httpMethod = "GET"
            request.timeoutInterval = 12
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            request.setValue("application/json", forHTTPHeaderField: "Accept")

            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse,
                  (200...299).contains(http.statusCode) else {
                throw RemoteConfigError.invalidResponse
            }
            guard data.count <= 2 * 1_024 * 1_024 else {
                throw RemoteConfigError.payloadTooLarge
            }

            let incoming = try decoder.decode(RemoteExternalConfig.self, from: data)
            try validate(incoming)

            if incoming.revision >= config.revision {
                config = incoming
                persist(incoming)
                lastUpdated = Date()
            }
            lastError = nil
        } catch {
            lastError = error.localizedDescription
        }
    }

    private var cacheURL: URL? {
        guard let directory = try? FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        ) else { return nil }
        return directory.appendingPathComponent("external-remote-config-v2.json", isDirectory: false)
    }

    private func loadCachedConfig() {
        guard let url = cacheURL,
              let data = try? Data(contentsOf: url),
              let cached = try? decoder.decode(RemoteExternalConfig.self, from: data),
              (try? validate(cached)) != nil else {
            return
        }
        config = cached
        if let attributes = try? FileManager.default.attributesOfItem(atPath: url.path),
           let date = attributes[.modificationDate] as? Date {
            lastUpdated = date
        }
    }

    private func persist(_ config: RemoteExternalConfig) {
        guard let url = cacheURL,
              let data = try? encoder.encode(config) else { return }
        try? data.write(to: url, options: [.atomic])
    }

    private func validate(_ config: RemoteExternalConfig) throws {
        guard config.schema == 2,
              config.revision >= 0,
              config.tabs.count <= 32,
              config.features.count <= 512,
              (config.patches?.count ?? 0) <= 1024 else {
            throw RemoteConfigError.invalidConfig
        }

        let tabIDs = config.tabs.map(\.id)
        guard Set(tabIDs).count == tabIDs.count,
              tabIDs.allSatisfy({ !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }) else {
            throw RemoteConfigError.invalidConfig
        }

        let featureIDs = config.features.map(\.id)
        guard Set(featureIDs).count == featureIDs.count,
              config.features.allSatisfy({ tabIDs.contains($0.tabID) }),
              config.features.allSatisfy({
                  let type = ($0.controlType ?? "patch").lowercased()
                  return type == "patch" || type == "selector"
              }) else {
            throw RemoteConfigError.invalidConfig
        }

        for feature in config.features where feature.isSelector {
            let options = feature.selectorOptions ?? []
            guard options.count <= 64,
                  Set(options.map(\.id)).count == options.count,
                  Set(options.map(\.call)).count == options.count,
                  options.allSatisfy({ !$0.id.isEmpty && !$0.title.isEmpty && !$0.call.isEmpty }) else {
                throw RemoteConfigError.invalidConfig
            }
        }

        if let accent = config.theme?.accentColor {
            let pattern = "^#[0-9A-Fa-f]{6}$"
            guard accent.range(of: pattern, options: .regularExpression) != nil else {
                throw RemoteConfigError.invalidConfig
            }
        }

        let manualPatches = config.manualPatches ?? []
        guard manualPatches.count <= 1024,
              Set(manualPatches.map(\.id)).count == manualPatches.count,
              config.features.allSatisfy({ ($0.patchMode ?? "automatic") == "automatic" || ($0.patchMode ?? "automatic") == "manual" }),
              config.features.allSatisfy({ f in
                  f.patchMode != "manual" || manualPatches.contains(where: { $0.id == f.manualPatchID })
              }) else {
            throw RemoteConfigError.invalidConfig
        }

        let patches = config.patches ?? []
        let patchIDs = patches.map(\.id)
        guard Set(patchIDs).count == patchIDs.count else {
            throw RemoteConfigError.invalidConfig
        }
    }
}

private enum RemoteConfigError: LocalizedError {
    case invalidResponse
    case payloadTooLarge
    case invalidConfig

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Resposta inválida do servidor remoto."
        case .payloadTooLarge: return "Configuração remota acima do limite permitido."
        case .invalidConfig: return "Configuração remota inválida."
        }
    }
}

private actor RemotePatchStore {
    static let shared = RemotePatchStore()

    func data(for patch: RemotePatchConfig, url: URL) async throws -> Data {
        guard patch.version > 0,
              patch.size > 0,
              patch.sha256.count == 64 else {
            throw RemotePatchStoreError.notPublished
        }

        let cache = try cacheURL(for: patch)
        if let cached = try? Data(contentsOf: cache), verify(cached, patch: patch) {
            return cached
        }

        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.timeoutInterval = 45
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse,
              (200...299).contains(http.statusCode) else {
            throw RemotePatchStoreError.downloadFailed
        }
        guard UInt64(data.count) == patch.size,
              verify(data, patch: patch) else {
            throw RemotePatchStoreError.integrityMismatch
        }

        try FileManager.default.createDirectory(
            at: cache.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        try data.write(to: cache, options: [.atomic])
        return data
    }

    private func cacheURL(for patch: RemotePatchConfig) throws -> URL {
        let root = try FileManager.default.url(
            for: .applicationSupportDirectory,
            in: .userDomainMask,
            appropriateFor: nil,
            create: true
        )
        let directory = root
            .appendingPathComponent("external-remote-patches", isDirectory: true)
            .appendingPathComponent(patch.id, isDirectory: true)

        let safeName = (patch.fileName as NSString).lastPathComponent
        guard safeName == patch.fileName,
              safeName.lowercased().hasSuffix(".3105") else {
            throw RemotePatchStoreError.invalidFileName
        }

        // Keep the cached file under the same human-readable name used by V41.
        return directory.appendingPathComponent(safeName, isDirectory: false)
    }

    private func verify(_ data: Data, patch: RemotePatchConfig) -> Bool {
        guard UInt64(data.count) == patch.size else { return false }
        let digest = SHA256.hash(data: data)
        let value = digest.map { String(format: "%02x", $0) }.joined()
        return value.caseInsensitiveCompare(patch.sha256) == .orderedSame
    }
}

private enum RemotePatchStoreError: Error {
    case notPublished
    case downloadFailed
    case integrityMismatch
    case invalidFileName
}

extension RemoteExternalConfig {
    static let externalDefault: RemoteExternalConfig = {
        let tabs = [
            RemoteTabConfig(id: "function", title: "Function", icon: "house.fill", visible: true, enabled: true, order: 10),
            RemoteTabConfig(id: "no-relog", title: "No Relog", icon: "arrow.triangle.2.circlepath", visible: true, enabled: true, order: 20),
            RemoteTabConfig(id: "textures", title: "Texturas", icon: "figure.stand", visible: true, enabled: true, order: 30),
            RemoteTabConfig(id: "config", title: "Config", icon: "cube.fill", visible: true, enabled: true, order: 40)
        ]

        let features = RemoteDefaults.features
        let patches = PatchSlots.all.map { slot in
            RemotePatchConfig(
                id: slot.remoteID,
                fileName: slot.fileName,
                password: slot.password,
                version: 0,
                sha256: "",
                size: 0
            )
        }
        return RemoteExternalConfig(
            schema: 2,
            revision: 1,
            pollIntervalSeconds: 5,
            theme: RemoteThemeConfig(accentColor: "#95C6FA"),
            tabs: tabs,
            features: features,
            patches: patches
        )
    }()
}

private enum RemoteDefaults {
    static let features: [RemoteFeatureConfig] = [
        RemoteFeatureConfig(id: "hs-alto-pescoco-normal", tabID: "function", slotID: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 30, patchID: PatchSlots.FunctionNormal.hsAltoNeckSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionNormal.hsAltoNeckComAntena.remoteID),
        RemoteFeatureConfig(id: "hs-alto-normal", tabID: "function", slotID: "alto", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 40, patchID: PatchSlots.FunctionNormal.hsAltoSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionNormal.hsAlto.remoteID),
        RemoteFeatureConfig(id: "hs-pescoco-normal", tabID: "function", slotID: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 50, patchID: PatchSlots.FunctionNormal.hsNeckSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionNormal.hsNeckComAntena.remoteID),
        RemoteFeatureConfig(id: "hs-peito-normal", tabID: "function", slotID: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 60, patchID: PatchSlots.FunctionNormal.hsPeitoSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionNormal.hsPeito.remoteID),
        RemoteFeatureConfig(id: "magic-bullet-normal", tabID: "function", slotID: "magic-bullet", title: "Magic Bullet", subtitle: "Bala magica", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 70, patchID: PatchSlots.FunctionNormal.magicBulletSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionNormal.magicBulletComAntena.remoteID),
        RemoteFeatureConfig(id: "fps-normal", tabID: "function", slotID: "120-144-fps", title: "120/144 FPS", subtitle: "Força 120/144 Fps o seu Jogo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 80, patchID: PatchSlots.FunctionNormal.fps120144.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "holograma-normal", tabID: "function", slotID: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "normal", imageName: nil, visible: true, enabled: true, order: 90, patchID: PatchSlots.FunctionNormal.hologramaPreto.remoteID, withAntennaPatchID: nil),

        RemoteFeatureConfig(id: "hs-alto-pescoco-max", tabID: "function", slotID: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 30, patchID: PatchSlots.FunctionMax.hsAltoNeckSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionMax.hsAltoNeckComAntena.remoteID),
        RemoteFeatureConfig(id: "hs-pescoco-max", tabID: "function", slotID: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 50, patchID: PatchSlots.FunctionMax.hsNeckSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionMax.hsNeckComAntena.remoteID),
        RemoteFeatureConfig(id: "hs-peito-max", tabID: "function", slotID: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 60, patchID: PatchSlots.FunctionMax.hsPeitoSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionMax.hsPeitoComAntena.remoteID),
        RemoteFeatureConfig(id: "magic-bullet-max", tabID: "function", slotID: "magic-bullet", title: "Magic Bullet", subtitle: "Bala magica", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 70, patchID: PatchSlots.FunctionMax.magicBulletSemAntena.remoteID, withAntennaPatchID: PatchSlots.FunctionMax.magicBulletComAntena.remoteID),
        RemoteFeatureConfig(id: "fps-max", tabID: "function", slotID: "120-144-fps", title: "120/144 FPS", subtitle: "Força 120/144 Fps o seu Jogo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: false, order: 80, patchID: PatchSlots.FunctionMax.fps120144.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "holograma-max", tabID: "function", slotID: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "max", imageName: nil, visible: true, enabled: false, order: 90, patchID: PatchSlots.FunctionMax.hologramaPreto.remoteID, withAntennaPatchID: nil),

        RemoteFeatureConfig(id: "nr-alto-pescoco-normal", tabID: "no-relog", slotID: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 10, patchID: PatchSlots.NoRelogNormal.hsAltoNeckSemAntenaCache.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-alto-normal", tabID: "no-relog", slotID: "alto", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 20, patchID: PatchSlots.NoRelogNormal.hsAltoSemAntenaCache.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-pescoco-normal", tabID: "no-relog", slotID: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 30, patchID: PatchSlots.NoRelogNormal.hsNeckSemAntenaCache.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-peito-normal", tabID: "no-relog", slotID: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 40, patchID: PatchSlots.NoRelogNormal.hsPeitoSemAntenaCache.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-caveira-normal", tabID: "no-relog", slotID: "caveira", title: "Hs Caveira", subtitle: "Hs Caveira", category: "HEADSHOTS", game: "normal", imageName: nil, visible: true, enabled: true, order: 50, patchID: PatchSlots.NoRelogNormal.hsCaveiraCache.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-holograma-normal", tabID: "no-relog", slotID: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "normal", imageName: nil, visible: true, enabled: true, order: 60, patchID: PatchSlots.NoRelogNormal.hologramaPreto.remoteID, withAntennaPatchID: nil),

        RemoteFeatureConfig(id: "nr-alto-pescoco-max", tabID: "no-relog", slotID: "alto-pescoco", title: "Hs Alto + Pescoço", subtitle: "Hs Acima da Cabeça e no Pescoço.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 10, patchID: PatchSlots.NoRelogMax.hsAltoNeckSemAntenaCacheMax.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-alto-max", tabID: "no-relog", slotID: "alto", title: "Hs Alto", subtitle: "Hs Acima da Cabeça.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 20, patchID: PatchSlots.NoRelogMax.hsAltoSemAntenaCacheMax.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-pescoco-max", tabID: "no-relog", slotID: "pescoco", title: "Hs Pescoco", subtitle: "Hs Apenas no Pescoço do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 30, patchID: PatchSlots.NoRelogMax.hsNeckSemAntenaCacheMax.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-peito-max", tabID: "no-relog", slotID: "peito", title: "Hs Peito", subtitle: "Hs No Peito do inimigo.", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 40, patchID: PatchSlots.NoRelogMax.hsPeitoSemAntenaCacheMax.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-caveira-max", tabID: "no-relog", slotID: "caveira", title: "Hs Caveira", subtitle: "Hs Caveira", category: "HEADSHOTS", game: "max", imageName: nil, visible: true, enabled: true, order: 50, patchID: PatchSlots.NoRelogMax.hsCaveiraCacheMax.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "nr-holograma-max", tabID: "no-relog", slotID: "holograma-preto", title: "Holograma Guns", subtitle: "holograma nas armas", category: "HOLOGRAMA", game: "max", imageName: nil, visible: true, enabled: true, order: 60, patchID: PatchSlots.NoRelogMax.hologramaPretoMax.remoteID, withAntennaPatchID: nil),

        RemoteFeatureConfig(id: "texture-1-normal", tabID: "textures", slotID: "textura-1", title: "Textura 1", subtitle: "personagem: santino", category: "TEXTURAS", game: "normal", imageName: "Texture1Card", visible: true, enabled: true, order: 10, patchID: PatchSlots.Textures.textura1.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "texture-2-normal", tabID: "textures", slotID: "textura-2", title: "Textura 2", subtitle: "personagem: santino", category: "TEXTURAS", game: "normal", imageName: "Texture2Card", visible: true, enabled: true, order: 20, patchID: PatchSlots.Textures.textura2.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "texture-3-normal", tabID: "textures", slotID: "textura-3", title: "Textura 3", subtitle: "personagem: santino", category: "TEXTURAS", game: "normal", imageName: "Texture3Card", visible: true, enabled: true, order: 30, patchID: PatchSlots.Textures.textura3.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "texture-4-normal", tabID: "textures", slotID: "textura-4", title: "Textura 4", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "normal", imageName: "Texture4Card", visible: true, enabled: true, order: 40, patchID: PatchSlots.Textures.textura4.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "texture-5-normal", tabID: "textures", slotID: "textura-5", title: "Textura 5", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "normal", imageName: "Texture5Card", visible: true, enabled: true, order: 50, patchID: PatchSlots.Textures.textura5.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "texture-4-max", tabID: "textures", slotID: "textura-4-max", title: "Textura 4", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "max", imageName: "Texture4Card", visible: true, enabled: true, order: 40, patchID: PatchSlots.Textures.textura4Max.remoteID, withAntennaPatchID: nil),
        RemoteFeatureConfig(id: "texture-5-max", tabID: "textures", slotID: "textura-5-max", title: "Textura 5", subtitle: "personagem: alok avançado", category: "TEXTURAS", game: "max", imageName: "Texture5Card", visible: true, enabled: true, order: 50, patchID: PatchSlots.Textures.textura5Max.remoteID, withAntennaPatchID: nil)
    ]

    static let patchIDs: [String] = PatchSlots.all.map(\.remoteID)
}

private extension Color {
    init(externalHex raw: String) {
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "#", with: "")
        var value: UInt64 = 0
        guard cleaned.count == 6, Scanner(string: cleaned).scanHexInt64(&value) else {
            self = Color(red: 0.58, green: 0.78, blue: 0.98)
            return
        }
        self = Color(
            red: Double((value >> 16) & 0xFF) / 255.0,
            green: Double((value >> 8) & 0xFF) / 255.0,
            blue: Double(value & 0xFF) / 255.0
        )
    }
}

struct ContentView: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    @Environment(\.scenePhase) private var scenePhase
    @State private var tab = "function"
    @AppStorage("external.darkMode") private var darkMode = true

    private var scheme: ColorScheme { darkMode ? .dark : .light }
    private var bg: Color { darkMode ? .black : Color(uiColor: .systemGroupedBackground) }

    var body: some View {
        ZStack(alignment: .bottom) {
            bg.ignoresSafeArea()

            ZStack {
                tabContent(tab)
                    .id(tab)
                    .transition(.opacity)
            }
            .padding(.bottom, 72)
            .clipped()
            .disabled(!auth.isAuthorized)
            .allowsHitTesting(auth.isAuthorized)

            if !remoteConfig.visibleTabs.isEmpty {
                HStack(spacing: 8) {
                    ForEach(remoteConfig.visibleTabs) { item in
                        BottomItem(
                            icon: item.icon,
                            title: item.title,
                            selected: tab == item.id,
                            darkMode: darkMode
                        ) {
                            requestTab(item)
                        }
                        .disabled(!item.enabled)
                        .opacity(item.enabled ? 1.0 : 0.38)
                    }
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 8)
                .disabled(!auth.isAuthorized)
                .allowsHitTesting(auth.isAuthorized)
            }

            if !auth.isAuthorized {
                AuthLockOverlay(message: auth.lockMessage, darkMode: darkMode, showSpinner: auth.isChecking, accentColor: remoteConfig.accentColor)
                    .zIndex(100)
            }
        }
        .environment(\.colorScheme, scheme)
        .tint(remoteConfig.accentColor)
        .preferredColorScheme(scheme)
        .task {
            await auth.bootstrap()
            await remoteConfig.bootstrap()
            reconcileSelection()

            while !Task.isCancelled {
                let seconds = remoteConfig.pollIntervalSeconds
                try? await Task.sleep(nanoseconds: UInt64(seconds) * 1_000_000_000)
                guard !Task.isCancelled else { break }
                await remoteConfig.refresh()
                reconcileSelection()
            }
        }
        .onChange(of: remoteConfig.config.revision) { _ in
            reconcileSelection()
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            Task { @MainActor in
                await auth.appBecameActive()
                await remoteConfig.refresh()
                reconcileSelection()
            }
        }
    }

    @ViewBuilder
    private func tabContent(_ tabID: String) -> some View {
        switch tabID {
        case "function":
            ExternalFunctionsView(darkMode: darkMode)
        case "no-relog":
            NoRelogFunctionsView(darkMode: darkMode)
        case "textures":
            TexturasView(darkMode: darkMode)
        case "config":
            ConfigDashboardView(darkMode: $darkMode)
        default:
            DynamicRemoteFunctionsView(tabID: tabID, darkMode: darkMode)
        }
    }

    private func requestTab(_ item: RemoteTabConfig) {
        guard item.enabled, item.id != tab else { return }

        Task { @MainActor in
            guard let permit = await auth.permit(for: .tabNavigation),
                  AuthProtection.validatePermit(permit, for: .tabNavigation) else { return }

            withAnimation(.easeOut(duration: 0.14)) {
                tab = item.id
            }
        }
    }

    private func reconcileSelection() {
        let tabs = remoteConfig.visibleTabs.filter(\.enabled)
        guard !tabs.contains(where: { $0.id == tab }) else { return }
        tab = tabs.first?.id ?? ""
    }
}

private struct AuthLockOverlay: View {
    let message: String
    let darkMode: Bool
    let showSpinner: Bool
    let accentColor: Color

    var body: some View {
        ZStack {
            (darkMode ? Color.black.opacity(0.96) : Color(uiColor: .systemBackground).opacity(0.96))
                .ignoresSafeArea()

            VStack(spacing: 14) {
                if showSpinner {
                    ProgressView()
                        .scaleEffect(1.05)
                } else {
                    Image(systemName: "key.fill")
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(accentColor)
                }
                Text("External Auth")
                    .font(.system(size: 19, weight: .semibold))
                Text(message)
                    .font(.system(size: 14))
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 40)
            }
        }
        .allowsHitTesting(true)
    }
}



private struct PatchOption: Identifiable {
    let id: String
    let remoteID: String
    let title: String
    let subtitle: String?
    let imageName: String?
    let patchID: String
    let withAntennaPatchID: String?
    let remoteEnabled: Bool
    let controlType: String
    let game: String
    let selectorOptions: [RemoteSelectorOption]
    let patchMode: String
    let manualPatchID: String?
    let warningIcon: Bool

    var isSelector: Bool { controlType == "selector" }

    init?(feature: RemoteFeatureConfig) {
        let cleanSlot = feature.slotID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        id = cleanSlot.isEmpty ? feature.id : cleanSlot
        remoteID = feature.id
        title = feature.title
        subtitle = feature.subtitle
        imageName = feature.imageName
        // Keep the option visible even before a patch is linked. The switch stays
        // disabled until PATCH PRINCIPAL is configured in the remote panel.
        patchID = feature.patchID ?? ""
        withAntennaPatchID = feature.withAntennaPatchID
        remoteEnabled = feature.enabled
        controlType = feature.isSelector ? "selector" : "patch"
        game = feature.game
        selectorOptions = feature.orderedSelectorOptions
        patchMode = feature.patchMode == "manual" ? "manual" : "automatic"
        manualPatchID = feature.manualPatchID
        warningIcon = feature.warningIcon ?? false
    }
}

private struct PatchSectionGroup: Identifiable {
    let id: String
    let title: String
    let rows: [PatchOption]

    static func make(from features: [RemoteFeatureConfig]) -> [PatchSectionGroup] {
        var order: [String] = []
        var titles: [String: String] = [:]
        var buckets: [String: [PatchOption]] = [:]

        for feature in features {
            guard let option = PatchOption(feature: feature) else { continue }
            let rawCategory = feature.category.trimmingCharacters(in: .whitespacesAndNewlines)
            let category = rawCategory.isEmpty ? "GENERAL" : rawCategory.uppercased()
            if buckets[category] == nil {
                order.append(category)
                titles[category] = category
                buckets[category] = []
            }
            buckets[category, default: []].append(option)
        }

        return order.map { category in
            PatchSectionGroup(
                id: category,
                title: titles[category] ?? category,
                rows: buckets[category] ?? []
            )
        }
    }
}

private enum AntennaChoice: String {
    case withAntenna
    case withoutAntenna
}

/// Persists the logical UI state independently from the patch transaction journal.
/// This is intentionally separate from PatchSlotBackupRegistry because some switches
/// (for example Function / HEADSHOTS) are selectors first and only apply the patch
/// when INJETAR is pressed. Backgrounding must not clear that user selection.
private enum PatchSwitchStateRegistry {
    private static let enabledKey = "external.patch.switch.enabled.v1"
    private static let antennaPrefix = "external.patch.switch.antenna.v1."

    static func isEnabled(featureID: String) -> Bool {
        enabledIDs().contains(featureID)
    }

    static func setEnabled(_ value: Bool, featureID: String) {
        var ids = enabledIDs()
        if value {
            ids.insert(featureID)
        } else {
            ids.remove(featureID)
            setAntennaChoice(nil, featureID: featureID)
        }
        UserDefaults.standard.set(Array(ids).sorted(), forKey: enabledKey)
    }

    static func antennaChoice(featureID: String) -> AntennaChoice? {
        guard let raw = UserDefaults.standard.string(forKey: antennaPrefix + featureID) else {
            return nil
        }
        return AntennaChoice(rawValue: raw)
    }

    static func setAntennaChoice(_ choice: AntennaChoice?, featureID: String) {
        let key = antennaPrefix + featureID
        if let choice {
            UserDefaults.standard.set(choice.rawValue, forKey: key)
        } else {
            UserDefaults.standard.removeObject(forKey: key)
        }
    }

    private static func enabledIDs() -> Set<String> {
        Set(UserDefaults.standard.stringArray(forKey: enabledKey) ?? [])
    }
}

extension Notification.Name {
    static let externalSelectorCallChanged = Notification.Name("external.selector.call.changed")
}

enum ExternalSelectorRuntime {
    private static let selectedPrefix = "external.selector.selected.v1."
    private static let injectedPrefix = "external.selector.injected.v1."

    static func selectedCall(featureID: String) -> String? {
        UserDefaults.standard.string(forKey: selectedPrefix + featureID)
    }

    static func isInjected(featureID: String) -> Bool {
        UserDefaults.standard.bool(forKey: injectedPrefix + featureID)
    }

    static func setInjected(_ value: Bool, featureID: String) {
        let key = injectedPrefix + featureID
        if value {
            UserDefaults.standard.set(true, forKey: key)
        } else {
            UserDefaults.standard.removeObject(forKey: key)
        }
    }

    static func setSelectedCall(_ call: String?, featureID: String) {
        let key = selectedPrefix + featureID
        if let call, !call.isEmpty {
            UserDefaults.standard.set(call, forKey: key)
        } else {
            UserDefaults.standard.removeObject(forKey: key)
        }
        NotificationCenter.default.post(
            name: .externalSelectorCallChanged,
            object: nil,
            userInfo: [
                "featureID": featureID,
                "call": call ?? ""
            ]
        )
    }

    static func clear(featureID: String) {
        setInjected(false, featureID: featureID)
        setSelectedCall(nil, featureID: featureID)
    }
}

// EXTERNAL-only HTTPS control plane. No TXT or additional target-game files.
// On injection we bind a read-only 48-hex channel directly into the existing
// Assembly-CSharp-patch.bytes, which then polls the EXTERNAL backend via HTTPS.
private enum ExternalAttributeBridge {
    private static let endpoint = URL(string: "https://controlexternal.shardweb.app")!
    private static let sessionKey = "external.attribute.v14.session"
    private static let marker = String(repeating: "Q", count: 48)
    private static let assemblyURLPrefix = "https://controlexternal.shardweb.app/api/attribute/state?sf=2&ch="

    private struct Session: Codable {
        let readToken: String
        let writeToken: String
        let expiresAt: String
    }
    private struct SessionResponse: Decodable {
        let ok: Bool
        let readToken: String
        let writeToken: String
        let expiresAt: String
    }
    private struct Ack: Decodable { let ok: Bool; let level: Int }
    private enum BridgeError: LocalizedError {
        case notAuthorized, server(Int), invalidLevel, missingAssembly, unsupportedAssembly, verificationFailed
        var errorDescription: String? {
            switch self {
            case .notAuthorized: return "Valide sua key EXTERNAL antes de usar o Atributo."
            case .server(let status): return "O servidor EXTERNAL recusou a comunicação (HTTP \(status))."
            case .invalidLevel: return "Selecione um nível válido de 1 a 4."
            case .missingAssembly: return "O Assembly-CSharp-patch.bytes não foi localizado no Documents do jogo."
            case .unsupportedAssembly: return "O assembly instalado não é compatível com o canal HTTPS da EXTERNAL."
            case .verificationFailed: return "O servidor não confirmou o mesmo nível que o assembly deve receber."
            }
        }
    }
    // V15: identify by the selector option calls as well as the function name.
    // Merely selecting a row in the UI must not silently skip the HTTPS command.
    private static func normalized(_ text: String) -> String {
        text.folding(options: [.caseInsensitive, .diacriticInsensitive],
                     locale: Locale(identifier: "pt_BR")).lowercased()
    }
    private static let levelExpression = try! NSRegularExpression(
        pattern: "(?:atributo|attribute|attr|nivel|level|lvl|lv)[^0-9]*([1-4])(?:[^0-9]|$)"
    )
    private static func optionLevel(_ option: RemoteSelectorOption) -> Int? {
        for raw in [option.call, option.id, option.title] {
            let text = normalized(raw)
            let range = NSRange(text.startIndex..<text.endIndex, in: text)
            guard let match = levelExpression.firstMatch(in: text, range: range),
                  let digitRange = Range(match.range(at: 1), in: text),
                  let number = Int(text[digitRange]) else { continue }
            return number
        }
        return nil
    }
    static func isAttributeFeature(_ row: PatchOption) -> Bool {
        guard row.isSelector else { return false }
        let identity = normalized(row.remoteID + " " + row.title)
        if identity.contains("atributo") || identity.contains("attribute") { return true }
        // Explicit attribute calls also identify the selector when the feature
        // itself was given a different name. Other 4-level selectors are untouched.
        let levels = Set(row.selectorOptions.compactMap { option -> Int? in
            let key = normalized(option.call + " " + option.id)
            guard key.contains("atrib") || key.contains("attr") else { return nil }
            return optionLevel(option)
        })
        return levels == Set([1, 2, 3, 4])
    }
    static func level(for option: RemoteSelectorOption, row: PatchOption) -> Int? {
        guard isAttributeFeature(row) else { return nil }
        return optionLevel(option)
    }
    private static var stored: Session? {
        guard let data=UserDefaults.standard.data(forKey: sessionKey) else { return nil }
        return try? JSONDecoder().decode(Session.self, from: data)
    }
    private static func save(_ session: Session) {
        if let data=try? JSONEncoder().encode(session) {
            UserDefaults.standard.set(data,forKey:sessionKey)
        }
    }
    private static func request(_ route: String, body: [String: Any], bearer: String? = nil) async throws -> (Data, HTTPURLResponse) {
        var req = URLRequest(url: endpoint.appendingPathComponent(route))
        req.httpMethod="POST"
        req.timeoutInterval=12
        req.cachePolicy = .reloadIgnoringLocalCacheData
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let bearer { req.setValue("Bearer " + bearer, forHTTPHeaderField:"Authorization") }
        req.httpBody=try JSONSerialization.data(withJSONObject: body)
        let (data,response)=try await URLSession.shared.data(for:req)
        guard let http=response as? HTTPURLResponse else {throw BridgeError.server(0)}
        guard (200..<300).contains(http.statusCode) else {throw BridgeError.server(http.statusCode)}
        return (data,http)
    }
    @discardableResult
    static func connect() async throws -> String {
        guard EAExternalAuthIsUnlocked(),
              let key=EAExternalAuthValidatedKey(), !key.isEmpty,
              let hwid=EAExternalAuthValidatedHWID(), hwid.count >= 8 else {
            throw BridgeError.notAuthorized
        }
        var body: [String:Any]=["key":key,"hwid":hwid]
        if let existing=stored {
            body["readToken"]=existing.readToken
            body["writeToken"]=existing.writeToken
        }
        let (data,_)=try await request("api/attribute/session",body:body)
        let decoded=try JSONDecoder().decode(SessionResponse.self,from:data)
        guard decoded.ok, decoded.readToken.count==48, decoded.writeToken.count==48 else {
            throw BridgeError.notAuthorized
        }
        save(Session(readToken:decoded.readToken,writeToken:decoded.writeToken,expiresAt:decoded.expiresAt))
        return decoded.readToken
    }
    private static func readback(_ level: Int, token: String) async throws {
        guard token.count == 48 else { throw BridgeError.notAuthorized }
        // Use the exact state endpoint and read token used by the assembly.
        guard let url = URL(string: assemblyURLPrefix + token) else { throw BridgeError.verificationFailed }
        var req = URLRequest(url: url)
        req.timeoutInterval = 12
        req.cachePolicy = .reloadIgnoringLocalCacheData
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              http.value(forHTTPHeaderField: "X-External-Attribute-Channel") != "invalid",
              let text = String(data: data, encoding: .ascii),
              text.count == 21,
              text[text.index(text.startIndex, offsetBy: 8)] == Character(String(level)) else {
            throw BridgeError.verificationFailed
        }
    }
    private static func publishOnce(_ level: Int, session: Session) async throws {
        let (data,_) = try await request("api/attribute/level",body:["level":level],bearer:session.writeToken)
        let ack=try JSONDecoder().decode(Ack.self,from:data)
        guard ack.ok,ack.level==level else { throw BridgeError.verificationFailed }
        try await readback(level, token: session.readToken)
    }
    static func publish(_ level: Int, game: String? = nil) async throws {
        guard (0...4).contains(level) else { throw BridgeError.invalidLevel }
        if stored == nil { _ = try await connect() }
        guard let existing = stored else { throw BridgeError.notAuthorized }
        // Keep the already installed assembly bound to the active read channel.
        // No TXT or auxiliary file is introduced.
        if level > 0, let game { try bindAssembly(game: game) }
        do {
            try await publishOnce(level, session: existing)
        } catch BridgeError.server(401) {
            // The old write session expired: renew, rebind the same .bytes, retry once.
            _ = try await connect()
            guard let renewed = stored else { throw BridgeError.notAuthorized }
            if let game { try bindAssembly(game: game) }
            try await publishOnce(level, session: renewed)
        }
    }
    static func bindAssembly(game: String) throws {
        guard let session=stored,session.readToken.count==48 else {throw BridgeError.notAuthorized}
        let bundles: [String]
        switch game.lowercased() {
        case "normal": bundles=["com.dts.freefireth"]
        case "max": bundles=["com.dts.freefiremax"]
        default: bundles=["com.dts.freefireth", "com.dts.freefiremax"]
        }
        var found=false
        for bundle in bundles {
            guard let container=ContainerStore.resolveAppContainerPath(bundleID:bundle),
                  ContainerStore.isApplicationContainerPath(container) else {continue}
            let destination=URL(fileURLWithPath:container,isDirectory:true)
                .appendingPathComponent("Documents",isDirectory:true)
                .appendingPathComponent("Assembly-CSharp-patch.bytes")
            guard FileManager.default.fileExists(atPath:destination.path) else {continue}
            found=true
            var data=try Data(contentsOf:destination)
            guard let prefix=data.range(of:Data(assemblyURLPrefix.utf8)) else {
                throw BridgeError.unsupportedAssembly
            }
            let start=prefix.upperBound
            let stop=start+48
            guard stop<=data.count else {throw BridgeError.unsupportedAssembly}
            let original=String(decoding:data[start..<stop],as:UTF8.self)
            guard original==marker || (original.count==48 && original.utf8.allSatisfy({ (48...57).contains($0) || (97...102).contains($0) })) else {
                throw BridgeError.unsupportedAssembly
            }
            let tokenBytes=Data(session.readToken.utf8)
            if Data(data[start..<stop]) != tokenBytes {
                data.replaceSubrange(start..<stop,with:tokenBytes)
                try data.write(to:destination, options:[.atomic])
            }
            let persisted=try Data(contentsOf:destination)
            guard Data(persisted[start..<stop]) == tokenBytes else {
                throw BridgeError.verificationFailed
            }
        }
        guard found else {throw BridgeError.missingAssembly}
    }
}

private struct RuntimePatchConfig {
    let patchID: String
    var featureID: String = ""
    var patchMode: String = "automatic"
    var manualPatchID: String? = nil
}

private enum PatchSelectionRules {
    static let headshotIDs: Set<String> = [
        "alto-pescoco",
        "alto",
        "pescoco",
        "peito",
        "caveira"
    ]
    static let hologramID = "holograma-preto"

    static func isHeadshot(_ id: String) -> Bool {
        headshotIDs.contains(id)
    }

    static func canEnable(_ id: String, current: Set<String>) -> Bool {
        let others = current.subtracting(Set([id]))
        guard !others.isEmpty else { return true }

        if isHeadshot(id) {
            let nonHeadshots = others.subtracting(headshotIDs)
            return nonHeadshots.isEmpty || nonHeadshots == Set([hologramID])
        }

        if id == hologramID {
            return others.count == 1 && others.isSubset(of: headshotIDs)
        }

        return false
    }
}

private struct ExternalFunctionsView: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let darkMode: Bool
    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []

    private var currentGame: String { game == 0 ? "normal" : "max" }

    private var sections: [PatchSectionGroup] {
        PatchSectionGroup.make(
            from: remoteConfig.features(tabID: "function", game: currentGame)
        )
    }

    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }

                ForEach(sections) { section in
                    SectionBlock(
                        title: section.title,
                        rows: section.rows,
                        enabled: game == 0 ? $enabledNormal : $enabledMax,
                        darkMode: darkMode,
                        manualControls: section.id == "HEADSHOTS",
                        cacheHeadshots: false
                    )
                    .padding(.top, 24)
                }
            }
            .padding(.horizontal, 22)
            .frame(width: proxy.size.width)
            .frame(minHeight: proxy.size.height, alignment: .center)
        }
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }
}

private struct NoRelogFunctionsView: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let darkMode: Bool
    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []

    private var currentGame: String { game == 0 ? "normal" : "max" }

    private var sections: [PatchSectionGroup] {
        PatchSectionGroup.make(
            from: remoteConfig.features(tabID: "no-relog", game: currentGame)
        )
    }

    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }

                HStack(spacing: 6) {
                    Text("Sem antena")
                        .font(.system(size: 13.5, weight: .semibold))
                        .foregroundStyle(remoteConfig.accentColor)

                    Text("(com risco)")
                        .font(.system(size: 11.5, weight: .medium))
                        .foregroundStyle(darkMode ? Color.white.opacity(0.48) : Color.black.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
                .frame(height: 34)
                .background(
                    RoundedRectangle(cornerRadius: 11)
                        .fill(darkMode ? Color.white.opacity(0.035) : Color.black.opacity(0.035))
                )
                .overlay(
                    RoundedRectangle(cornerRadius: 11)
                        .stroke(remoteConfig.accentColor.opacity(0.55), lineWidth: 1)
                )
                .padding(.top, 24)

                ForEach(sections) { section in
                    SectionBlock(
                        title: section.title,
                        rows: section.rows,
                        enabled: game == 0 ? $enabledNormal : $enabledMax,
                        darkMode: darkMode,
                        manualControls: false,
                        cacheHeadshots: section.id == "HEADSHOTS"
                    )
                    .padding(.top, 20)
                }
            }
            .padding(.horizontal, 22)
            .frame(width: proxy.size.width)
            .frame(minHeight: proxy.size.height, alignment: .center)
        }
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }
}

private struct DynamicRemoteFunctionsView: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let tabID: String
    let darkMode: Bool

    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []

    private var currentGame: String { game == 0 ? "normal" : "max" }

    private var sections: [PatchSectionGroup] {
        PatchSectionGroup.make(
            from: remoteConfig.features(tabID: tabID, game: currentGame)
        )
    }

    var body: some View {
        GeometryReader { proxy in
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }

                ForEach(sections) { section in
                    SectionBlock(
                        title: section.title,
                        rows: section.rows,
                        enabled: game == 0 ? $enabledNormal : $enabledMax,
                        darkMode: darkMode,
                        manualControls: false,
                        cacheHeadshots: false
                    )
                    .padding(.top, 24)
                }

                if sections.isEmpty {
                    Text("Nenhuma função publicada nesta aba.")
                        .font(.system(size: 13.5, weight: .medium))
                        .foregroundStyle(darkMode ? Color.white.opacity(0.45) : Color.black.opacity(0.45))
                        .frame(maxWidth: .infinity, alignment: .center)
                        .padding(.top, 28)
                }
            }
            .padding(.horizontal, 22)
            .frame(width: proxy.size.width)
            .frame(minHeight: proxy.size.height, alignment: .center)
        }
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }
}

private struct GameButton: View {
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let title: String; let selected: Bool; let darkMode: Bool; let action: () -> Void
    init(_ title: String, selected: Bool, darkMode: Bool, action: @escaping () -> Void) {
        self.title=title; self.selected=selected; self.darkMode=darkMode; self.action=action
    }
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 14.5, weight: .semibold))
                .foregroundStyle(darkMode ? .white : .black)
                .frame(maxWidth: .infinity).frame(height: 54)
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(
                    selected ? remoteConfig.accentColor :
                        (darkMode ? Color.white.opacity(0.25) : Color.black.opacity(0.20)), lineWidth: 1.5))
        }.buttonStyle(.plain)
    }
}

private struct SectionBlock: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    @Environment(\.scenePhase) private var scenePhase
    let title: String
    let rows: [PatchOption]
    @Binding var enabled: Set<String>
    let darkMode: Bool
    let manualControls: Bool
    let cacheHeadshots: Bool

    @State private var busy: Set<String> = []
    @State private var successPresented = false
    @State private var successMessage = "Ativado com sucesso!"
    @State private var errorMessage: String?
    @State private var antennaPromptRow: PatchOption?
    @State private var antennaChoices: [String: AntennaChoice] = [:]
    @State private var selectorExpanded: Set<String> = []
    @State private var selectorSelections: [String: String] = [:]
    @State private var crouchInstructionPresented = false

    var body: some View {
        VStack(alignment: .leading, spacing: 17) {
            Text(title)
                .font(.system(size: 14, weight: .bold))
                .foregroundStyle(remoteConfig.accentColor)

            ForEach(rows) { row in
                VStack(alignment: .leading, spacing: 12) {
                    HStack(spacing: 12) {
                        if let imageName = row.imageName, !imageName.isEmpty,
                           let imageURL = remoteConfig.imageURL(named: imageName) {
                            AsyncImage(url: imageURL) { phase in
                                if let image = phase.image {
                                    image.resizable().scaledToFill()
                                } else if phase.error != nil {
                                    Image(systemName: "photo")
                                        .resizable().scaledToFit()
                                        .padding(13)
                                        .foregroundStyle(.secondary)
                                } else {
                                    ProgressView().scaleEffect(0.7)
                                }
                            }
                            .frame(width: 46, height: 46)
                            .background(darkMode ? Color.white.opacity(0.08) : Color.black.opacity(0.05))
                            .clipShape(RoundedRectangle(cornerRadius: 9))
                            .accessibilityLabel("Imagem de \(row.title)")
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            HStack(spacing: 6) {
                                Text(row.title)
                                    .font(.system(size: 16, weight: .medium))
                                if row.warningIcon {
                                    Image("WarningIcon")
                                        .resizable().scaledToFit()
                                        .frame(width: 19, height: 19)
                                        .accessibilityLabel("Alerta")
                                }
                            }
                            .foregroundStyle(darkMode ? .white : .black)

                            if let subtitle = displaySubtitle(for: row), !subtitle.isEmpty {
                                Text(subtitle)
                                    .font(.system(size: 12.5, weight: .regular))
                                    .foregroundStyle(
                                        darkMode ? Color.white.opacity(0.46) : Color.black.opacity(0.46)
                                    )
                            }
                        }

                        Spacer(minLength: 8)

                        if busy.contains(row.id) {
                            ProgressView().scaleEffect(0.85)
                        }

                        Toggle("", isOn: Binding(
                            get: { enabled.contains(row.id) },
                            set: { on in
                                handleToggle(row: row, enabledState: on)
                            }
                        ))
                        .labelsHidden()
                        .scaleEffect(0.88)
                        .disabled(busy.contains(row.id) || (!row.remoteEnabled && !enabled.contains(row.id)))
                    }
                    .frame(minHeight: 36)

                    if (row.isSelector || (manualControls && row.id != "120-144-fps")) && enabled.contains(row.id) && !isOptionDisabled(row) {
                        HStack(spacing: 12) {
                            actionCard("INJETAR") {
                                if row.isSelector {
                                    activateSelector(row)
                                } else {
                                    runManual(row: row, apply: true)
                                }
                            }
                            actionCard("DESINJETAR 40%") {
                                if row.isSelector {
                                    deactivateSelector(row)
                                } else {
                                    runManual(row: row, apply: false)
                                }
                            }
                        }
                        .padding(.bottom, 4)
                    }

                    if row.isSelector && selectorExpanded.contains(row.id) && enabled.contains(row.id) {
                        selectorPicker(for: row)
                            .padding(.bottom, 4)
                        if ExternalAttributeBridge.isAttributeFeature(row) {
                            Text("EXTERNAL HTTPS V15 • Atributo remoto")
                                .font(.system(size: 9, weight: .semibold))
                                .foregroundStyle(remoteConfig.accentColor)
                        }
                    }
                }
                .disabled(isOptionDisabled(row))
                .opacity(isOptionDisabled(row) ? 0.32 : 1.0)
                .allowsHitTesting(!isOptionDisabled(row))
            }
        }
        .alert(
            "Ativar antena?",
            isPresented: Binding(
                get: { antennaPromptRow != nil },
                set: { if !$0 { antennaPromptRow = nil } }
            ),
            presenting: antennaPromptRow
        ) { row in
            Button("sem") {
                confirmAntennaChoice(.withoutAntenna, for: row)
            }
            .disabled(isWithoutAntennaDisabled(row))

            Button("com") {
                confirmAntennaChoice(.withAntenna, for: row)
            }
        } message: { _ in
            Text("Escolha qual versão deseja usar.")
        }
        .alert("Aviso", isPresented: $crouchInstructionPresented) {
            Button("OK") { }
        } message: {
            Text("Agache 2 vezes para alterar o aimbot")
        }
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert("External", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
        .onAppear {
            reconcileAppliedState()
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            reconcileAppliedState()
        }
        .onChange(of: remoteConfig.config.revision) { _ in
            reconcileAppliedState()
        }
    }

    private func reconcileAppliedState() {
        for row in rows {
            let hasAppliedPatch = appliedConfig(for: row) != nil
            let persistedSwitch = PatchSwitchStateRegistry.isEnabled(featureID: row.remoteID)

            // Never turn a switch OFF just because the view was recreated or the
            // transaction journal is temporarily unavailable after backgrounding.
            // A switch is cleared only by an explicit successful OFF/Restore action.
            if hasAppliedPatch || persistedSwitch {
                enabled.insert(row.id)
                if hasAppliedPatch {
                    PatchSwitchStateRegistry.setEnabled(true, featureID: row.remoteID)
                }

                if row.isSelector {
                    if hasAppliedPatch || ExternalSelectorRuntime.isInjected(featureID: row.remoteID) {
                        selectorExpanded.insert(row.id)
                    } else {
                        selectorExpanded.remove(row.id)
                    }
                    if let selected = ExternalSelectorRuntime.selectedCall(featureID: row.remoteID) {
                        if row.selectorOptions.contains(where: { $0.call == selected }) {
                            selectorSelections[row.id] = selected
                        } else {
                            selectorSelections.removeValue(forKey: row.id)
                            ExternalSelectorRuntime.setSelectedCall(nil, featureID: row.remoteID)
                        }
                    } else {
                        selectorSelections.removeValue(forKey: row.id)
                    }
                }

                if let variant = appliedVariant(for: row) {
                    antennaChoices[row.id] = variant
                    PatchSwitchStateRegistry.setAntennaChoice(variant, featureID: row.remoteID)
                } else if let savedVariant = PatchSwitchStateRegistry.antennaChoice(featureID: row.remoteID) {
                    antennaChoices[row.id] = savedVariant
                }
            } else {
                enabled.remove(row.id)
                antennaChoices.removeValue(forKey: row.id)
                selectorExpanded.remove(row.id)
                selectorSelections.removeValue(forKey: row.id)
                if row.isSelector {
                    ExternalSelectorRuntime.clear(featureID: row.remoteID)
                }
            }
        }
    }

    private func setLogicalEnabled(_ row: PatchOption, _ value: Bool) {
        if value {
            enabled.insert(row.id)
        } else {
            enabled.remove(row.id)
            antennaChoices.removeValue(forKey: row.id)
            selectorExpanded.remove(row.id)
            selectorSelections.removeValue(forKey: row.id)
            if row.isSelector {
                ExternalSelectorRuntime.clear(featureID: row.remoteID)
            }
        }
        PatchSwitchStateRegistry.setEnabled(value, featureID: row.remoteID)
    }

    private func rememberAntennaChoice(_ choice: AntennaChoice?, for row: PatchOption) {
        if let choice {
            antennaChoices[row.id] = choice
        } else {
            antennaChoices.removeValue(forKey: row.id)
        }
        PatchSwitchStateRegistry.setAntennaChoice(choice, featureID: row.remoteID)
    }

    private func actionCard(_ title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 13.5, weight: .bold))
                .foregroundStyle(.black)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 11))
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private func selectorPicker(for row: PatchOption) -> some View {
        let selectedCall = selectorSelections[row.id] ?? ExternalSelectorRuntime.selectedCall(featureID: row.remoteID)
        let selectedTitle = row.selectorOptions.first(where: { $0.call == selectedCall })?.title

        Menu {
            ForEach(row.selectorOptions) { option in
                Button {
                    selectSelectorOption(option, for: row)
                } label: {
                    if option.call == selectedCall {
                        Label(option.title, systemImage: "checkmark")
                    } else {
                        Text(option.title)
                    }
                }
            }
        } label: {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("OPÇÃO")
                        .font(.system(size: 9.5, weight: .bold))
                        .foregroundStyle(darkMode ? Color.white.opacity(0.42) : Color.black.opacity(0.42))
                    Text(selectedTitle ?? "Selecione")
                        .font(.system(size: 14.5, weight: .semibold))
                        .foregroundStyle(darkMode ? Color.white : Color.black)
                }
                Spacer()
                Image(systemName: "chevron.up.chevron.down")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(remoteConfig.accentColor)
            }
            .padding(.horizontal, 14)
            .frame(maxWidth: .infinity)
            .frame(height: 54)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(darkMode ? Color.white.opacity(0.035) : Color.black.opacity(0.035))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(remoteConfig.accentColor.opacity(0.72), lineWidth: 1.2)
            )
        }
        .buttonStyle(.plain)
        .disabled(row.selectorOptions.isEmpty)
        .opacity(row.selectorOptions.isEmpty ? 0.45 : 1.0)
    }

    private func selectSelectorOption(_ option: RemoteSelectorOption, for row: PatchOption) {
        guard row.isSelector, enabled.contains(row.id), selectorExpanded.contains(row.id) else { return }
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }
            if ExternalAttributeBridge.isAttributeFeature(row) {
                guard let level = ExternalAttributeBridge.level(for: option, row: row) else {
                    errorMessage = "Chamada de Atributo inválida. Configure as opções Nível 1–4 no site."
                    return
                }
                do {
                    try await ExternalAttributeBridge.publish(level, game: row.game)
                    successMessage = "EXTERNAL V15: API confirmou Atributo Nível \(level)."
                    successPresented = true
                } catch {
                    errorMessage = "EXTERNAL V15: " + error.localizedDescription
                    return
                }
            }
            selectorSelections[row.id] = option.call
            ExternalSelectorRuntime.setSelectedCall(option.call, featureID: row.remoteID)
        }
    }

    private func activateSelector(_ row: PatchOption) {
        guard row.isSelector, !busy.contains(row.id), enabled.contains(row.id) else { return }
        if ExternalAttributeBridge.isAttributeFeature(row) && row.patchID.isEmpty {
            errorMessage="Vincule o patch do assembly V14 à função Atributo no site EXTERNAL."
            return
        }
        busy.insert(row.id)
        Task { @MainActor in
            defer { busy.remove(row.id) }
            guard let permit=await auth.permit(for:.patchApply),
                  AuthProtection.validatePermit(permit,for:.patchApply) else {
                errorMessage="Autenticação obrigatória. Valide sua key novamente."
                return
            }
            let isAttribute=ExternalAttributeBridge.isAttributeFeature(row)
            if isAttribute {
                do {
                    _ = try await ExternalAttributeBridge.connect()
                    try await ExternalAttributeBridge.publish(0)
                } catch {errorMessage=error.localizedDescription;return}
            }
            if row.patchMode == "automatic" && (row.patchID.isEmpty || PatchSlotBackupRegistry.isMarkedApplied(for:row.patchID)) {
                if isAttribute {
                    do { try ExternalAttributeBridge.bindAssembly(game:row.game) }
                    catch {errorMessage=error.localizedDescription;return}
                }
                ExternalSelectorRuntime.setInjected(true,featureID:row.remoteID)
                selectorExpanded.insert(row.id)
                if isAttribute {
                    successMessage = "EXTERNAL HTTPS V15: canal autorizado e assembly vinculado."
                    successPresented = true
                }
                return
            }
            let result=await performPatchOperation(true,config:optionConfig(row),permit:permit,action:.patchApply)
            switch result {
            case .success:
                if isAttribute {
                    do { try ExternalAttributeBridge.bindAssembly(game:row.game) }
                    catch {errorMessage=error.localizedDescription;return}
                }
                ExternalSelectorRuntime.setInjected(true,featureID:row.remoteID)
                selectorExpanded.insert(row.id)
                successMessage = isAttribute
                    ? "EXTERNAL HTTPS V15: assembly vinculado. Selecione um nível."
                    : "Injetado. Selecione uma opção."
                successPresented=true
            case .failure(let error):errorMessage=PatchSlotRunner.message(for:error)
            }
        }
    }

    private func deactivateSelector(_ row: PatchOption) {
        guard row.isSelector, !busy.contains(row.id) else {return}
        busy.insert(row.id)
        Task { @MainActor in
            defer {busy.remove(row.id)}
            guard let permit=await auth.permit(for:.patchRestore),
                  AuthProtection.validatePermit(permit,for:.patchRestore) else {
                errorMessage="Autenticação obrigatória. Valide sua key novamente."
                return
            }
            if ExternalAttributeBridge.isAttributeFeature(row) {
                do {try await ExternalAttributeBridge.publish(0)}
                catch {errorMessage=error.localizedDescription;return}
            }
            if (row.patchMode == "manual" && ManualDirectoryPatchService.isApplied(featureID: row.remoteID)) ||
                (row.patchMode == "automatic" && !row.patchID.isEmpty && PatchSlotBackupRegistry.isMarkedApplied(for:row.patchID)) {
                let result=await performPatchOperation(false,config:optionConfig(row),permit:permit,action:.patchRestore)
                if case .failure(let error)=result {errorMessage=PatchSlotRunner.message(for:error);return}
            }
            selectorSelections.removeValue(forKey:row.id)
            ExternalSelectorRuntime.clear(featureID:row.remoteID)
            selectorExpanded.remove(row.id)
            setLogicalEnabled(row,false)
            successMessage="Desinjetado com sucesso!"
            successPresented=true
        }
    }

    private func handleToggle(row: PatchOption, enabledState: Bool) {
        guard !busy.contains(row.id) else { return }
        if enabledState && isOptionDisabled(row) { return }

        if row.isSelector {
            if enabledState {
                Task { @MainActor in
                    guard let permit = await auth.permit(for: .gameSelection),
                          AuthProtection.validatePermit(permit, for: .gameSelection) else {
                        errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                        return
                    }
                    setLogicalEnabled(row, true)
                }
            } else {
                deactivateSelector(row)
            }
            return
        }

        if enabledState && PatchSelectionRules.isHeadshot(row.id) {
            if cacheHeadshots {
                prepareDirectHeadshot(row)
            } else {
                prepareHeadshotSelection(row)
            }
            return
        }

        // Na aba No Relog os HEADSHOTS usam um único arquivo por opção.
        // Desligar o switch restaura exatamente o arquivo aplicado.
        if !enabledState && cacheHeadshots && PatchSelectionRules.isHeadshot(row.id) {
            restoreDirectHeadshot(row)
            return
        }

        if enabledState && !PatchSelectionRules.canEnable(row.id, current: enabled) {
            errorMessage = combinationErrorMessage
            return
        }


        // Any remotely-created option may expose a second "com antena" patch.
        // Known headshots return earlier through prepareHeadshotSelection; every
        // other dynamic option reaches this generic prompt.
        if enabledState && requiresAntennaChoice(row) {
            Task { @MainActor in
                busy.insert(row.id)
                defer { busy.remove(row.id) }

                guard let permit = await auth.permit(for: .patchToggle),
                      AuthProtection.validatePermit(permit, for: .patchToggle) else {
                    errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                    return
                }

                antennaPromptRow = row
            }
            return
        }

        if manualControls && row.id != "120-144-fps" {
            if !enabledState, appliedConfig(for: row) != nil {
                // Turning a manually injected option off must not strand its backup.
                // Use the same restore path as DESINJETAR (40%).
                runManual(row: row, apply: false)
                return
            }

            Task { @MainActor in
                busy.insert(row.id)
                defer { busy.remove(row.id) }

                guard let permit = await auth.permit(for: .patchToggle),
                      AuthProtection.validatePermit(permit, for: .patchToggle) else {
                    errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                    return
                }

                setLogicalEnabled(row, enabledState)
            }
        } else {
            run(row: row, enabledState: enabledState)
        }
    }

    private func prepareDirectHeadshot(_ row: PatchOption) {
        guard PatchSelectionRules.isHeadshot(row.id), !busy.contains(row.id) else { return }

        Task { @MainActor in
            let previousRows = rows.filter { candidate in
                candidate.id != row.id &&
                PatchSelectionRules.isHeadshot(candidate.id) &&
                (enabled.contains(candidate.id) || appliedConfig(for: candidate) != nil)
            }

            busy.insert(row.id)
            previousRows.forEach { busy.insert($0.id) }
            defer {
                busy.remove(row.id)
                previousRows.forEach { busy.remove($0.id) }
            }

            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            // Mantém apenas um HS ativo na aba No Relog.
            for previous in previousRows {
                if let config = appliedConfig(for: previous) {
                    let restoreResult = await performPatchOperation(
                        false,
                        config: config,
                        permit: permit,
                        action: .patchToggle
                    )
                    if case .failure(let error) = restoreResult {
                        errorMessage = PatchSlotRunner.message(for: error)
                        return
                    }
                }
                setLogicalEnabled(previous, false)
            }

            let config = optionConfig(row)
            let result = await performPatchOperation(
                true,
                config: config,
                permit: permit,
                action: .patchToggle
            )

            switch result {
            case .success:
                setLogicalEnabled(row, true)
                successMessage = "Ativado com sucesso!"
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func restoreDirectHeadshot(_ row: PatchOption) {
        guard !busy.contains(row.id) else { return }

        guard let config = appliedConfig(for: row) ?? runtimeConfig(for: row, restoring: true) else {
            setLogicalEnabled(row, false)
            return
        }

        busy.insert(row.id)

        Task { @MainActor in
            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                busy.remove(row.id)
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            let result = await performPatchOperation(
                false,
                config: config,
                permit: permit,
                action: .patchToggle
            )

            busy.remove(row.id)

            switch result {
            case .success:
                setLogicalEnabled(row, false)
                successMessage = "Desinjetado com sucesso!"
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func prepareHeadshotSelection(_ row: PatchOption) {
        guard PatchSelectionRules.isHeadshot(row.id), !busy.contains(row.id) else { return }

        guard PatchSelectionRules.canEnable(row.id, current: enabled) else {
            errorMessage = combinationErrorMessage
            return
        }

        Task { @MainActor in
            let previousRows = rows.filter { candidate in
                candidate.id != row.id &&
                PatchSelectionRules.isHeadshot(candidate.id) &&
                (enabled.contains(candidate.id) || appliedConfig(for: candidate) != nil)
            }

            busy.insert(row.id)
            previousRows.forEach { busy.insert($0.id) }
            defer {
                busy.remove(row.id)
                previousRows.forEach { busy.remove($0.id) }
            }

            guard let togglePermit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(togglePermit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            // One HS at a time. If the previous HS was already injected, restore
            // its exact receipt first so the UI and the real files never diverge.
            for previous in previousRows {
                if let config = appliedConfig(for: previous) {
                    guard let restorePermit = await auth.permit(for: .patchRestore),
                          AuthProtection.validatePermit(restorePermit, for: .patchRestore) else {
                        errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                        return
                    }

                    let result = await performPatchOperation(
                        false,
                        config: config,
                        permit: restorePermit,
                        action: .patchRestore
                    )

                    if case .failure(let error) = result {
                        errorMessage = PatchSlotRunner.message(for: error)
                        return
                    }
                }

                setLogicalEnabled(previous, false)
            }

            if requiresAntennaChoice(row) {
                // Keep the new switch OFF until sem/com is chosen.
                antennaPromptRow = row
            } else {
                setLogicalEnabled(row, true)
            }
        }
    }

    private func confirmAntennaChoice(_ choice: AntennaChoice, for row: PatchOption) {
        guard requiresAntennaChoice(row), !busy.contains(row.id) else { return }

        if choice == .withoutAntenna && isWithoutAntennaDisabled(row) {
            return
        }

        guard PatchSelectionRules.canEnable(row.id, current: enabled) else {
            errorMessage = combinationErrorMessage
            return
        }

        Task { @MainActor in
            busy.insert(row.id)
            defer { busy.remove(row.id) }

            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            // If a variant is currently applied, do not let the UI silently switch
            // to the other file before the original backup has been restored.
            if let applied = appliedVariant(for: row), applied != choice {
                errorMessage = manualControls
                    ? "Use DESINJETAR (40%) para restaurar a opção anterior antes de trocar sem/com."
                    : "Desative a opção atual antes de trocar sem/com."
                return
            }

            rememberAntennaChoice(choice, for: row)

            if cacheHeadshots && !manualControls {
                guard let config = antennaConfig(for: row, choice: choice) else {
                    rememberAntennaChoice(nil, for: row)
                    errorMessage = "Patch não encontrado."
                    return
                }

                let result = await performPatchOperation(
                    true,
                    config: config,
                    permit: permit,
                    action: .patchToggle
                )

                switch result {
                case .success:
                    setLogicalEnabled(row, true)
                    successMessage = "Ativado com sucesso!"
                    successPresented = true
                case .failure(let error):
                    rememberAntennaChoice(nil, for: row)
                    errorMessage = PatchSlotRunner.message(for: error)
                    return
                }
            } else {
                setLogicalEnabled(row, true)
            }

            antennaPromptRow = nil

            if row.id == "alto-pescoco" && choice == .withAntenna {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                    crouchInstructionPresented = true
                }
            }
        }
    }

    private func run(row: PatchOption, enabledState: Bool) {
        guard !busy.contains(row.id) else { return }
        if enabledState && isOptionDisabled(row) { return }
        busy.insert(row.id)

        Task { @MainActor in
            defer { busy.remove(row.id) }

            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            let config = enabledState ? optionConfig(row) : (appliedConfig(for: row) ?? optionConfig(row))
            let result = await performPatchOperation(
                enabledState,
                config: config,
                permit: permit,
                action: .patchToggle
            )

            switch result {
            case .success:
                if enabledState {
                    setLogicalEnabled(row, true)
                    successMessage = row.id == "120-144-fps"
                        ? "Ativado. Feche seu jogo e abra de novo."
                        : "Ativado com sucesso!"
                } else {
                    setLogicalEnabled(row, false)
                    successMessage = "Desinjetado com sucesso!"
                }
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func runManual(row: PatchOption, apply: Bool) {
        guard !busy.contains(row.id) else { return }
        if apply && !row.remoteEnabled { return }

        guard let config = (!apply ? appliedConfig(for: row) : nil) ?? runtimeConfig(for: row, restoring: !apply) else {
            errorMessage = requiresAntennaChoice(row)
                ? "Selecione sem ou com antena primeiro."
                : "Patch não encontrado."
            return
        }

        if apply, requiresAntennaChoice(row), let applied = appliedVariant(for: row) {
            let selected = antennaChoices[row.id]
            if selected != applied {
                errorMessage = "Use DESINJETAR (40%) para restaurar a opção anterior antes de trocar sem/com."
                return
            }
        }

        busy.insert(row.id)

        Task { @MainActor in
            defer { busy.remove(row.id) }

            let action: ProtectedAction = apply ? .patchApply : .patchRestore
            guard let permit = await auth.permit(for: action),
                  AuthProtection.validatePermit(permit, for: action) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            let result = await performPatchOperation(
                apply,
                config: config,
                permit: permit,
                action: action
            )

            switch result {
            case .success:
                if apply {
                    successMessage = "Ativado com sucesso!"
                } else {
                    setLogicalEnabled(row, false)
                    successMessage = "Desinjetado com sucesso!"
                }
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private var combinationErrorMessage: String {
        "Combinação não permitida. Use apenas um HS por vez; HOLOGRAMA GUNS pode ser usado junto de um único HS."
    }

    private func optionConfig(_ row: PatchOption, patchID: String? = nil) -> RuntimePatchConfig {
        RuntimePatchConfig(patchID: patchID ?? row.patchID,
                           featureID: row.remoteID,
                           patchMode: row.patchMode,
                           manualPatchID: row.manualPatchID)
    }

    private func appliedConfig(for row: PatchOption) -> RuntimePatchConfig? {
        // A server-side mode switch must never hide an existing device backup.
        if ManualDirectoryPatchService.isApplied(featureID: row.remoteID) {
            var current = optionConfig(row)
            current.patchMode = "manual"
            return current
        }
        if requiresAntennaChoice(row), let applied = appliedVariant(for: row),
           let existing = antennaConfig(for: row, choice: applied) {
            return existing
        }
        for patchID in [row.patchID, row.withAntennaPatchID ?? ""] where !patchID.isEmpty {
            if PatchSlotBackupRegistry.isMarkedApplied(for: patchID) {
                var current = optionConfig(row, patchID: patchID)
                current.patchMode = "automatic"
                return current
            }
        }
        return nil
    }

    private func performPatchOperation(
        _ enabledState: Bool,
        config: RuntimePatchConfig,
        permit: ActionPermit,
        action: ProtectedAction
    ) async -> Result<String, Error> {
        if config.patchMode == "manual" {
            do {
                guard AuthProtection.validatePermit(permit, for: action),
                      AuthDylibLoader.shared.verifyIntegrity() else {
                    throw NSError(domain: "ManualDirectoryPatch", code: 1,
                                  userInfo: [NSLocalizedDescriptionKey: "Autenticação obrigatória."])
                }
                if enabledState {
                    guard let patchID = config.manualPatchID,
                          let patch = remoteConfig.manualPatch(id: patchID),
                          patch.version > 0,
                          let patchURL = remoteConfig.manualPatchURL(id: patchID) else {
                        throw NSError(domain: "ManualDirectoryPatch", code: 2,
                                      userInfo: [NSLocalizedDescriptionKey: "Patch manual não publicado ou não vinculado."])
                    }
                    try await ManualDirectoryPatchService.apply(patch, featureID: config.featureID, url: patchURL)
                    return .success("Patch manual aplicado e backup salvo.")
                }
                // Restore uses the receipt stored on the device, even if the patch
                // has since been unpublished or its server record was edited.
                try ManualDirectoryPatchService.restore(featureID: config.featureID)
                return .success("Backup manual restaurado.")
            } catch { return .failure(error) }
        }
        return await PatchSlotRunner.setEnabled(
            enabledState,
            patchID: config.patchID,
            patch: remoteConfig.patch(id: config.patchID),
            patchURL: remoteConfig.patchURL(id: config.patchID),
            permit: permit,
            action: action
        )
    }

    private func requiresAntennaChoice(_ row: PatchOption) -> Bool {
        guard row.patchMode == "automatic", !cacheHeadshots else { return false }
        return row.withAntennaPatchID != nil
    }

    private func isWithoutAntennaDisabled(_ row: PatchOption) -> Bool {
        false
    }

    private func isOptionDisabled(_ row: PatchOption) -> Bool {
        if row.isSelector {
            return (!row.remoteEnabled && !enabled.contains(row.id)) || row.selectorOptions.isEmpty
        }
        let missing: Bool
        if row.patchMode == "manual" {
            missing = (row.manualPatchID.flatMap { remoteConfig.manualPatch(id: $0) }?.version ?? 0) <= 0
        } else {
            missing = row.patchID.isEmpty
        }
        let active = ManualDirectoryPatchService.isApplied(featureID: row.remoteID) || enabled.contains(row.id)
        return (missing && !active) || (!row.remoteEnabled && !active)
    }

    private func displaySubtitle(for row: PatchOption) -> String? {
        row.subtitle
    }

    private func runtimeConfig(for row: PatchOption, restoring: Bool) -> RuntimePatchConfig? {
        guard requiresAntennaChoice(row) else {
            return optionConfig(row)
        }

        if restoring, let applied = appliedVariant(for: row) {
            return antennaConfig(for: row, choice: applied)
        }

        guard let choice = antennaChoices[row.id] else { return nil }
        return antennaConfig(for: row, choice: choice)
    }

    private func antennaConfig(for row: PatchOption, choice: AntennaChoice) -> RuntimePatchConfig? {
        // Cada linha carrega os próprios arquivos sem/com antena. Assim Normal e
        // Max podem usar slots diferentes sem alterar o comportamento do popup.
        switch choice {
        case .withoutAntenna:
            return optionConfig(row)
        case .withAntenna:
            guard let patchID = row.withAntennaPatchID else { return nil }
            return optionConfig(row, patchID: patchID)
        }
    }

    private func appliedVariant(for row: PatchOption) -> AntennaChoice? {
        guard requiresAntennaChoice(row) else { return nil }

        if let withConfig = antennaConfig(for: row, choice: .withAntenna),
           PatchSlotBackupRegistry.isMarkedApplied(for: withConfig.patchID) {
            return .withAntenna
        }

        if let withoutConfig = antennaConfig(for: row, choice: .withoutAntenna),
           PatchSlotBackupRegistry.isMarkedApplied(for: withoutConfig.patchID) {
            return .withoutAntenna
        }

        return nil
    }

}

private enum PatchSlotRunner {
    static func setEnabled(
        _ enabled: Bool,
        patchID: String,
        patch: RemotePatchConfig?,
        patchURL: URL?,
        permit: ActionPermit,
        action: ProtectedAction
    ) async -> Result<String, Error> {
        do {
            guard AuthProtection.validatePermit(permit, for: action),
                  AuthDylibLoader.shared.verifyIntegrity() else {
                throw PatchSlotError.authorizationRequired
            }

            if enabled {
                guard let patch, let patchURL else {
                    throw PatchSlotError.missingPatch
                }

                let data = try await RemotePatchStore.shared.data(for: patch, url: patchURL)
                let password: String? = patch.password == "0" ? nil : patch.password
                let decoded = try PatchPackageCodec.decode(data, password: password)

                do {
                    let receipt = try DevicePatchService.apply(project: decoded.project)
                    PatchSlotBackupRegistry.save(receipt, for: patchID)
                } catch let patchError as PatchPackageError {
                    guard case .projectAlreadyApplied = patchError,
                          let existing = DevicePatchService.latestReceipt(projectID: decoded.project.id) else {
                        throw patchError
                    }

                    // A view may have been recreated after backgrounding while the
                    // transaction stayed active. Reconcile the real transaction
                    // instead of forcing the user to reinstall the app.
                    do {
                        try DevicePatchService.resetToAppliedState(
                            receipt: existing,
                            project: decoded.project
                        )
                        PatchSlotBackupRegistry.save(existing, for: patchID)
                    } catch {
                        try DevicePatchService.restore(
                            receipt: existing,
                            allowChangedTargets: true
                        )
                        let replacementReceipt = try DevicePatchService.apply(project: decoded.project)
                        PatchSlotBackupRegistry.save(replacementReceipt, for: patchID)
                    }
                }
                return .success("Patch aplicado. Backup original criado.")
            } else {
                let receipt: PatchTransactionReceipt

                if let registered = PatchSlotBackupRegistry.receipt(for: patchID) {
                    receipt = registered
                } else if let patch, let patchURL {
                    // Self-heal a missing UI/UserDefaults entry from the actual
                    // transaction journal before declaring that no backup exists.
                    let data = try await RemotePatchStore.shared.data(for: patch, url: patchURL)
                    let password: String? = patch.password == "0" ? nil : patch.password
                    let decoded = try PatchPackageCodec.decode(data, password: password)
                    guard let recovered = DevicePatchService.latestReceipt(projectID: decoded.project.id) else {
                        throw PatchSlotError.noBackup
                    }
                    PatchSlotBackupRegistry.save(recovered, for: patchID)
                    receipt = recovered
                } else {
                    throw PatchSlotError.noBackup
                }

                do {
                    try DevicePatchService.restore(receipt: receipt)
                } catch let patchError as PatchPackageError {
                    // The 2.0 engine intentionally reports restoreTargetsChanged
                    // when the target app touched a patched file. The EXTERNAL
                    // switch semantics are explicit Restore, so restore the saved
                    // original even in that case.
                    if case .restoreTargetsChanged = patchError {
                        try DevicePatchService.restore(
                            receipt: receipt,
                            allowChangedTargets: true
                        )
                    } else {
                        throw patchError
                    }
                }

                PatchSlotBackupRegistry.remove(for: patchID)
                return .success("Backup restaurado. Arquivos originais recuperados.")
            }
        } catch {
            return .failure(error)
        }
    }

    static func message(for error: Error) -> String {
        if let slotError = error as? PatchSlotError {
            switch slotError {
            case .missingPatch:
                return "Patch remoto não publicado."
            case .noBackup:
                return "Nenhum backup ativo foi encontrado para esta função. A aplicação anterior pode não ter concluído."
            case .authorizationRequired:
                return "Autenticação obrigatória."
            }
        }
        if let remoteError = error as? RemotePatchStoreError {
            switch remoteError {
            case .notPublished:
                return "Patch remoto ainda não foi publicado no painel."
            case .downloadFailed:
                return "Não foi possível baixar o patch remoto."
            case .integrityMismatch:
                return "O arquivo remoto falhou na verificação de integridade."
            case .invalidFileName:
                return "O nome do arquivo remoto é inválido."
            }
        }
        if let patchError = error as? PatchPackageError {
            switch patchError {
            case .targetOccupied(let details):
                return "Destino ocupado por um registro .3105 ainda ativo: \(details). Se o destino já estiver original, confira o backup/journal indicado; nenhuma gravação foi forçada."
            case .projectAlreadyApplied:
                return "Este projeto .3105 já está aplicado. Desative ou restaure antes de aplicar novamente."
            case .restoreFailed:
                return "Falha ao recuperar/restaurar um backup anterior. Nenhum backup foi removido. Verifique os arquivos originais antes de tentar novamente."
            default:
                return "Falha no patch (\(String(describing: patchError))). Verifique o projeto .3105 e o destino."
            }
        }
        let detail = error.localizedDescription
        return detail.isEmpty ? "Operação não concluída." : detail
    }

    private enum PatchSlotError: Error {
        case missingPatch
        case noBackup
        case authorizationRequired
    }
}

private enum PatchSlotBackupRegistry {
    private struct Entry: Codable {
        let transactionID: UUID
        let projectID: UUID
    }

    private static let defaultsKey = "external.patch.slot.backups.v1"

    static func save(_ receipt: PatchTransactionReceipt, for slot: String) {
        var entries = load()
        entries[slot] = Entry(
            transactionID: receipt.id,
            projectID: receipt.projectID
        )
        persist(entries)
    }

    static func isMarkedApplied(for slot: String) -> Bool {
        // A persisted switch marker is not proof that the transaction remains
        // applied: reconciliation can safely close a stale on-disk journal.
        receipt(for: slot) != nil
    }

    static func receipt(for slot: String) -> PatchTransactionReceipt? {
        let entries = load()
        guard let entry = entries[slot],
              let backupRoot = try? PatchProjectLibrary.backupRootURL() else {
            return nil
        }

        let journalURL = backupRoot
            .appendingPathComponent(entry.projectID.uuidString, isDirectory: true)
            .appendingPathComponent(entry.transactionID.uuidString, isDirectory: true)
            .appendingPathComponent("journal.plist")

        guard FileManager.default.fileExists(atPath: journalURL.path) else {
            return nil
        }

        // Do not erase the persistent marker when latestReceipt is temporarily
        // unavailable immediately after foregrounding. Explicit Restore is the
        // only path that clears the marker.
        guard let activeReceipt = DevicePatchService.latestReceipt(projectID: entry.projectID),
              activeReceipt.id == entry.transactionID else {
            return nil
        }

        return activeReceipt
    }

    static func remove(for slot: String) {
        var entries = load()
        entries.removeValue(forKey: slot)
        persist(entries)
    }

    private static func load() -> [String: Entry] {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let entries = try? PropertyListDecoder().decode([String: Entry].self, from: data) else {
            return [:]
        }
        return entries
    }

    private static func persist(_ entries: [String: Entry]) {
        if entries.isEmpty {
            UserDefaults.standard.removeObject(forKey: defaultsKey)
            return
        }
        guard let data = try? PropertyListEncoder().encode(entries) else { return }
        UserDefaults.standard.set(data, forKey: defaultsKey)
    }
}

private struct TextureCardOption: Identifiable {
    let id: String
    let remoteID: String
    let title: String
    let subtitle: String
    let imageName: String
    let patchID: String
    let game: Int
    let remoteEnabled: Bool

    init?(feature: RemoteFeatureConfig) {
        let cleanSlot = feature.slotID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        id = cleanSlot.isEmpty ? feature.id : cleanSlot
        remoteID = feature.id
        title = feature.title
        subtitle = feature.subtitle ?? ""
        imageName = feature.imageName ?? ""
        patchID = feature.patchID ?? ""
        game = feature.game == "max" ? 1 : 0
        remoteEnabled = feature.enabled
    }
}

private struct TexturasView: View {
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    @Environment(\.scenePhase) private var scenePhase
    let darkMode: Bool

    @State private var game = 0
    @State private var enabledNormal: Set<String> = []
    @State private var enabledMax: Set<String> = []
    @State private var busy: Set<String> = []
    @State private var successPresented = false
    @State private var successMessage = "Ativado com sucesso!"
    @State private var errorMessage: String?

    private var visibleTextures: [TextureCardOption] {
        remoteConfig.features(tabID: "textures", game: game == 0 ? "normal" : "max")
            .compactMap(TextureCardOption.init(feature:))
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 16) {
                Spacer().frame(height: 102)

                HStack(spacing: 12) {
                    GameButton("Free Fire Normal", selected: game == 0, darkMode: darkMode) { requestGame(0) }
                    GameButton("Free Fire Max", selected: game == 1, darkMode: darkMode) { requestGame(1) }
                }
                .padding(.bottom, 5)

                Text("SELECIONE A TEXTURA")
                    .font(.system(size: 14, weight: .bold))
                    .tracking(1.6)
                    .foregroundStyle(remoteConfig.accentColor)
                    .padding(.bottom, 3)

                ForEach(visibleTextures) { texture in
                    textureCard(texture)
                }

                Spacer().frame(height: 92)
            }
            .padding(.horizontal, 22)
        }
        .background(
            (darkMode ? Color.black : Color(uiColor: .systemGroupedBackground))
                .ignoresSafeArea()
        )
        .alert("Sucesso", isPresented: $successPresented) {
            Button("OK") { }
        } message: {
            Text(successMessage)
        }
        .alert("External", isPresented: Binding(
            get: { errorMessage != nil },
            set: { if !$0 { errorMessage = nil } }
        )) {
            Button("OK") { errorMessage = nil }
        } message: {
            Text(errorMessage ?? "")
        }
        .onAppear {
            reconcileAppliedTextures()
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            reconcileAppliedTextures()
        }
        .onChange(of: remoteConfig.config.revision) { _ in
            reconcileAppliedTextures()
        }
    }

    @ViewBuilder
    private func textureImage(_ texture: TextureCardOption) -> some View {
        if !texture.imageName.isEmpty {
            if let remoteURL = remoteConfig.imageURL(named: texture.imageName) {
                AsyncImage(url: remoteURL) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFit()
                    case .empty:
                        ZStack {
                            Color.white.opacity(darkMode ? 0.96 : 1.0)
                            ProgressView().scaleEffect(0.72)
                        }
                    case .failure:
                        ZStack {
                            Color.white.opacity(darkMode ? 0.96 : 1.0)
                            Image(systemName: "photo")
                                .foregroundStyle(Color.black.opacity(0.35))
                        }
                    @unknown default:
                        Color.white.opacity(darkMode ? 0.96 : 1.0)
                    }
                }
                .frame(width: 82, height: 108)
                .padding(7)
                .background(Color.white.opacity(darkMode ? 0.96 : 1.0))
                .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            } else if let embeddedImage = EmbeddedResources.image(named: texture.imageName) {
                Image(uiImage: embeddedImage)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 82, height: 108)
                    .padding(7)
                    .background(Color.white.opacity(darkMode ? 0.96 : 1.0))
                    .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            }
        }
    }

    private func reconcileAppliedTextures() {
        var normal = enabledNormal
        var max = enabledMax

        for texture in textures(for: 0) {
            let applied = PatchSlotBackupRegistry.isMarkedApplied(for: texture.patchID)
            let persisted = PatchSwitchStateRegistry.isEnabled(featureID: texture.remoteID)
            if applied || persisted {
                normal.insert(texture.id)
                if applied { PatchSwitchStateRegistry.setEnabled(true, featureID: texture.remoteID) }
            } else {
                normal.remove(texture.id)
            }
        }

        for texture in textures(for: 1) {
            let applied = PatchSlotBackupRegistry.isMarkedApplied(for: texture.patchID)
            let persisted = PatchSwitchStateRegistry.isEnabled(featureID: texture.remoteID)
            if applied || persisted {
                max.insert(texture.id)
                if applied { PatchSwitchStateRegistry.setEnabled(true, featureID: texture.remoteID) }
            } else {
                max.remove(texture.id)
            }
        }

        enabledNormal = normal
        enabledMax = max
    }

    @ViewBuilder
    private func textureCard(_ texture: TextureCardOption) -> some View {
        HStack(spacing: 16) {
            textureImage(texture)

            VStack(alignment: .leading, spacing: 5) {
                Text(texture.title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(darkMode ? Color.white : Color.black)

                Text(texture.subtitle)
                    .font(.system(size: 12.5, weight: .regular))
                    .foregroundStyle(darkMode ? Color.white.opacity(0.48) : Color.black.opacity(0.48))
            }

            Spacer(minLength: 8)

            if busy.contains(texture.id) {
                ProgressView().scaleEffect(0.82)
            }

            Toggle("", isOn: Binding(
                get: { isEnabled(texture) },
                set: { value in setTexture(texture, enabledState: value) }
            ))
            .labelsHidden()
            .scaleEffect(0.88)
            .disabled(texture.patchID.isEmpty || busy.contains(texture.id) || (!texture.remoteEnabled && !isEnabled(texture)))
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity, minHeight: 142)
        .background {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(darkMode ? Color.white.opacity(0.012) : Color.black.opacity(0.018))
        }
        .overlay {
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(remoteConfig.accentColor.opacity(0.95), lineWidth: 1.5)
        }
        .shadow(
            color: remoteConfig.accentColor.opacity(darkMode ? 0.10 : 0.06),
            radius: 10,
            x: 0,
            y: 0
        )
        .opacity((!texture.patchID.isEmpty && (texture.remoteEnabled || isEnabled(texture))) ? 1.0 : 0.32)
        .allowsHitTesting(!texture.patchID.isEmpty && (texture.remoteEnabled || isEnabled(texture)))
    }

    private func requestGame(_ newGame: Int) {
        Task { @MainActor in
            guard let permit = await auth.permit(for: .gameSelection),
                  AuthProtection.validatePermit(permit, for: .gameSelection) else { return }
            withAnimation(.easeOut(duration: 0.14)) {
                game = newGame
            }
        }
    }

    private func isEnabled(_ texture: TextureCardOption) -> Bool {
        texture.game == 0 ? enabledNormal.contains(texture.id) : enabledMax.contains(texture.id)
    }

    private func textures(for game: Int) -> [TextureCardOption] {
        remoteConfig.features(tabID: "textures", game: game == 0 ? "normal" : "max")
            .compactMap(TextureCardOption.init(feature:))
    }

    private func insertEnabled(_ texture: TextureCardOption) {
        if texture.game == 0 { enabledNormal.insert(texture.id) }
        else { enabledMax.insert(texture.id) }
        PatchSwitchStateRegistry.setEnabled(true, featureID: texture.remoteID)
    }

    private func removeEnabled(_ texture: TextureCardOption) {
        if texture.game == 0 { enabledNormal.remove(texture.id) }
        else { enabledMax.remove(texture.id) }
        PatchSwitchStateRegistry.setEnabled(false, featureID: texture.remoteID)
    }

    private func setTexture(_ texture: TextureCardOption, enabledState: Bool) {
        guard !busy.contains(texture.id) else { return }
        if enabledState && !texture.remoteEnabled { return }

        Task { @MainActor in
            guard let permit = await auth.permit(for: .patchToggle),
                  AuthProtection.validatePermit(permit, for: .patchToggle) else {
                errorMessage = "Autenticação obrigatória. Valide sua key novamente."
                return
            }

            busy.insert(texture.id)
            defer { busy.remove(texture.id) }

            if enabledState {
                let previousTextures = textures(for: texture.game).filter {
                    $0.id != texture.id && isEnabled($0)
                }

                for previous in previousTextures {
                    let restoreResult = await performTextureOperation(false, texture: previous, permit: permit)
                    if case .failure(let error) = restoreResult {
                        errorMessage = PatchSlotRunner.message(for: error)
                        return
                    }
                    removeEnabled(previous)
                }
            }

            let result = await performTextureOperation(enabledState, texture: texture, permit: permit)

            switch result {
            case .success:
                if enabledState {
                    insertEnabled(texture)
                    successMessage = "Ativado com sucesso!"
                } else {
                    removeEnabled(texture)
                    successMessage = "Desinjetado com sucesso!"
                }
                successPresented = true
            case .failure(let error):
                errorMessage = PatchSlotRunner.message(for: error)
            }
        }
    }

    private func performTextureOperation(
        _ enabledState: Bool,
        texture: TextureCardOption,
        permit: ActionPermit
    ) async -> Result<String, Error> {
        await PatchSlotRunner.setEnabled(
            enabledState,
            patchID: texture.patchID,
            patch: remoteConfig.patch(id: texture.patchID),
            patchURL: remoteConfig.patchURL(id: texture.patchID),
            permit: permit,
            action: .patchToggle
        )
    }
}

// This test never calls ContainerStore, kexploit, or accesses another app.
// The admin may choose the path, but only under Documents/RemoteTests/.
private struct DirectFileTestReceipt: Codable {
    var targetPath: String
    var hadOriginal: Bool
    var appliedSHA256: String
}

private enum DirectFileSandboxTest {
    private static let maxBytes = 2 * 1024 * 1024

    private static func directory() throws -> URL {
        guard let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            throw NSError(domain: "DirectFileTest", code: 1, userInfo: [NSLocalizedDescriptionKey: "Documents indisponível"])
        }
        return documents.appendingPathComponent("RemoteTests", isDirectory: true)
    }

    private static func checkedTarget(_ input: String, createParents: Bool) throws -> URL {
        let components = input.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        guard components.count >= 3, components.count <= 14,
              components[0] == "Documents", components[1] == "RemoteTests",
              components.allSatisfy({ !$0.isEmpty && $0 != "." && $0 != ".." && !$0.hasPrefix(".") && $0.count <= 80 && $0.range(of: "^[A-Za-z0-9._~=\\-]+$", options: .regularExpression) != nil }) else {
            throw NSError(domain: "DirectFileTest", code: 2, userInfo: [NSLocalizedDescriptionKey: "Diretório de teste inválido. Use Documents/RemoteTests/..."])
        }
        let manager = FileManager.default
        let base = try directory()
        if createParents { try manager.createDirectory(at: base, withIntermediateDirectories: true) }
        var current = base
        for component in components.dropFirst(2).dropLast() {
            current.appendPathComponent(component, isDirectory: true)
            if createParents { try manager.createDirectory(at: current, withIntermediateDirectories: true) }
            if (try? current.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink) == true {
                throw NSError(domain: "DirectFileTest", code: 3, userInfo: [NSLocalizedDescriptionKey: "Links simbólicos não são permitidos no teste"])
            }
        }
        let target = current.appendingPathComponent(components.last!)
        if (try? target.resourceValues(forKeys: [.isSymbolicLinkKey]).isSymbolicLink) == true {
            throw NSError(domain: "DirectFileTest", code: 4, userInfo: [NSLocalizedDescriptionKey: "Destino simbólico não permitido"])
        }
        return target
    }

    private static func receiptURL() throws -> URL {
        try directory().appendingPathComponent(".direct-file-receipt.json")
    }

    private static func backupURL() throws -> URL {
        try directory().appendingPathComponent(".direct-file-original.bin")
    }

    static func isApplied() -> Bool {
        guard let receiptURL = try? receiptURL() else { return false }
        return FileManager.default.fileExists(atPath: receiptURL.path)
    }

    static func apply(_ remote: RemoteDirectFileTestConfig, downloadURL: URL) async throws {
        guard downloadURL.scheme?.lowercased() == "https" else {
            throw NSError(domain: "DirectFileTest", code: 5, userInfo: [NSLocalizedDescriptionKey: "Arquivo precisa vir de HTTPS"])
        }
        guard remote.size > 0, remote.size <= maxBytes else {
            throw NSError(domain: "DirectFileTest", code: 6, userInfo: [NSLocalizedDescriptionKey: "Arquivo excede 2 MB"])
        }
        let target = try checkedTarget(remote.targetPath, createParents: true)
        let receipt = try receiptURL()
        let backup = try backupURL()
        guard !FileManager.default.fileExists(atPath: receipt.path) else {
            throw NSError(domain: "DirectFileTest", code: 7, userInfo: [NSLocalizedDescriptionKey: "Teste aplicado. Restaure antes de aplicar outro."])
        }
        let (payload, response) = try await URLSession.shared.data(from: downloadURL)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200,
              payload.count == remote.size, payload.count <= maxBytes else {
            throw NSError(domain: "DirectFileTest", code: 8, userInfo: [NSLocalizedDescriptionKey: "Download incompleto"])
        }
        let digest = SHA256.hash(data: payload).map { String(format: "%02x", $0) }.joined()
        guard digest.caseInsensitiveCompare(remote.sha256) == .orderedSame else {
            throw NSError(domain: "DirectFileTest", code: 9, userInfo: [NSLocalizedDescriptionKey: "SHA-256 do arquivo não confere"])
        }
        let manager = FileManager.default
        let hadOriginal = manager.fileExists(atPath: target.path)
        if hadOriginal {
            let attributes = try manager.attributesOfItem(atPath: target.path)
            if let bytes = attributes[.size] as? NSNumber, bytes.intValue > maxBytes {
                throw NSError(domain: "DirectFileTest", code: 11, userInfo: [NSLocalizedDescriptionKey: "Arquivo original excede 2 MB; teste cancelado para preservar memória"])
            }
            try Data(contentsOf: target).write(to: backup, options: .atomic)
        }
        let record = DirectFileTestReceipt(targetPath: remote.targetPath, hadOriginal: hadOriginal, appliedSHA256: digest)
        try JSONEncoder().encode(record).write(to: receipt, options: .atomic)
        do {
            try payload.write(to: target, options: .atomic)
        } catch {
            try? manager.removeItem(at: receipt)
            throw error
        }
    }

    static func restore() throws {
        let receiptFile = try receiptURL()
        let record = try JSONDecoder().decode(DirectFileTestReceipt.self, from: Data(contentsOf: receiptFile))
        let target = try checkedTarget(record.targetPath, createParents: false)
        let manager = FileManager.default
        // Do not overwrite a file changed by someone else after our test applied.
        let current = try Data(contentsOf: target)
        let digest = SHA256.hash(data: current).map { String(format: "%02x", $0) }.joined()
        guard digest == record.appliedSHA256 else {
            throw NSError(domain: "DirectFileTest", code: 10, userInfo: [NSLocalizedDescriptionKey: "Arquivo alterado desde a aplicação; backup preservado"])
        }
        if record.hadOriginal {
            try Data(contentsOf: backupURL()).write(to: target, options: .atomic)
            try? manager.removeItem(at: backupURL())
        } else {
            try manager.removeItem(at: target)
        }
        try manager.removeItem(at: receiptFile)
    }
}

private struct ConfigDashboardView: View {
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var auth: AuthProtection
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    @Binding var darkMode: Bool
    @State private var showSettings = false
    @State private var directFileBusy = false
    @State private var directFileAlert: String?

    var body: some View {
        NavigationStack {
            List {
                Section("CONTA") {
                    HStack(spacing: 10) {
                        Text("Key")
                        Spacer(minLength: 12)
                        Text(auth.displayedKey)
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.75)

                        Button {
                            guard auth.displayedKey != "–" else { return }
                            UIPasteboard.general.string = auth.displayedKey
                        } label: {
                            Image(systemName: "doc.on.doc")
                                .font(.system(size: 15, weight: .semibold))
                        }
                        .buttonStyle(.plain)
                        .disabled(auth.displayedKey == "–")
                        .accessibilityLabel("Copiar key")
                    }

                    LabeledContent("Expira em", value: auth.expirationDisplay)
                    LabeledContent("Build", value: "20")
                    LabeledContent("Versão", value: "2.0")
                }
                Section {
                    LabeledContent("Phone", value: DeviceInfo.machine)
                    LabeledContent("Modelo de hardware", value: DeviceInfo.machine)
                    LabeledContent("Versão do iOS", value: UIDevice.current.systemVersion)
                    HStack {
                        Text("Compatibilidade"); Spacer()
                        Label(appState.isSupported ? "Suportado" : "Não suportado",
                              systemImage: appState.isSupported ? "checkmark.circle.fill" : "xmark.circle.fill")
                            .foregroundStyle(appState.isSupported ? Color.green : Color.red)
                    }
                } header: { Text("DISPOSITIVO") }
                footer: { Text("Verificado: iOS 17.0–17.7.x, 18.0–18.7.1, 26.0–26.6.1 e builds listados do iOS 27.") }

                Section("APARÊNCIA") {
                    Toggle(isOn: Binding(get: { darkMode }, set: { darkMode = $0 })) {
                        Label(darkMode ? "Modo escuro" : "Modo claro",
                              systemImage: darkMode ? "moon.fill" : "sun.max.fill")
                    }
                }
                Section("INSTALAÇÃO") {
                    Label("Certificado enterprise", systemImage: "checkmark.seal")
                }
                if let test = remoteConfig.config.directFileTest {
                    Section {
                        Text(test.targetPath).font(.system(size: 12, design: .monospaced))
                            .textSelection(.enabled)
                        LabeledContent("Tamanho", value: "\(test.size) bytes")
                        Button("INJETAR ARQUIVO TESTE") { runDirectFileTest(apply: true, info: test) }
                            .disabled(directFileBusy || DirectFileSandboxTest.isApplied())
                        Button("DESINJETAR ARQUIVO TESTE") { runDirectFileTest(apply: false, info: test) }
                            .disabled(directFileBusy || !DirectFileSandboxTest.isApplied())
                    } header: {
                        Text("TESTE DE DIRETÓRIO REMOTO")
                    } footer: {
                        Text("Somente Documents/RemoteTests/ dentro do próprio app; não altera outros aplicativos.")
                    }
                }
            }
            .font(.system(size: 15))
            .navigationTitle("Config")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showSettings = true } label: { Image(systemName:"gearshape") }
                }
            }
            .tint(remoteConfig.accentColor)
            .sheet(isPresented: $showSettings) {
                SettingsView().preferredColorScheme(darkMode ? .dark : .light)
            }
            .alert("Teste de arquivo", isPresented: Binding(
                get: { directFileAlert != nil },
                set: { if !$0 { directFileAlert = nil } }
            )) {
                Button("OK") { directFileAlert = nil }
            } message: {
                Text(directFileAlert ?? "")
            }
        }
    }

    private func runDirectFileTest(apply: Bool, info: RemoteDirectFileTestConfig) {
        guard !directFileBusy else { return }
        directFileBusy = true
        Task { @MainActor in
            defer { directFileBusy = false }
            let action: ProtectedAction = apply ? .patchApply : .patchRestore
            guard let permit = await auth.permit(for: action),
                  AuthProtection.validatePermit(permit, for: action) else {
                directFileAlert = "Autenticação obrigatória."
                return
            }
            do {
                if apply {
                    guard let url = remoteConfig.directFileTestURL else {
                        directFileAlert = "URL remota indisponível."
                        return
                    }
                    try await DirectFileSandboxTest.apply(info, downloadURL: url)
                    directFileAlert = "Arquivo de teste aplicado em Documents/RemoteTests/."
                } else {
                    try DirectFileSandboxTest.restore()
                    directFileAlert = "Arquivo original restaurado."
                }
            } catch {
                directFileAlert = error.localizedDescription
            }
        }
    }
}

private enum DeviceInfo {
    static var machine: String {
        var systemInfo = utsname(); uname(&systemInfo)
        let mirror = Mirror(reflecting: systemInfo.machine)
        return mirror.children.reduce(into: "") { result, element in
            guard let value = element.value as? Int8, value != 0 else { return }
            result.append(Character(UnicodeScalar(UInt8(value))))
        }
    }
}

private struct BottomItem: View {
    @EnvironmentObject private var remoteConfig: RemoteConfigStore
    let icon:String; let title:String; let selected:Bool; let darkMode:Bool; let action:()->Void
    var body: some View {
        Button(action:action) {
            VStack(spacing:3) {
                Image(systemName:icon).font(.system(size:19))
                Text(title).font(.system(size:11.5))
            }
            .foregroundStyle(selected ? remoteConfig.accentColor :
                                (darkMode ? Color.white.opacity(0.50) : Color.black.opacity(0.48)))
            .frame(maxWidth:.infinity).frame(height:56)
            .background(selected ? (darkMode ? Color.white.opacity(0.09) : Color.black.opacity(0.07)) : .clear,
                        in: RoundedRectangle(cornerRadius:24))
        }
        .buttonStyle(.plain)
        .animation(.easeOut(duration: 0.14), value: selected)
    }
}

// Each function owns a reversible sandbox transaction. Never write outside
// all app-owned directories, preserving per-feature rollback receipts.
private struct ManualDirectoryReceipt: Codable {
    let featureID: String
    let patchID: String
    let targetPath: String
    let hadOriginal: Bool
    let appliedSHA256: String
    let version: Int
}

private enum ManualDirectoryPatchService {
    private static let maxBytes = 32 * 1024 * 1024
    private static let fm = FileManager.default

    private static func documentsURL() throws -> URL {
        guard let url = fm.urls(for: .documentDirectory, in: .userDomainMask).first else {
            throw failure("Documents indisponível")
        }
        return url
    }

    private static func receiptsRoot() throws -> URL {
        guard let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            throw failure("Application Support indisponível")
        }
        let folder = support.appendingPathComponent("external-manual-receipts-v1", isDirectory: true)
        try fm.createDirectory(at: folder, withIntermediateDirectories: true)
        return folder
    }

    private static func receiptFolder(_ id: String) throws -> URL {
        guard id.range(of: "^[A-Za-z0-9._-]{1,100}$", options: .regularExpression) != nil,
              id != ".", id != ".." else { throw failure("ID da função inválido") }
        return try receiptsRoot().appendingPathComponent(id, isDirectory: true)
    }

    private static func failure(_ description: String) -> NSError {
        NSError(domain: "ManualDirectoryPatch", code: 20,
                userInfo: [NSLocalizedDescriptionKey: description])
    }

    private static func validatedTarget(_ raw: String, createParents: Bool) throws -> URL {
        guard !raw.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              raw.utf8.count <= 4096,
              !raw.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }) else {
            throw failure("Informe um caminho de arquivo válido")
        }
        // No application-defined directory allowlist: an explicit absolute path
        // is used as-is, while relative paths start at this app's home directory.
        // iOS still determines whether the process may access the final location.
        let expanded = raw.hasPrefix("~/") ? NSHomeDirectory() + String(raw.dropFirst()) : raw
        let candidate: URL
        if expanded.hasPrefix("/") {
            candidate = URL(fileURLWithPath: expanded, isDirectory: false)
        } else {
            candidate = URL(fileURLWithPath: NSHomeDirectory(), isDirectory: true)
                .appendingPathComponent(expanded, isDirectory: false)
        }
        let target = candidate.resolvingSymlinksInPath().standardizedFileURL
        if createParents {
            try fm.createDirectory(at: target.deletingLastPathComponent(),
                                   withIntermediateDirectories: true)
        }
        var isDirectory: ObjCBool = false
        if fm.fileExists(atPath: target.path, isDirectory: &isDirectory) && isDirectory.boolValue {
            throw failure("O destino informado é uma pasta; escolha o caminho de um arquivo")
        }
        return target
    }

    static func isApplied(featureID: String) -> Bool {
        guard let folder = try? receiptFolder(featureID) else { return false }
        return fm.fileExists(atPath: folder.appendingPathComponent("receipt.json").path)
    }

    private static func readReceipt(featureID: String) throws -> ManualDirectoryReceipt {
        let receipt = try receiptFolder(featureID).appendingPathComponent("receipt.json")
        guard fm.fileExists(atPath: receipt.path) else { throw failure("Backup não encontrado para esta função") }
        return try JSONDecoder().decode(ManualDirectoryReceipt.self, from: Data(contentsOf: receipt))
    }

    private static func ensureNoConflictingTarget(_ targetPath: String, except: String) throws {
        let destination = try validatedTarget(targetPath, createParents: false).path
        let root = try receiptsRoot()
        for candidate in try fm.contentsOfDirectory(at: root, includingPropertiesForKeys: nil) {
            guard candidate.lastPathComponent != except else { continue }
            let receipt = candidate.appendingPathComponent("receipt.json")
            if let data = try? Data(contentsOf: receipt),
               let active = try? JSONDecoder().decode(ManualDirectoryReceipt.self, from: data),
               let existing = try? validatedTarget(active.targetPath, createParents: false),
               existing.path == destination {
                throw failure("Outro patch manual já ocupa este arquivo: \(active.featureID)")
            }
        }
    }

    static func apply(_ patch: RemoteManualPatchConfig, featureID: String, url: URL) async throws {
        guard url.scheme?.lowercased() == "https" else { throw failure("Download do patch exige HTTPS") }
        guard patch.version > 0, patch.size > 0, patch.size <= maxBytes,
              patch.sha256.count == 64 else { throw failure("Patch manual não publicado ou excede 32 MB") }
        let target = try validatedTarget(patch.targetPath, createParents: true)
        let folder = try receiptFolder(featureID)
        if isApplied(featureID: featureID) { throw failure("Patch já aplicado. Restaure antes de atualizar") }
        try ensureNoConflictingTarget(patch.targetPath, except: featureID)
        let (data, response) = try await URLSession.shared.data(from: url)
        guard (response as? HTTPURLResponse)?.statusCode == 200,
              data.count == patch.size, data.count <= maxBytes else { throw failure("Download manual incompleto ou HTTP inválido") }
        let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        guard digest.caseInsensitiveCompare(patch.sha256) == .orderedSame else { throw failure("SHA-256 do patch manual não confere") }
        // Revalidate after asynchronous download, before touching a destination.
        _ = try validatedTarget(patch.targetPath, createParents: true)
        try ensureNoConflictingTarget(patch.targetPath, except: featureID)
        guard !isApplied(featureID: featureID) else { throw failure("Patch já aplicado") }
        let hadOriginal = fm.fileExists(atPath: target.path)
        try fm.createDirectory(at: folder, withIntermediateDirectories: true)
        let backup = folder.appendingPathComponent("original.bin")
        let receipt = folder.appendingPathComponent("receipt.json")
        if hadOriginal {
            let attributes = try fm.attributesOfItem(atPath: target.path)
            if let size = attributes[.size] as? NSNumber, size.int64Value > Int64(maxBytes) {
                throw failure("Arquivo original excede 32 MB; backup cancelado")
            }
            try fm.copyItem(at: target, to: backup)
        }
        let record = ManualDirectoryReceipt(featureID: featureID, patchID: patch.id,
                                            targetPath: target.path, hadOriginal: hadOriginal,
                                            appliedSHA256: digest, version: patch.version)
        do {
            try data.write(to: target, options: .atomic)
            try JSONEncoder().encode(record).write(to: receipt, options: .atomic)
        } catch {
            if hadOriginal && fm.fileExists(atPath: backup.path) {
                try? fm.removeItem(at: target)
                try? fm.copyItem(at: backup, to: target)
            } else if !hadOriginal { try? fm.removeItem(at: target) }
            try? fm.removeItem(at: folder)
            throw error
        }
    }

    static func restore(featureID: String) throws {
        let record = try readReceipt(featureID: featureID)
        let folder = try receiptFolder(featureID)
        let target = try validatedTarget(record.targetPath, createParents: false)
        let current = try Data(contentsOf: target)
        let digest = SHA256.hash(data: current).map { String(format: "%02x", $0) }.joined()
        guard digest.caseInsensitiveCompare(record.appliedSHA256) == .orderedSame else {
            throw failure("Destino mudou após aplicar o patch. Backup preservado; restaure manualmente")
        }
        if record.hadOriginal {
            let backup = folder.appendingPathComponent("original.bin")
            guard fm.fileExists(atPath: backup.path) else { throw failure("Backup original ausente; destino preservado") }
            let originalData = try Data(contentsOf: backup)
            try originalData.write(to: target, options: .atomic)
        } else {
            try fm.removeItem(at: target)
        }
        try fm.removeItem(at: folder)
    }
}
