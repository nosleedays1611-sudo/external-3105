import Foundation
import SwiftUI

private struct BuiltInPatchManifest: Codable {
    var title: String
    var items: [BuiltInPatchEntry]
}

private struct BuiltInPatchEntry: Codable, Identifiable, Hashable {
    var id: String { file }

    let screen: String
    let group: String
    let section: String
    let name: String
    let file: String
    let password: String?

    enum CodingKeys: String, CodingKey {
        case screen, group, section, name, file, password
    }

    init(
        screen: String,
        group: String,
        section: String,
        name: String,
        file: String,
        password: String? = nil
    ) {
        self.screen = screen
        self.group = group
        self.section = section
        self.name = name
        self.file = file
        self.password = password
    }
}

private struct BuiltInPatchAlert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
}

@MainActor
private final class BuiltInPatchController: ObservableObject {
    @Published private(set) var manifest = BuiltInPatchManifest(title: "EXTERNAL", items: [])
    @Published private(set) var enabledFiles = Set<String>()
    @Published private(set) var busyFiles = Set<String>()
    @Published var alert: BuiltInPatchAlert?

    private let activeProjectsKey = "externalPanel.activeProjects.v1"
    private var activeProjects: [String: String] = [:]

    init() {
        reload()
    }

    func reload() {
        do {
            manifest = try Self.loadManifest()
            activeProjects = UserDefaults.standard.dictionary(forKey: activeProjectsKey) as? [String: String] ?? [:]
            reconcileActiveState()
        } catch {
            manifest = BuiltInPatchManifest(title: "EXTERNAL", items: [])
            enabledFiles.removeAll()
            alert = BuiltInPatchAlert(
                title: "Configuração inválida",
                message: error.localizedDescription
            )
        }
    }

    func isEnabled(_ item: BuiltInPatchEntry) -> Bool {
        enabledFiles.contains(item.file)
    }

    func isBusy(_ item: BuiltInPatchEntry) -> Bool {
        busyFiles.contains(item.file)
    }

    func setEnabled(_ enabled: Bool, for item: BuiltInPatchEntry) {
        guard !busyFiles.contains(item.file), enabled != isEnabled(item) else { return }
        busyFiles.insert(item.file)

        let savedProjectID = activeProjects[item.file]

        Task.detached(priority: .userInitiated) {
            do {
                if enabled {
                    let decoded = try Self.decodePackage(for: item)
                    _ = try DevicePatchService.apply(project: decoded.project)
                    await MainActor.run {
                        self.activeProjects[item.file] = decoded.project.id.uuidString
                        self.saveActiveProjects()
                        self.enabledFiles.insert(item.file)
                        self.busyFiles.remove(item.file)
                    }
                } else {
                    let projectID: UUID
                    if let savedProjectID, let uuid = UUID(uuidString: savedProjectID) {
                        projectID = uuid
                    } else {
                        let decoded = try Self.decodePackage(for: item)
                        projectID = decoded.project.id
                    }

                    if let receipt = DevicePatchService.latestReceipt(projectID: projectID) {
                        try DevicePatchService.restore(receipt: receipt)
                    }

                    await MainActor.run {
                        self.activeProjects.removeValue(forKey: item.file)
                        self.saveActiveProjects()
                        self.enabledFiles.remove(item.file)
                        self.busyFiles.remove(item.file)
                    }
                }
            } catch {
                await MainActor.run {
                    self.busyFiles.remove(item.file)
                    self.enabledFiles.remove(item.file)
                    self.alert = BuiltInPatchAlert(
                        title: enabled ? "Não foi possível ativar" : "Não foi possível restaurar",
                        message: Self.friendlyMessage(error, item: item)
                    )
                }
            }
        }
    }

    private func reconcileActiveState() {
        var valid: [String: String] = [:]
        var active = Set<String>()

        for item in manifest.items {
            guard let stored = activeProjects[item.file],
                  let projectID = UUID(uuidString: stored),
                  DevicePatchService.latestReceipt(projectID: projectID) != nil
            else {
                continue
            }
            valid[item.file] = stored
            active.insert(item.file)
        }

        activeProjects = valid
        enabledFiles = active
        saveActiveProjects()
    }

    private func saveActiveProjects() {
        UserDefaults.standard.set(activeProjects, forKey: activeProjectsKey)
    }

    private static func loadManifest() throws -> BuiltInPatchManifest {
        guard let url = Bundle.main.url(
            forResource: "patches",
            withExtension: "json",
            subdirectory: "BuiltInPatches"
        ) else {
            throw NSError(
                domain: "ExternalPanel",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "O arquivo BuiltInPatches/patches.json não foi encontrado."]
            )
        }

        let data = try Data(contentsOf: url)
        return try JSONDecoder().decode(BuiltInPatchManifest.self, from: data)
    }

    private static func decodePackage(for item: BuiltInPatchEntry) throws -> DecodedPatchPackage {
        guard let url = Bundle.main.url(
            forResource: item.file,
            withExtension: nil,
            subdirectory: "BuiltInPatches"
        ) else {
            throw NSError(
                domain: "ExternalPanel",
                code: 2,
                userInfo: [NSLocalizedDescriptionKey: "O patch \"\(item.file)\" não está na pasta BuiltInPatches."]
            )
        }

        let data = try Data(contentsOf: url)
        return try PatchPackageCodec.decode(data, password: item.password)
    }

    private static func friendlyMessage(_ error: Error, item: BuiltInPatchEntry) -> String {
        if let patchError = error as? PatchPackageError {
            switch patchError {
            case .invalidPasswordOrCorruptedPackage:
                return "O arquivo \(item.file) está protegido por senha, corrompido ou não é compatível. Se ele tiver senha, adicione o campo password na linha dele em patches.json."
            case .targetAppUnavailable(let bundleID):
                return "O app de destino não foi encontrado ou não pôde ser acessado: \(bundleID)."
            case .restoreFailed:
                return "A restauração falhou. Evite trocar o arquivo .3105 enquanto o switch estiver ligado."
            case .applyFailed:
                return "O patch foi lido, mas não pôde ser aplicado ao arquivo de destino."
            default:
                return patchError.localizedDescription
            }
        }
        return error.localizedDescription
    }
}

struct ExternalPatchPanelView: View {
    private enum PanelTab: String, CaseIterable, Identifiable {
        case function = "Function"
        case textures = "Texturas"
        case config = "Config"

        var id: String { rawValue }

        var icon: String {
            switch self {
            case .function: return "house.fill"
            case .textures: return "person.fill"
            case .config: return "shippingbox.fill"
            }
        }
    }

    @StateObject private var controller = BuiltInPatchController()
    @State private var selectedTab: PanelTab = .function

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            Group {
                switch selectedTab {
                case .function:
                    PatchSwitchListScreen(
                        title: controller.manifest.title,
                        screen: "function",
                        controller: controller
                    )
                case .textures:
                    PatchSwitchListScreen(
                        title: controller.manifest.title,
                        screen: "textures",
                        controller: controller
                    )
                case .config:
                    PatchPanelConfigView(controller: controller)
                }
            }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            bottomBar
        }
        .preferredColorScheme(.dark)
        .alert(item: $controller.alert) { alert in
            Alert(
                title: Text(alert.title),
                message: Text(alert.message),
                dismissButton: .default(Text("OK"))
            )
        }
    }

    private var bottomBar: some View {
        HStack(spacing: 18) {
            ForEach(PanelTab.allCases) { tab in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) {
                        selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: tab.icon)
                            .font(.system(size: 18, weight: .semibold))
                        Text(tab.rawValue)
                            .font(.system(size: 11, weight: .medium))
                    }
                    .foregroundStyle(selectedTab == tab ? PanelStyle.accent : .gray)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background {
                        if selectedTab == tab {
                            Capsule(style: .continuous)
                                .fill(Color.white.opacity(0.10))
                        }
                    }
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 18)
        .padding(.top, 8)
        .padding(.bottom, 4)
        .background(.ultraThinMaterial)
        .background(Color.black.opacity(0.84))
    }
}

private enum PanelStyle {
    static let accent = Color(red: 0.62, green: 0.76, blue: 0.93)
    static let muted = Color.white.opacity(0.20)
}

private struct PatchSwitchListScreen: View {
    let title: String
    let screen: String
    @ObservedObject var controller: BuiltInPatchController

    @State private var selectedGroup: String = ""

    private var entries: [BuiltInPatchEntry] {
        controller.manifest.items.filter {
            $0.screen.caseInsensitiveCompare(screen) == .orderedSame
        }
    }

    private var groups: [String] {
        var seen = Set<String>()
        return entries.compactMap { item in
            seen.insert(item.group).inserted ? item.group : nil
        }
    }

    private var effectiveGroup: String? {
        if groups.contains(selectedGroup) { return selectedGroup }
        return groups.first
    }

    private var filteredEntries: [BuiltInPatchEntry] {
        guard let effectiveGroup else { return entries }
        return entries.filter { $0.group == effectiveGroup }
    }

    private var sections: [(String, [BuiltInPatchEntry])] {
        var order: [String] = []
        var buckets: [String: [BuiltInPatchEntry]] = [:]
        for item in filteredEntries {
            if buckets[item.section] == nil { order.append(item.section) }
            buckets[item.section, default: []].append(item)
        }
        return order.map { ($0, buckets[$0] ?? []) }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 22) {
                Spacer().frame(height: 30)

                if !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Text(title)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, alignment: .center)
                }

                groupSelector

                if sections.isEmpty {
                    emptyState
                } else {
                    ForEach(Array(sections.enumerated()), id: \.offset) { _, section in
                        sectionView(name: section.0, entries: section.1)
                    }
                }

                Spacer().frame(height: 20)
            }
            .padding(.horizontal, 28)
        }
        .onAppear {
            if selectedGroup.isEmpty { selectedGroup = groups.first ?? "" }
        }
        .onChange(of: groups) { newGroups in
            if !newGroups.contains(selectedGroup) {
                selectedGroup = newGroups.first ?? ""
            }
        }
    }

    @ViewBuilder
    private var groupSelector: some View {
        if !groups.isEmpty {
            HStack(spacing: 16) {
                ForEach(groups, id: \.self) { group in
                    Button {
                        selectedGroup = group
                    } label: {
                        Text(group)
                            .font(.system(size: 13, weight: .bold, design: .rounded))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(Color.black)
                            .overlay {
                                RoundedRectangle(cornerRadius: 17, style: .continuous)
                                    .stroke(
                                        effectiveGroup == group ? PanelStyle.accent : Color.white.opacity(0.30),
                                        lineWidth: effectiveGroup == group ? 1.8 : 1.2
                                    )
                            }
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func sectionView(name: String, entries: [BuiltInPatchEntry]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(name.uppercased())
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .tracking(0.8)
                .foregroundStyle(PanelStyle.accent)
                .padding(.bottom, 3)

            ForEach(entries) { item in
                patchRow(item)
            }
        }
    }

    private func patchRow(_ item: BuiltInPatchEntry) -> some View {
        HStack(spacing: 16) {
            Text(item.name)
                .font(.system(size: 15, weight: .medium))
                .foregroundStyle(.white.opacity(0.92))
                .frame(maxWidth: .infinity, alignment: .leading)

            if controller.isBusy(item) {
                ProgressView()
                    .controlSize(.small)
                    .frame(width: 50)
            } else {
                Toggle(
                    "",
                    isOn: Binding(
                        get: { controller.isEnabled(item) },
                        set: { controller.setEnabled($0, for: item) }
                    )
                )
                .labelsHidden()
                .tint(PanelStyle.accent)
            }
        }
        .frame(minHeight: 54)
        .contentShape(Rectangle())
    }

    private var emptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "shippingbox")
                .font(.system(size: 30, weight: .light))
                .foregroundStyle(PanelStyle.accent)
            Text("Nenhum patch nesta aba")
                .font(.headline)
                .foregroundStyle(.white)
            Text("Edite BuiltInPatches/patches.json para adicionar linhas.")
                .font(.caption)
                .foregroundStyle(.gray)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 60)
    }
}

private struct PatchPanelConfigView: View {
    @ObservedObject var controller: BuiltInPatchController
    @State private var tool: OriginalTool?

    private enum OriginalTool: String, Identifiable {
        case patches
        case files
        case cleaner
        case wallpapers
        case settings

        var id: String { rawValue }
    }

    var body: some View {
        ScrollView(showsIndicators: false) {
            VStack(alignment: .leading, spacing: 18) {
                Spacer().frame(height: 30)

                Text("CONFIG")
                    .font(.system(size: 20, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)

                configCard(
                    title: "PATCHES INTERNOS",
                    body: "Coloque seus arquivos .3105 em ThreeOneOSFive/BuiltInPatches e edite apenas o patches.json para criar, remover ou renomear as linhas."
                )

                Button {
                    controller.reload()
                } label: {
                    Label("Recarregar lista", systemImage: "arrow.clockwise")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(PanelButtonStyle())

                Text("FERRAMENTAS DO 3105")
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .tracking(0.7)
                    .foregroundStyle(PanelStyle.accent)
                    .padding(.top, 4)

                toolButton("Editor / Importador .3105", icon: "shippingbox.fill", tool: .patches)
                toolButton("Arquivos", icon: "folder.fill", tool: .files)
                toolButton("Cleaner", icon: "sparkles", tool: .cleaner)
                toolButton("Wallpapers", icon: "photo.on.rectangle.angled", tool: .wallpapers)
                toolButton("Ajustes", icon: "gearshape.fill", tool: .settings)

                configCard(
                    title: "IMPORTANTE",
                    body: "Antes de substituir um .3105 que esteja em uso, desligue o switch dele para o 3105 restaurar o backup original."
                )

                Spacer().frame(height: 20)
            }
            .padding(.horizontal, 28)
        }
        .sheet(item: $tool) { tool in
            switch tool {
            case .patches:
                PatchProjectsView()
            case .files:
                AppDataBrowserView()
            case .cleaner:
                CleanerView()
            case .wallpapers:
                WallpaperLabView()
            case .settings:
                SettingsView()
            }
        }
    }

    private func configCard(title: String, body: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(.system(size: 13, weight: .bold, design: .rounded))
                .foregroundStyle(PanelStyle.accent)
            Text(body)
                .font(.system(size: 14))
                .foregroundStyle(.white.opacity(0.76))
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color.white.opacity(0.055))
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(Color.white.opacity(0.09), lineWidth: 1)
        }
    }

    private func toolButton(_ title: String, icon: String, tool: OriginalTool) -> some View {
        Button {
            self.tool = tool
        } label: {
            HStack(spacing: 12) {
                Image(systemName: icon)
                    .frame(width: 22)
                    .foregroundStyle(PanelStyle.accent)
                Text(title)
                    .foregroundStyle(.white)
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.gray)
            }
            .padding(.horizontal, 16)
            .frame(height: 52)
            .background(Color.white.opacity(0.055))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}

private struct PanelButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14, weight: .semibold))
            .foregroundStyle(.black)
            .padding(.vertical, 13)
            .background(PanelStyle.accent.opacity(configuration.isPressed ? 0.70 : 1.0))
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
